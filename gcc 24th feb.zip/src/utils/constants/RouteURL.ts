export const Route_URL = {
	login: `/`,
	somethingwentwrong: '/something_went_wrong',
	accessdenied: '/access_denied',
	dashboard: '/dashboard',
	dashboardV2: '/dashboard_v2',
	triageDetails: '/dashboard/triage_details',
	corelationDetails: '/dashboard/corelation',
	eventOverview: '/dashboard/event_overview',
	incidentOverview: '/dashboard/incident_overview',
	ciOverview: '/dashboard/ci_overview'
};