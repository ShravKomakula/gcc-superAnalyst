import moment from "moment"
import { notifications } from "@mantine/notifications";

import classes from "../modules/login/styles/AuthenticationImage.module.css"
import { CONFIGURATIONS } from "./constants/configurations";

export const getAccount = () => {
  const Account = localStorage.getItem('account') ?? ''
  return Account
}

export const formatDateTime = (value: string) => {
  if(value) {
    return moment(value).format('MMMM DD YYYY, HH:mm:ss A')
  }
  return value;
}

export const getformatedDateTime = (value: string, format: string) => {
  if(value && format) {
    return moment(value).format(format)
  }
  return value;
}

export const getCurrPrevDaysformatDateTime = (days: number = 0, hours: number = 0, minutes: number = 0, seconds: number = 0) => {
  if(days > 0) {
    return moment().subtract(days, 'days').set({ hour: hours, minute: minutes, second: seconds }).format('YYYY-MM-DD HH:mm:ss')
  }
  return moment().set({ hour: hours, minute: minutes, second: seconds }).format('YYYY-MM-DD HH:mm:ss');
}

export const formatFilterDateTimeString = (value: string | string[]) => {
  if (Array.isArray(value)) {
    const endDate = value.length > 1 ? value[1] : value[0];
 
    return `${moment(value[0]).format("YYYY-MM-DD HH:mm:ss")} To ${moment(
      endDate
    ).format("YYYY-MM-DD HH:mm:ss")}`;
  } else if (typeof value === "string") {
    const dateTimeArr = value.split(",");
    const endDate = dateTimeArr.length > 1 ? dateTimeArr[1] : dateTimeArr[0];
 
    return `${moment(dateTimeArr[0]).format("YYYY-MM-DD HH:mm:ss")} To ${moment(
      endDate
    ).format("YYYY-MM-DD HH:mm:ss")}`;
  }
 
  return value; // Return as-is if it's neither a string nor an array
};

export const formatFilterDateTime = (value: string) => {
  if(value) {
    const dateTimeArr = value.split(",");
    const endDate = dateTimeArr && dateTimeArr[1] ? dateTimeArr[1] : dateTimeArr[0]
    return [moment(dateTimeArr[0]).format('YYYY-MM-DD HH:mm:ss'), moment(endDate).format('YYYY-MM-DD HH:mm:ss')]
  }
  return value;
}

export const formatFilterPayloadDateTime = (value: any) => {
  if(value) {
    const endDate = value[1] ? value[1] : value[0]
    return {
      "start_date": moment(value[0]).format('YYYY-MM-DD HH:mm:ss'),
      "end_date": moment(endDate).format('YYYY-MM-DD HH:mm:ss')
    }
  }
  return value;
}

export const showMessage = (color: string, title: string, message: string) => {
  return notifications.show({
      color: color,
      title: title,
      message: message,
      classNames: classes,
  })
}

// Function to determine the link based on ID prefix
export const getDynamicLink = (ID: string): string => {
  if(ID === '') {
    return '';
  }
  let IDVal = ID.toString();
  if (IDVal.startsWith('IM')) {
      return `${CONFIGURATIONS.SMWEB_LINK}${IDVal}`;
  }
  if (IDVal.startsWith('GCC') || /^\d+$/.test(IDVal)) {
      return `${CONFIGURATIONS.EVENT_LINK}${ID}`;
  }
  if (IDVal.startsWith('CR')) {
      return `${CONFIGURATIONS.SMWEBRFC_LINK}${IDVal}`;
  }
  return `${CONFIGURATIONS.CI_LINK}${IDVal}`;
};

export const parseTextWithHyperlinks = (text: string): string => {
  const regexIncident = /\bIM(\d+)\b/g; // Incident ID (e.g., IM45217007)
  const regexEvent = /\bGCC-(\d+)\b/g;  // Event ID (e.g., GCC-1234)
  const regexRFC = /\bCR(\d+)\b/g;      // RFC ID (e.g., CR9876)

  // Function to create a hyperlink with a dynamic base URL
  const createLink = (id: string, type: string): string => {
      let baseUrl = "";
      switch (type) {
          case "IN":
              baseUrl = CONFIGURATIONS.SMWEB_LINK;
              break;
          case "GCC-":
              baseUrl = CONFIGURATIONS.EVENT_LINK;
              break;
          case "CR":
              baseUrl = CONFIGURATIONS.SMWEBRFC_LINK;
              break;
          default:
              baseUrl = CONFIGURATIONS.SMWEB_LINK;
      }
      return `<a href="${baseUrl}${type}${id}" target="_blank" class="custom-link">${type}${id}</a>`;
  };

  // Replace the IDs with dynamic links
  let parsedText = text
      .replace(regexIncident, (match, id) => createLink(id, "IM"))
      .replace(regexEvent, (match, id) => createLink(id, "GCC-"))
      .replace(regexRFC, (match, id) => createLink(id, "CR"));

  return parsedText;
};