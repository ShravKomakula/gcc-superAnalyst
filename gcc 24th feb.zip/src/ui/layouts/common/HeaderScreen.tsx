import {
  Group,
  Box,
  Image,
  Menu,
  Text,
} from '@mantine/core';
import { useEffect, useState, useRef } from "react";
import { useNavigate, useLocation } from 'react-router-dom';
import classes from './HeaderMegaMenu.module.css';
import ProfileIcon from 'assets/images/userColor.png';
import PfizerLogo from 'assets/images/Pfizer_Logo_Color_RGB.svg';
import VerticalBar from 'assets/images/vertical_header_bar.svg';
import { Route_URL } from 'utils/constants/RouteURL';

const HeaderScreen = (props: any) => {
  const navigate = useNavigate();
  const [isMenuOpen, setMenuOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close menu when clicking outside
  const handleOutsideClick = (event: MouseEvent) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
      setMenuOpen(false); // Close the dropdown
    }
  };

  useEffect(() => {
    if (isMenuOpen) {
      // Add event listener to detect clicks outside
      document.addEventListener("mousedown", handleOutsideClick);
    } else {
      // Cleanup event listener when menu is closed
      document.removeEventListener("mousedown", handleOutsideClick);
    }

    // Cleanup when the component unmounts
    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, [isMenuOpen]);


// useClickOutside(handleClickOutside, dropdownRef);
  const location = useLocation();
  const [username, setUsername] = useState('-');
  const localStorageData = localStorage.getItem('jwt_Token') ?? null;

  useEffect(() => {
    if (localStorageData) {
      const userInfo = JSON.parse(localStorageData);
      const fullname = userInfo.username.substring(0, userInfo.username.indexOf('@'));
      const fullnameArr = fullname.split('.');
      let fName = fullnameArr.shift(0);
      let lName = fullnameArr.pop();
      fName = fName[0].toUpperCase() + fName.slice(1);
      lName = lName[0].toUpperCase() + lName.slice(1);
      setUsername(`${fName} ${lName}`);
    }
  }, [localStorageData]);

  const handleLogout = () => {
    localStorage.clear();
    navigate(Route_URL.login);
  };


  return (
    <Box>
      <header className={classes.header} style={{ display: "flex", justifyContent: "space-between" }}>
        <Group>
          <Image
            className={classes.pointer}
            src={PfizerLogo}
            alt="Pfizer Logo"
            onClick={() => navigate('/dashboard')}
          />
          <Image
            className={classes.pointer}
            src={VerticalBar}
            alt="Vertical Bar"
          />
          <Text className={classes.link}>Super Analyst</Text>
        </Group>

        <div style={{ padding: "15px" }}>
          <Group visibleFrom="sm" style={{ position: 'relative' }}>
            <span className="textname" style={{ fontSize: "16px", fontWeight: 600 }}>{username}</span>
            <Image
              className={classes.pointer}
              src={ProfileIcon}
              height="40px"
              width="40px"
              alt="User Icon"
              onClick={() => setMenuOpen((prev) => !prev)} // Toggle menu visibility
            />

            
            {isMenuOpen && (
              <div 
              ref={dropdownRef}
                style={{
                  position: 'absolute',
                  top: '50px',
                  right: '0',
                  background: 'white',
                  padding: '10px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  zIndex: 100,
                }} 
              >
                <Text
                  style={{ cursor: 'pointer', color: 'red' }}
                  onClick={handleLogout} // Logout on click
                >
                  
                  Logout
                </Text>
              </div>
            )}
          </Group>
        </div>
      </header>
    </Box>
  );
};

export default HeaderScreen;