interface PrivateLayoutSubHeaderProps {}
const PrivateLayoutSubHeader: React.FC<PrivateLayoutSubHeaderProps> = ({}) => {
  return (
    <div>
      
    </div>
  )
}
export default PrivateLayoutSubHeader
