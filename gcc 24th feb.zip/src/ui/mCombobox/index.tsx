import { useState } from 'react';
import { Combobox, ScrollArea, TextInput, useCombobox } from '@mantine/core';
import { IconSearch } from '@tabler/icons-react';

const MCombobox = (props: any) => {
    const { label, data, value, setValue, disabled } = props;
    const combobox = useCombobox();
    const shouldFilterOptions = !data.some((item: any) => item === value);
    const filteredOptions = shouldFilterOptions
        ? data.filter((item: any) => item.toLowerCase().includes(value.toLowerCase().trim()))
        : data;

    const options = filteredOptions.map((item: any) => (
        <Combobox.Option value={item} key={item}>
            {item}
        </Combobox.Option>
    ));
    return (
        <Combobox
            onOptionSubmit={(optionValue) => {
                setValue(optionValue);
                combobox.closeDropdown();
            }}
            store={combobox}
        >
            <Combobox.Target>
                <TextInput
                    label={label}
                    placeholder="Type here..."
                    size='md'
                    // leftSection={<IconSearch size={14} />}
                    rightSection={<IconSearch size={14} />}
                    value={value}
                    onChange={(event) => {
                        setValue(event.currentTarget.value);
                        combobox.openDropdown();
                    }}
                    disabled={disabled ?? false}
                    onClick={() => combobox.openDropdown()}
                    onFocus={() => combobox.openDropdown()}
                    onBlur={() => combobox.closeDropdown()}
                />
            </Combobox.Target>
            <Combobox.Dropdown hidden={options.length === 0}>
                <ScrollArea h={250}>
                    <Combobox.Options>{options}</Combobox.Options>
                </ScrollArea>
            </Combobox.Dropdown>
        </Combobox>
    )
}

export default MCombobox;