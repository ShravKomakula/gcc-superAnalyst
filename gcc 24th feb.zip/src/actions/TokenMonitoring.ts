import { getTokenMonitoringListService } from "services/TokenMonitoringServices";

export const getTokenMonitoringListAction = async (payload: any) => {
  return await getTokenMonitoringListService(payload).then((result) => {
      return result.data;
  }).catch((error) => {
      return error.response;
  });
};