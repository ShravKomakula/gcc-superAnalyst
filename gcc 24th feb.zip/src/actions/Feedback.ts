import { filterFeedbackStatusService, getFeedbackService, getFeedbackStatsService, getFeedbackTextService } from "services/FeedbackServices";

export const getFeedbackListAction = async (payload: any) => {
    return await getFeedbackService(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const getFeedbackStatsAction = async (payload: any) => {
    return await getFeedbackStatsService(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const getFeedbackTextAction = async (payload: any) => {
  return await getFeedbackTextService(payload).then((result) => {
      return result.data;
  }).catch((error) => {
      return error.response;
  });
};

export const filterFeedbackStatusAction = async (payload: any) => {
  return await filterFeedbackStatusService(payload).then((result) => {
      return result.data;
  }).catch((error) => {
      return error.response;
  });
};