import axios from 'axios'

const getToken = () => {
  const token = localStorage.getItem('jwt_Token') ?? ''
  return token
}

const axiosInstance = axios.create({
  baseURL: process.env.REACT_APP_AUTH_API_URL ? process.env.REACT_APP_AUTH_API_URL : '',
  headers: {},
})
axiosInstance.interceptors.request.use(
  (config: any) => {
    if (!config) {
      config = {}
    }
    if (!config.headers) {
      config.headers = {}
    }
    // config.headers['Authorization'] = `${'Bearer' + ' ' + getToken()}`
    // config.headers['Access-Control-Allow-origin'] = `*`;
    config.headers['Accept'] = `application/json`;
    // config.headers['Content-type'] = `application/json`;
    
    return config
  },
  (error) => {
    Promise.reject(error)
  }
)

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    return Promise.reject(error)
  }
)

export default axiosInstance
