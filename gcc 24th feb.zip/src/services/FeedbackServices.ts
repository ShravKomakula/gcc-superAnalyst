import axiosInstance from "./AxiosInstance";


export const getFeedbackService = async (payload: any) => {
    const response = await axiosInstance.post(`feedback_table`, payload);
    return response;
};

export const getFeedbackStatsService = async (payload: any) => {
    const response = await axiosInstance.post(`feedback_summary`, payload);
    return response;
};

export const getFeedbackTextService = async (payload: any) => {
    const response = await axiosInstance.post(`filter_feedback_text`, payload);
    return response;
};

export const filterFeedbackStatusService = async (payload: any) => {
    const response = await axiosInstance.post(`filter_feedback_status`, payload);
    return response;
};