import axios from 'axios'
const axiosAuthInstance = axios.create({
  baseURL: 'http://10.11.168.41:8002/',//'http://localhost:8001/', // Replace with your API base URL
});

// Request interceptor
axiosAuthInstance.interceptors.request.use(
  (config: any) => {
    if(!config) {
      config = {};
    }
    if(!config.headers) {
      config.headers = {};
    }
    config.headers = {
      'Authorization': `${'Basic' + ' ' + ''}`,
      'Content-Type': 'application/x-www-form-urlencoded',
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Origin, X-Requested-With, Content-Type, Accept"
    };
    return config;
  },
  (error) => {
    // Handle request errors here
    return Promise.reject(error);
  }
);

axiosAuthInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    return Promise.reject(error)
  }
)
export default axiosAuthInstance;