import axios from 'axios'

const getToken = () => {
  const token = localStorage.getItem('jwt_Token') ?? ''
  return token
}

const axiosInstanceTriage = axios.create({
  baseURL: process.env.REACT_APP_API_URL_TRIAGE ? process.env.REACT_APP_API_URL_TRIAGE : '',
  headers: {},
})
axiosInstanceTriage.interceptors.request.use(
  (config: any) => {
    if (!config) {
      config = {}
    }
    if (!config.headers) {
      config.headers = {}
    }
    // config.headers['Authorization'] = `${'Bearer' + ' ' + getToken()}`
    // config.headers['Access-Control-Allow-origin'] = `*`;
    return config
  },
  (error) => {
    Promise.reject(error)
  }
)

axiosInstanceTriage.interceptors.response.use(
  (response) => response,
  (error) => {
    return Promise.reject(error)
  }
)

export default axiosInstanceTriage
