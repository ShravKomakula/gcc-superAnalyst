import {
    Paper,
    Tabs,
    Text
} from "@mantine/core";
import { StyleContainer } from "../styles/Feedback.styles";
import FeedbackOverview from "./FeedbackOverview";
import TokenMonitoringOverview from "./TokenMonitoringOverview";

const Feedback = () => {

    return (
        <StyleContainer fluid>
            <Paper className="paperTbl">
            <Tabs defaultValue="feedback_summary" variant="outline" radius="md" orientation="horizontal">
                <Tabs.List>
                    <Tabs.Tab value="feedback_summary"><Text fw={500}>Feedback Summary</Text></Tabs.Tab>
                    <Tabs.Tab value="token_monitoring"><Text fw={500}>Token Monitoring</Text></Tabs.Tab>
                </Tabs.List>
                <Tabs.Panel value="feedback_summary">
                    <FeedbackOverview />
                </Tabs.Panel>
                <Tabs.Panel value="token_monitoring">
                    <TokenMonitoringOverview />
                </Tabs.Panel>
            </Tabs>
            </Paper>
        </StyleContainer>
    )
}

export default Feedback;