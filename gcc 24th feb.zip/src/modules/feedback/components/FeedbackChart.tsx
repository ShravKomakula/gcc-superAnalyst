import { BarChart } from '@mantine/charts';
import { Paper, Skeleton } from '@mantine/core';
import '@mantine/charts/styles.css';
import { useEffect, useState } from 'react';

const FeedbackChart = (props: any) => {
    const { data, fetching } = props;
    const [chartData, setChartData] = useState([]);

    useEffect(() => {
        const cData = data && data.map((d: any) => {
            return { 
                name: String(d.category).charAt(0).toUpperCase() + String(d.category).slice(1), 
                Positive: d.positive, 
                Negative: d.negative,
                Percentage_Positive: parseFloat(d.percentage_positive)
            }
        })
        if(cData && cData.length > 0) {
            setChartData(cData);
        } else {
            setChartData([]);
        }
    }, [data])

    return (
        <Paper className="paperTbl">
            <Skeleton visible={fetching}>
            <BarChart
                h={300}
                type='default'
                data={chartData}
                dataKey="name"
                // valueFormatter={(value: number | bigint) => new Intl.NumberFormat('en-US').format(value)}
                withBarValueLabel
                withLegend
                legendProps={{ verticalAlign: 'top', height: 50 }}
                series={[
                    { name: 'Positive', color: 'green.6' },
                    { name: 'Negative', color: 'blue.6' },
                    { name: 'Percentage_Positive', color: 'teal.6' },
                ]}
            />
            </Skeleton>
        </Paper>
    )
}

export default FeedbackChart;