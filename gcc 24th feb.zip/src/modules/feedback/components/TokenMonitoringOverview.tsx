import React, {} from "react";
import {
} from "@mantine/core";
import TokenMonitoringTable from "./TokenMonitoringTable";

const TokenMonitoringOverview = () => {

    return (
        <React.Fragment>
            <TokenMonitoringTable />
        </React.Fragment>
    )
}

export default TokenMonitoringOverview