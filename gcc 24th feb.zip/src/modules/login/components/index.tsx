import {
    Paper,
    TextInput,
    PasswordInput,
    Checkbox,
    Button,
    Title,
    Text,
    Anchor,
    Container,
    Grid,
    Flex,
    Group,
    Box,
    Divider,
    Stack,
    Center,
    Image,
    LoadingOverlay
} from '@mantine/core';
import { useForm } from '@mantine/form';
import { useToggle, upperFirst, useDisclosure } from '@mantine/hooks';
import { notifications } from '@mantine/notifications';
import styled from '@emotion/styled'
import classes from '../styles/AuthenticationImage.module.css';
import { type } from '@testing-library/user-event/dist/type';
import { ThemeInterface, monochromeColor, pfizerColor, pfizerColor1 } from 'utils/constants/ColorPalette';
import { fontFamily, fontStyle } from 'utils/constants/TypographyProperties'
import { Icons } from 'assets/images';
import { useNavigate } from 'react-router-dom';
import { Route_URL } from 'utils/constants/RouteURL';
import { loginAction } from 'actions/Auth';
import SingleSignOn from './SingleSignOn';

const StyleContainer = styled(Container)`
    padding: 0 !important;
    margin: 0 !important;
    /* position: relative; */
    height: 100%;
    .login-form-paper {
        position: absolute;
        top: 5%;
        // left: 700px;
        right:10%;
        width: 500px;
        height: 580px;
        border-radius: 20px;
        padding: 50px;
        background: ${monochromeColor[6]} 0% 0% no-repeat padding-box;
        box-shadow: 10px 5px 20px #00000029;
        border: 1px solid #8B8B8B;
        opacity: 1;
        float: none; 
        margin: 0 auto;
        text-align: center;
    }
    .mantine-Grid-inner {
        margin: 0px;
    }
    .left-box-content {
        display: flex;
        /* align-items: center; */
        /* justify-content: center; */
    }
    .text-section {
        width: 542px;
        position: absolute;
        top: 157px;
        left: 50px;
    }
    .text-ays {
        text-align: center;
        font: ${fontStyle} 55px/54px ${fontFamily};
        letter-spacing: 0.55px;
        color: ${monochromeColor[6]};
        opacity: 1;
    }
    .text-ays-subtitle {
        font: ${fontStyle} 30px/35px ${fontFamily};
        letter-spacing: 0.6px;
        color: ${monochromeColor[6]};
        opacity: 1;
    }
        .image-bottom-section-01{
         position: absolute;
    bottom: 315px;
    left: 225px;
    overflow: hidden;
    height: 160px;
    width: 160px;
    padding: 10px;
        }
        .image-bottom-section{
         position: absolute;
    bottom: 200px;
    left: 480px;
    overflow: hidden;
    height: 160px;
    width: 160px;
    padding: 10px;
        }
    .text-bottom-section {
        position: absolute;
        bottom: 0;
        left: 0;
        padding: 350px 100px 0px 0px;
         overflow: hidden;
         height:500px;
         width:331px;
    }
    .text-bottom-section img {
    position: absolute;
    right: -50px;
    bottom: -150px;
    width: 100%; 
}
    .text-system-support {
        color: ${monochromeColor[6]};
    }
    .text-phone {
        color: ${monochromeColor[6]};
    }
    .text-fax {
        color: ${monochromeColor[6]};
    }
    .form-logo-section .mantine-Group-root {
        /* display: flex; */
        justify-content: center;
    }
    .login-text {
        padding-top: 30px;
    }
    .text-login-account {
        font: ${fontStyle} 30px/39px ${fontFamily};
        color: #4B4B4B;
    }
    .login-form {
        padding-top: 30px;
    }
    .btn-login {
        width: 441px;
        height: 48px;
        background: #0000C9 0% 0% no-repeat padding-box;
        border-radius: 10px;
    }
    .btn-login-sso {
        width: 441px;
        height: 48px;
        background: rgb(0, 149, 255) 0% 0% no-repeat padding-box;
        border-radius: 10px;
    }
    .text-copyright {
        position: absolute;
        bottom: 0;
        /* left: 0; */
    }
`

const Login = () => {
    const navigate = useNavigate()
    const [type, toggle] = useToggle(['login', 'register']);
    const [visible, handlers] = useDisclosure(false);
    
    const form = useForm({
        initialValues: {
          email: '',
          password: ''
        },
        validate: {
          email: (val) => (/^\S+@\S+$/.test(val) ? null : 'Invalid email'),
          password: (val) => (val.length <= 6 ? 'Password should include at least 6 characters' : null),
        },
    });

    const handleLogin = (values: { email: string; password: string; }) => {
        handlers.open();
        const response = loginAction({email: values.email, password: values.password});
        response.then((result: any) => {
            if(result === true) {
                localStorage.setItem('jwt_Token', JSON.stringify({'username': values.email}));
                notifications.show({
                    title: 'Success!!',
                    message: 'Login successfully!',
                    classNames: classes,
                })
                navigate(Route_URL.dashboard)
            } else {
                notifications.show({
                    color: 'red',
                    title: 'Error!!',
                    message: 'Invalid credentials, Please check username or password!',
                    classNames: classes,
                })
            }
            handlers.close();
        });
    }

    return (
        <StyleContainer fluid style={{width: '98%',height:'98%'}}>
            <LoadingOverlay loaderProps={{ color: '#000484' }} visible={visible} zIndex={1000} overlayProps={{ radius: "sm", blur: 2 }} />
            <Grid>
                <Grid.Col style={{ minHeight: '100%', height: '100vh', overflow: 'hidden' }} span={{ base: 12, xs: 8 }} bg={pfizerColor1}>
                    <Flex
                        mih={50}
                        gap="sm"
                        justify="flex-center"
                        align="flex-center"
                        direction="column"
                        wrap="wrap"
                        className='text-section'
                    >
                        <Text className='text-ays'>Access your Services</Text>
                        <Text className='text-ays-subtitle'>Browse for more catalog based services and items you need</Text>
                    </Flex>
                    <Flex 
                         mih={50}
                         // gap="sm"
                         justify="flex-center"
                         align="flex-center"
                         direction="column"
                         wrap="wrap"
                         className='image-bottom-section-01'
                         >
                        <Image
                            h={'100px'}
                            w={'100px'}
                            style={{
                                position: 'absolute',
                                right: '0px',
                                bottom: '-0px',
                                padding: '-75px 0 0 -100px'
                            }}
                            src={Icons.Imgobjects_01}
                        />

                        </Flex>
                    <Flex 
                         mih={50}
                         // gap="sm"
                         justify="flex-center"
                         align="flex-center"
                         direction="column"
                         wrap="wrap"
                         className='image-bottom-section'
                         >
                        <Image
                            h={'150px'}
                            w={'150px'}
                            style={{
                                position: 'absolute',
                                right: '0px',
                                bottom: '-0px',
                                padding: '-75px 0 0 -100px'
                            }}
                            src={Icons.Imgobjects_02}
                        />

                        </Flex>
                    <Flex
                        mih={50}
                        // gap="sm"
                        justify="flex-center"
                        align="flex-center"
                        direction="column"
                        wrap="wrap"
                        className='text-bottom-section'
                    >
                        <Image
                            h={'480px'}
                            w={'480px'}
                            style={{
                                position: 'absolute',
                                right: '0px',
                                bottom: '-210px',
                                padding: '-75px 0 0 -100px'
                            }}
                            src={Icons.Imgobjects_03}
                        />
                        {/* <Text className='text-system-support'>System Support</Text>
                        <Text className='text-phone'>Ph - (+1)111-888-1234</Text>
                        <Text className='text-fax'>Fax - (+1)111-777-1234</Text> */}
                    </Flex>
                   
                    <Paper shadow="xs" className='login-form-paper'>
                        <div className='form-logo-section'>
                            <Group>
                                <Image
                                    h={'73px'}
                                    w={'70px'}
                                    src={Icons.ImgLogoPfizer}
                                />
                                <Image
                                    width={'300px'}
                                    height={'87px'}
                                    src={Icons.ImgLogoSuperAnalyst}
                                />
                            </Group>
                            <Group className='login-text'>
                                <Image
                                    src={Icons.ImgIconCredentialsSmall}
                                />
                                <Text className='text-login-account'>
                                    Login into Your Account
                                </Text>
                            </Group>
                        </div>
                        <form onSubmit={form.onSubmit((values) => handleLogin(values))} className='login-form'>
                            <Stack>
                                <TextInput
                                    required
                                    label="Email ID"
                                    placeholder="Email address"
                                    value={form.values.email}
                                    onChange={(event) => form.setFieldValue('email', event.currentTarget.value)}
                                    error={form.errors.email && 'Invalid email'}
                                    radius="md"
                                    style={{textAlign: 'left'}}
                                />
                                <PasswordInput
                                    required
                                    label="Password"
                                    placeholder="Your password"
                                    value={form.values.password}
                                    onChange={(event) => form.setFieldValue('password', event.currentTarget.value)}
                                    error={form.errors.password && 'Password should include at least 6 characters'}
                                    radius="md"
                                    style={{textAlign: 'left'}}
                                />
                            </Stack>
                            <Group justify="space-between" mt="xl">
                                <Anchor component="button" type="button" c="dimmed" onClick={() => toggle()} size="xs">
                                    {"Don't have an account? Register"}
                                </Anchor>
                                <Button type="submit" radius="sm" fullWidth className='btn-login'>
                                    {'Login'}
                                </Button>
                                <SingleSignOn handlers={handlers} />
                            </Group>
                        </form>
                    </Paper>
                </Grid.Col>
                <Grid.Col style={{ height: '100vh' }} span={{ base: 12, xs: 4 }}>
                    {/* <div className='text-copyright'>
                        <Text>2024 Copyrights © Pfizer</Text>
                    </div> */}
                </Grid.Col>
            </Grid>
        </StyleContainer>
    );
}

export default Login;