import { useEffect } from "react";
import { Button } from "@mantine/core"
import { useNavigate, useSearchParams } from 'react-router-dom';
import { getAuthTokenAction, validateAuthTokenAction } from "actions/Auth";
import { notifications } from "@mantine/notifications";
import classes from '../styles/AuthenticationImage.module.css';
import { Route_URL } from "utils/constants/RouteURL";

const SingleSignOn = (props: any) => {
    const { handlers } = props;

    const navigate = useNavigate()
    const [params, setParams] = useSearchParams();

    useEffect(() => {
        const code = params.get('code');
        if(code) {
            handlers.open();
            const response = getAuthTokenAction({code: code});
            response.then((resp: any) => {
                if(resp && resp.status && resp.status === 200) {
                    const respValidateTokenReq = validateAuthTokenAction({token: resp.data.access_token});
                    respValidateTokenReq.then((respToken: any) => {
                        localStorage.setItem('jwt_Token', JSON.stringify({'username': respToken.access_token.mail}));
                        notifications.show({
                            title: 'Success!!',
                            message: 'Login successfully!',
                            classNames: classes,
                        })
                        handlers.close();
                        navigate(Route_URL.dashboard)
                    });
                } else {
                    handlers.close();
                    notifications.show({
                        color: 'red',
                        title: 'Error!!',
                        message: 'Invalid code, please try again!',
                        classNames: classes,
                    })
                }
            });
        }
    }, [])
    
    const handleLoginWithSso = async() => {
        // console.log(`${process.env.REACT_APP_OAUTH_URL}?client_id=${process.env.REACT_APP_OAUTH_CLIENT_ID}&grant_type=${process.env.REACT_APP_OAUTH_GRANT_TYPE}&redirect_uri=${process.env.REACT_APP_BASE_URL}${process.env.REACT_APP_OAUTH_REDIRECT_URL}&response_type=code&scope=edit`);
        window.location.href=`${process.env.REACT_APP_OAUTH_URL}?client_id=${process.env.REACT_APP_OAUTH_CLIENT_ID}&grant_type=${process.env.REACT_APP_OAUTH_GRANT_TYPE}&response_type=code&redirect_uri=${process.env.REACT_APP_BASE_URL}${process.env.REACT_APP_OAUTH_REDIRECT_URL}`;
    }

    return (<>
    <Button type="button" radius="sm" fullWidth className='btn-login-sso' onClick={() => handleLoginWithSso()}>
        {'Login With SSO'}
    </Button>
    </>)
}

export default SingleSignOn