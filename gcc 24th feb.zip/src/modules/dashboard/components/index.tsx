import { useEffect, useState } from "react";
import { Group, Text, Stack, Paper, Button, Input, Accordion } from "@mantine/core"
import { useDisclosure } from '@mantine/hooks';
import { StyleContainer } from "../styles/Dashboard.styles"
import { Icons } from "assets/images"
import { CSVLink } from "react-csv";
import { useNavigate } from 'react-router-dom';
import PageHeader from "./PageHeader";
import { Route_URL } from "utils/constants/RouteURL";
import { getEventByIdV2Action, getEventDashboardAction, getIncidentByIdV2Action, getIncidentDashboardAction, getSearchEventsAction, getSearchIncidentsAction } from "actions/Dashboard";
import { IconSearch } from "@tabler/icons-react";
import TriageDetails from "./TriageDetails";
import classes from './Accordion.module.css'
import SliderFilter from "./SliderFilter";
import EventTable from "./EventTable";
import IncidentTable from "./IncidentTable";
import Filter from "./Filter";
import { getCurrPrevDaysformatDateTime } from "utils/Common";

const perPageLimit = 20;

const Dashboard = () => {
    const navigate = useNavigate()
    const [activeTab, setActiveTab] = useState<string | null>('events');
    const [selectedRows, setSelectedRows] = useState<number[]>([]);
    const [currPage, setCurrPage] = useState<number>(1);

    const [eventDetails, setEventDetails] = useState<any>([]);
    const [eventResponse, setEventResponse] = useState<any>({});
    const [incidentResponse, setIncidentResponse] = useState<any>({});
    const [eventPageNo, setEventPageNo] = useState<number>(1);
    const [incidentPageNo, setIncidentPageNo] = useState<number>(1);
    const [loadingEvents, setLoadingEvents] = useState<boolean>(false);
    const [incidentDetails, setIncidentDetails] = useState<any>([]);
    const [loadingIncidents, setLoadingIncidents] = useState<boolean>(false);
    const [eventPageSize, setEventPageSize] = useState<number>(20);
    const [incidentPageSize, setIncidentPageSize] = useState<number>(20);

    const [currPageIncidents, setCurrPageIncidents] = useState<number>(1);
    const [eventNum, setEventNum] = useState<string>('');
    const [rfcFilterValue, setRfcFilterValue] = useState<any>([
        getCurrPrevDaysformatDateTime(1, 0, 1),
        getCurrPrevDaysformatDateTime(0, 23, 59)
    ]);
    const [incidentFilterValue, setIncidentFilterValue] = useState<any>([
        getCurrPrevDaysformatDateTime(1, 0, 1),
        getCurrPrevDaysformatDateTime(0, 23, 59)
    ]);
    const [rfcIncFilterValue, setRfcIncFilterValue] = useState<any>([
        getCurrPrevDaysformatDateTime(1, 0, 1),
        getCurrPrevDaysformatDateTime(0, 23, 59)
    ]);
    const [incidentIncFilterValue, setIncidentIncFilterValue] = useState<any>([
        getCurrPrevDaysformatDateTime(1, 0, 1),
        getCurrPrevDaysformatDateTime(0, 23, 59)
    ]);
    // const [rfcIncFilterValue, setRfcIncFilterValue] = useState<number>(1);
    // const [incidentIncFilterValue, setIncidentIncFilterValue] = useState<number>(1);
    const [incidentNum, setIncidentNum] = useState<string>('');
    const [eventKeyword, setEventKeyword] = useState<string>('');
    const [incidentKeyword, setIncidentKeyword] = useState<string>('');
    const [listData, setListData] = useState<any>();
    const [visible, handlers] = useDisclosure(false);
    const [showPagination, setShowPagination] = useState<boolean>(false);
    const [showPaginationIncidents, setShowPaginationIncidents] = useState<boolean>(false);

    useEffect(() => {
        handleFetchEventList();
    }, [eventPageNo])

    useEffect(() => {
        handleFetchIncidentList();
    }, [incidentPageNo])

    const handleFetchEventList = () => {
        const trimmedEventNum = eventNum.trim(); // Ensure the value is trimmed
        if (trimmedEventNum === '' && eventKeyword === '') {
            setLoadingEvents(true);
            const responseEvents = getEventDashboardAction({ page: eventPageNo, per_page: eventPageSize });
            responseEvents.then((result: any) => {
                if(result && result.data) {
                    setEventDetails(result.data);
                }
                setEventResponse(result);
                setLoadingEvents(false);
            });
            return;
        }
        setLoadingEvents(true);
        const responseEvents = getSearchEventsAction({
            "search": {
                "query": eventKeyword || trimmedEventNum // Use trimmed value
            },
            "pagination": {
                "page": eventPageNo,
                "per_page": eventPageSize
            }
        });
        responseEvents.then((result: any) => {
            if (result && result.status === 404) {
                setLoadingEvents(false);
                setEventDetails([]);
                setEventResponse([]);
                return;
            }
            setEventDetails(result.data);
            setEventResponse(result);
            setLoadingEvents(false);
        });
    };
    
    const handleFetchIncidentList = () => {
        const trimmedIncidentNum = incidentNum.trim(); // Ensure the value is trimmed
        if (trimmedIncidentNum === '' && incidentKeyword === '') {
            setLoadingIncidents(true);
            const responseIncidents = getIncidentDashboardAction({ page: incidentPageNo, per_page: incidentPageSize });
            responseIncidents.then((result: any) => {
                if(result && result.data) {
                    setIncidentDetails(result.data);
                }
                setIncidentResponse(result);
                setLoadingIncidents(false);
            });
            return;
        }
        setLoadingIncidents(true);
        const responseIncidents = getSearchIncidentsAction({
            "search": {
                "query": incidentKeyword || trimmedIncidentNum // Use trimmed value
            },
            "pagination": {
                "page": incidentPageNo,
                "per_page": incidentPageSize
            }
        });
        responseIncidents.then((result: any) => {
            if (result && result.status === 404) {
                setLoadingIncidents(false);
                setIncidentDetails([]);
                setIncidentResponse([]);
                return;
            }
            setIncidentDetails(result.data);
            setIncidentResponse(result);
            setLoadingIncidents(false);
        });
    };
    
    const handleEventKeywordSearch = () => {
        setEventPageNo(1);
        handleFetchEventList();
    }

    const handleIncidentKeywordSearch = () => {
        setIncidentPageNo(1);
        handleFetchIncidentList();
    }

    const handleEventSearch = () => {
        setEventPageNo(1);
        if (eventNum === '') {
            setLoadingEvents(true);
            const responseEvents = getEventDashboardAction({ page: eventPageNo, per_page: eventPageSize });
            responseEvents.then((result: any) => {
                setEventDetails(result.data);
                setEventResponse(result);
                setLoadingEvents(false);
            });
            return;
        }
        setLoadingEvents(true);
        const responseEvents = getEventByIdV2Action({ event_input_id: eventNum });
        responseEvents.then((result: any) => {
            if (result && (result.status === 404 || result.status === 422)) {
                setLoadingEvents(false);
                setEventDetails([]);
                setEventResponse([]);
                return;
            }
            if (result && result.data) {
                setEventDetails([result.data]);
                setEventResponse(result);
            }
            setLoadingEvents(false);
        });
    }

    const handleIncidentSearch = () => {
        setIncidentPageNo(1);
        if (incidentNum === '') {
            setLoadingIncidents(true);
            const responseEvents = getIncidentDashboardAction({ page: incidentPageNo, per_page: incidentPageSize });
            responseEvents.then((result: any) => {
                setIncidentDetails(result.data);
                setIncidentResponse(result);
                setLoadingIncidents(false);
            });
            return;
        }
        setLoadingIncidents(true);
        const responseEvents = getIncidentByIdV2Action({ incident_input_id: incidentNum });
        responseEvents.then((result: any) => {
            if (result && result.status === 404) {
                setLoadingIncidents(false);
                setIncidentDetails([]);
                setIncidentResponse([]);
                return;
            }
            setIncidentDetails([result.data]);
            setIncidentResponse([result]);
            setLoadingIncidents(false);
        });
    }

    return (
        <StyleContainer fluid>
            {/* <LoadingOverlay loaderProps={{ color: '#000484' }} visible={visible} zIndex={1000} overlayProps={{ radius: "sm", blur: 2 }} /> */}
            <PageHeader />
            <Paper className="paperTbl">
                <Accordion chevronPosition="right" variant="contained" pt={5} transitionDuration={200} classNames={classes} defaultValue={'event_list'}>
                    <Accordion.Item value={'event_list'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <div>
                                    <Group wrap="nowrap">
                                        <Text fw={600}>{'Event List'}</Text>
                                    </Group>
                                </div>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <Paper className="filterSection" mb={10} pt={0}>
                                <Group justify="center">
                                    <Stack
                                        align="stretch"
                                        justify="center"
                                        gap="0"
                                    >
                                        {/* <Text className="tableTitle">Events List</Text> */}
                                        {/* <Text size="sm" className="tableSubTitle">Server Potential Issues</Text> */}
                                    </Stack>
                                    <Group mb={10}>
                                        <Filter
                                            setRfcFilterValue={setRfcFilterValue}
                                            rfcFilterValue={rfcFilterValue}
                                            incidentFilterValue={incidentFilterValue}
                                            setIncidentFilterValue={setIncidentFilterValue}
                                        />
                                        {/* <SliderFilter 
                                            rfcFilterValue={rfcFilterValue} 
                                            setRfcFilterValue={setRfcFilterValue} 
                                            incidentFilterValue={incidentFilterValue} 
                                            setIncidentFilterValue={setIncidentFilterValue} 
                                        /> */}
                                        <Group justify="center" style={{ paddingTop: '20px' }}>
                                            <Input placeholder="Search By Keyword" mr={'-20px'} maw={145} value={eventKeyword} onKeyDown={event => { event.key === 'Enter' && handleEventKeywordSearch() }} onChange={(event: any) => setEventKeyword(event.currentTarget.value)} disabled={loadingEvents} />
                                            <Button onClick={() => { handleEventKeywordSearch() }} disabled={loadingEvents}><IconSearch size={18} /></Button>
                                        </Group>
                                        <Group justify="center" style={{ paddingTop: '20px' }}>
                                            <Input placeholder="Search By Event ID" mr={'-20px'} maw={145} value={eventNum} onKeyDown={event => { event.key === 'Enter' && handleEventSearch() }} onChange={(event: any) => setEventNum(event.currentTarget.value.trim())} disabled={loadingEvents} />
                                            <Button onClick={() => { handleEventSearch() }} disabled={loadingEvents}><IconSearch size={18} /></Button>
                                        </Group>
                                        {/* <CSVLink data={listData ?? ''} filename="device_overview">
                                    <Image
                                        src={Icons.Imgicon_dowload_sm}
                                    />
                                </CSVLink> */}
                                        {/* <Image
                            src={Icons.Imgicon_3_dots_options}
                            onClick={() => { }}
                        /> */}
                                    </Group>
                                </Group>
                            </Paper>
                            <EventTable currPage={eventPageNo} setCurrPage={setEventPageNo} pageSize={eventPageSize} setPageSize={setEventPageSize} totalRecords={eventResponse && eventResponse.total_records ? eventResponse.total_records : 0} data={eventDetails} fetching={loadingEvents} rfcFilterValue={rfcFilterValue} incidentFilterValue={incidentFilterValue} />
                        </Accordion.Panel>
                    </Accordion.Item>
                    <Accordion.Item value={'incident_list'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <div>
                                    <Group wrap="nowrap">
                                        <Text fw={600}>{'Incident List'}</Text>
                                    </Group>
                                </div>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <Paper className="filterSection" mb={10} pt={0}>
                                <Group justify="center">
                                    <Stack
                                        align="stretch"
                                        justify="center"
                                        gap="0"
                                    >
                                        {/* <Text className="tableTitle">Incidents List</Text> */}
                                        {/* <Text size="sm" className="tableSubTitle">Server Potential Issues</Text> */}
                                    </Stack>
                                    <Group mb={10}>
                                        {/* <Button type="button" variant="filled" rightSection={<IconPlus size={14} />} className="btnCreate" onClick={() => {}}>Create</Button> */}
                                        <Filter
                                            setRfcFilterValue={setRfcIncFilterValue}
                                            rfcFilterValue={rfcIncFilterValue}
                                            incidentFilterValue={incidentIncFilterValue}
                                            setIncidentFilterValue={setIncidentIncFilterValue}
                                        />
                                        {/* <SliderFilter rfcFilterValue={rfcIncFilterValue} setRfcFilterValue={setRfcIncFilterValue} incidentFilterValue={incidentIncFilterValue} setIncidentFilterValue={setIncidentIncFilterValue} /> */}
                                        <Group justify="center" style={{ paddingTop: '25px' }}>
                                            <Input placeholder="Search By Keyword" mr={'-20px'} maw={145}
                                                onKeyDown={event => { event.key === 'Enter' && handleIncidentKeywordSearch() }}
                                                onChange={(event: any) => setIncidentKeyword(event.currentTarget.value)}
                                                disabled={loadingIncidents}
                                            />
                                            <Button onClick={() => { handleIncidentKeywordSearch() }} disabled={loadingIncidents}><IconSearch size={18} /></Button>
                                        </Group>
                                        <Group justify="center" style={{ paddingTop: '25px' }}>
                                        <Input 
                                            placeholder="Search by Incident ID" 
                                            mr={'-20px'} 
                                            maw={145}
                                            onKeyDown={event => { 
                                                event.key === 'Enter' && handleIncidentSearch(); 
                                            }}
                                            onChange={(event: any) => setIncidentNum(event.currentTarget.value.trim())}  /* Trim spaces */
                                            disabled={loadingIncidents}
                                        />

                                            <Button onClick={() => { handleIncidentSearch() }} disabled={loadingIncidents}><IconSearch size={18} /></Button>
                                        </Group>
                                        {/* <CSVLink data={listData ?? ''} filename="device_overview">
                                        <Image
                                            src={Icons.Imgicon_dowload_sm}
                                        />
                                    </CSVLink> */}
                                    </Group>
                                </Group>
                            </Paper>
                            <IncidentTable currPage={incidentPageNo} setCurrPage={setIncidentPageNo} pageSize={incidentPageSize} setPageSize={setIncidentPageSize} totalRecords={incidentResponse && incidentResponse.total_records ? incidentResponse.total_records : 0} data={incidentDetails} fetching={loadingIncidents} rfcFilterValue={rfcIncFilterValue} incidentFilterValue={incidentIncFilterValue} />
                        </Accordion.Panel>
                    </Accordion.Item>
                </Accordion>
                {/* <TriageDetails /> */}
            </Paper>
        </StyleContainer>
    )
}

export default Dashboard