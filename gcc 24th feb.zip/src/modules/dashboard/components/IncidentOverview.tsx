import { useEffect, useState } from "react";
import {
    Button,
    Group,
    LoadingOverlay,
    Paper
} from "@mantine/core";
import { useDisclosure } from '@mantine/hooks';
import { useSearchParams } from 'react-router-dom';
import { StyleContainer } from "../styles/Dashboard.styles";
import PageHeader from "./PageHeader";
import CommonOverview from "./CommonOverview";
import { IconSearch } from "@tabler/icons-react";
import SliderFilter from "./SliderFilter";
import Filter from "./Filter";
import { formatFilterDateTime, getCurrPrevDaysformatDateTime } from "utils/Common";

const IncidentOverview = () => {
    const [searchParams] = useSearchParams();
    let paramFromQuery = searchParams.get('eventTitle');
    const eventId = searchParams.get('eventId');
    const periodFilter = searchParams.get('period');
    const rfcFilter = searchParams.get('rfc_filter');
    const incidentFilter = searchParams.get('incident_filter');
    let eventTitle = '';
    if(paramFromQuery) {
        paramFromQuery = paramFromQuery.toString().replace(/%/g,'~~pct~~');       // ~~pct~~ <-made up replacement
        paramFromQuery = encodeURI(paramFromQuery);
        const hashFragment = window.location.hash.slice(1); // Get the part after the '#';
        const decodedHashFragment = decodeURIComponent(hashFragment);
        const decodedParamFromQuery = paramFromQuery ? decodeURIComponent(paramFromQuery) : '';
        // Combine both
        let combinedParam = decodedParamFromQuery + (decodedHashFragment ? `#${decodedHashFragment}` : '');
        combinedParam = decodeURI(combinedParam);
        combinedParam = combinedParam.toString().replace(/~~pct~~/g,'%'); 
        eventTitle = combinedParam;
    }
    const [eventListDetails, setEventListDetails] = useState<any>();
    const [visible, handlers] = useDisclosure(false);
    const [rfcFilterValue, setRfcFilterValue] = useState<any>(rfcFilter ? formatFilterDateTime(rfcFilter) : [
        getCurrPrevDaysformatDateTime(1, 0, 1),
        getCurrPrevDaysformatDateTime(0, 23, 59)
    ]);
    const [incidentFilterValue, setIncidentFilterValue] = useState<any>(incidentFilter ? formatFilterDateTime(incidentFilter) : [
        getCurrPrevDaysformatDateTime(1, 0, 1),
        getCurrPrevDaysformatDateTime(0, 23, 59)
    ]);
    const [filterValueTotal, setFilterValueTotal] = useState<number>(1);
    const [loadingOverview, setLoadingOverview] = useState<boolean>(false);

    const [incidentFilterShowValue, setIncidentFilterShowValue] = useState<any>(incidentFilter ? (incidentFilter) : '');
    const [rfcFilterShowValue, setRfcFilterShowValue] = useState<any>(rfcFilter ? rfcFilter : '');
    
    useEffect(() => {
        setFilterValueTotal(filterValueTotal+1);
    }, [])

    const handleGetTriage = () => {
        setFilterValueTotal(filterValueTotal+1);
        setIncidentFilterShowValue(incidentFilterValue);
        setRfcFilterShowValue(rfcFilterValue);
    }

    return (
        <StyleContainer fluid>
            <LoadingOverlay style={{ position: 'fixed' }} loaderProps={{ color: '#000484' }} visible={visible} zIndex={1000} overlayProps={{ radius: "sm", blur: 2, children: 'Loading....' }} />
            <div className="pagefixedd" style={{
                position: "fixed", zIndex: 10, width: "calc(100% - 62px)",
                backgroundColor: "#FFFFFF", boxShadow: "2px 13px 54px #695F9714",

                // borderRadius: "8px",
                padding: "5px 20px 10px 20px", margin: "-11px 20px 0px 10px",
                borderTop: "1px solid #CCC"
            }}><PageHeader style={{ position: 'fixed' }} title={`Incident Overview - ${eventId}`} subTitle={eventTitle} /></div>

            <div style={{ marginTop: "68px" }}>
                <Paper className="paperTbl">
                <Group justify="center">
                    <Group wrap="nowrap">
                        <Filter
                            setRfcFilterValue={setRfcFilterValue}
                            rfcFilterValue={rfcFilterValue}
                            setIncidentFilterValue={setIncidentFilterValue}
                            incidentFilterValue={incidentFilterValue}
                        />
                            {/* <SliderFilter
                                rfcFilterValue={rfcFilterValue} 
                                setRfcFilterValue={setRfcFilterValue}
                                rfcFilterShowValue={rfcFilterShowValue}
                                incidentFilterValue={incidentFilterValue} 
                                setIncidentFilterValue={setIncidentFilterValue}
                                incidentFilterShowValue={incidentFilterShowValue} 
                                setIncidentFilterShowValue={setIncidentFilterShowValue} /> */}

                        {/* <SliderFilter rfcFilterValue={rfcFilterValue} setRfcFilterValue={setRfcFilterValue} incidentFilterValue={incidentFilterValue} setIncidentFilterValue={setIncidentFilterValue} /> */}
                        <Button mt={25} type="button" variant="filled" rightSection={<IconSearch size={14} />} className="" onClick={() => { handleGetTriage() }} loading={loadingOverview} loaderProps={{type: 'dots'}}>Search</Button>
                    </Group>
                </Group>
            </Paper>
            <CommonOverview
                filterValueTotal={filterValueTotal}
                overviewType="INCIDENT"
                eventListDetails={eventListDetails}
                eventId={eventId}
                subTitle={eventTitle}
                handleGetTriage={() => handleGetTriage()}
                rfcFilterValue={rfcFilterValue}
                rfcFilterShowValue={rfcFilterShowValue}
                incidentFilterValue={incidentFilterValue}
                incidentFilterShowValue={incidentFilterShowValue}
                setLoadingOverview={setLoadingOverview}
            />
            </div>
        </StyleContainer>
    )
}

export default IncidentOverview;