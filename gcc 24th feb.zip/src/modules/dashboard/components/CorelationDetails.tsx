import { useEffect, useState } from "react";
import {
    Paper, Table,
    Anchor, LoadingOverlay,
    Group,
    Stack, Text,
    Image,
    Avatar,
    ScrollArea,
    Select, Accordion,
    Button,
    Tooltip,
    Highlight,
    Input,
    Title,
    TypographyStylesProvider,
    Card,
    List,
    ThemeIcon,
    rem
} from "@mantine/core";
import { useDisclosure } from '@mantine/hooks';
import { useParams, useSearchParams } from 'react-router-dom';
import { StyleContainer } from "../styles/Dashboard.styles";
import classes from '../../login/styles/AuthenticationImage.module.css';
import PageHeader from "./PageHeader";
import { Icons } from "assets/images";
import { getCorelationAction, getSemanticSearchAction } from "actions/Dashboard";
import reactStringReplace from "react-string-replace";
import { IconCircleCheck, IconCircleDashed, IconInfoCircle, IconSearch } from "@tabler/icons-react";
import moment from "moment";
import { notifications } from "@mantine/notifications";

interface AccordionLabelProps {
    label: string;
    image: string;
    description: string;
}

function AccordionLabel({ label, image, description }: AccordionLabelProps) {
    return (
        <Group wrap="nowrap">
            {/* <Avatar radius="xl" size="lg">
            <IconRobot size={1} />
        </Avatar> */}
            <div>
                <Text>{label}</Text>
                <Text size="sm" c="dimmed" fw={400}>
                    {description}
                </Text>
            </div>
        </Group>
    );
}

const regx = /(?=.)(.*)(?<=:)/gim;

const CorelationDetails = () => {
    const [searchParams] = useSearchParams();
    const eventTitle = searchParams.get('eventTitle');
    const [selectedRows, setSelectedRows] = useState<number[]>([]);
    const [searchText, setSearchText] = useState<string>('');
    const [filterEventId, setFilterEventId] = useState<string>('');
    const [filterNetwork, setFilterNetwork] = useState<string | null>('');
    const [filterLocation, setFilterLocation] = useState<string>('');
    const [filterType, setFilterType] = useState<string>('');
    const [eventListDetails, setEventListDetails] = useState<any>();
    const [visible, handlers] = useDisclosure(false);

    const handleEventSearch = () => {
        if (filterEventId) {
            handlers.open();
            const payload = { 
                "number": filterEventId,
                "NETWORK_NAME": filterNetwork,
                "LOCATION": filterLocation,
                "TYPE": filterType
            }
            const response = getSemanticSearchAction(payload);
            response.then((result: any) => {
                setEventListDetails(result);
                handlers.close();
            });
        } else {
            notifications.show({
                color: 'red',
                title: 'Error!!',
                message: 'Please enter Event ID!',
                classNames: classes,
            })
        }
    }

    const rowsIncidents = eventListDetails && eventListDetails.incidents_table && eventListDetails.incidents_table.length > 0 && eventListDetails.incidents_table.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{ textAlign: 'left' }}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['NETWORK_NAME']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
            <Table.Td>{element['TYPE']}</Table.Td>
            <Table.Td>{Number(element['Similarity']).toFixed(2)}</Table.Td>
        </Table.Tr>
    ));

    const rowsEvents = eventListDetails && eventListDetails.events_table && eventListDetails.events_table.length > 0 && eventListDetails.events_table.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{ textAlign: 'left' }}
        >
            <Table.Td>{element['event_id']}</Table.Td>
            <Table.Td>{element['event_title']}</Table.Td>
            <Table.Td>{element['NETWORK_NAME']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
            <Table.Td>{element['TYPE']}</Table.Td>
            <Table.Td>{Number(element['Similarity']).toFixed(2)}</Table.Td>
        </Table.Tr>
    ));

    const rowsRfcs = eventListDetails && eventListDetails.rfcs_table && eventListDetails.rfcs_table.length > 0 && eventListDetails.rfcs_table.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{ textAlign: 'left' }}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['STATUS']}</Table.Td>
            <Table.Td>{element['OPEN_TIME']}</Table.Td>
            <Table.Td>{element['ASSIGN_DEPT']}</Table.Td>
            <Table.Td>{element['TYPE']}</Table.Td>
            <Table.Td>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
            <Table.Td>{element['NETWORK_NAME']}</Table.Td>
            <Table.Td>{element['text']}</Table.Td>
            <Table.Td>{element['embedding']}</Table.Td>
            <Table.Td>{Number(element['Similarity']).toFixed(2)}</Table.Td>
        </Table.Tr>
    ));

    return (
        <StyleContainer fluid>
            <LoadingOverlay loaderProps={{ color: '#000484' }} visible={visible} zIndex={1000} overlayProps={{ radius: "sm", blur: 2, children: 'Loading....' }} />
            <PageHeader title={'Correlation Details'} subTitle={eventTitle} />
            <Paper className="paperTbl">
                <Group justify="center">
                    <Stack
                        align="stretch"
                        justify="center"
                        gap="0"
                    >
                        <Group justify="">
                        </Group>
                    </Stack>
                    <Group wrap="nowrap">
                        <Group justify="center">
                            <Input.Wrapper label="NUMBERPRGN/Event ID" description="" error="" required>
                                <Input w={'170px'} placeholder="NUMBERPRGN/Event ID" onChange={(event: any) => setFilterEventId(event.currentTarget.value)} />
                            </Input.Wrapper>
                        </Group>
                    </Group>
                    <Group wrap="nowrap">
                        <Group justify="center">
                            <Input.Wrapper label="NETWORK NAME" description="" error="">
                                <Input w={'170px'} placeholder="Enter NETWORK NAME" onChange={(event: any) => setFilterNetwork(event.currentTarget.value)} />
                            </Input.Wrapper>
                        </Group>
                    </Group>
                    <Group wrap="nowrap">
                        <Group justify="center">
                            <Input.Wrapper label="Location" description="" error="">
                                <Input w={'170px'} placeholder="Enter Location" onChange={(event: any) => setFilterLocation(event.currentTarget.value)} />
                            </Input.Wrapper>
                        </Group>
                    </Group>
                    <Group wrap="nowrap">
                        <Group justify="center">
                            <Input.Wrapper label="Type" description="" error="">
                                <Input w={'170px'} placeholder="Enter Type" onChange={(event: any) => setFilterType(event.currentTarget.value)} />
                            </Input.Wrapper>
                        </Group>
                    </Group>
                    <Button mt={20} onClick={() => { handleEventSearch() }}>Search</Button>
                </Group>
            </Paper>
            {eventListDetails && Object.keys(eventListDetails).length > 0 &&
                <>
                    <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                        <ScrollArea h={200}>
                            <Text fw={700}>Description:</Text>
                            <div style={{ whiteSpace: "pre-line" }}>
                                {eventListDetails && eventListDetails.input_description &&
                                    reactStringReplace(eventListDetails.input_description, regx, (match: any, i) => (
                                        <strong>
                                            {match}
                                        </strong>
                                    ))
                                }
                            </div>
                        </ScrollArea>
                    </Paper>
                    <Accordion chevronPosition="right" variant="contained" pt={10}>
                        <Accordion.Item value={'acc_incidents'}>
                            <Accordion.Control>
                                <AccordionLabel label='Incidents' image='' description="Incidents based on Event ID" />
                            </Accordion.Control>
                            <Accordion.Panel>
                                <Table.ScrollContainer minWidth={500}>
                                    <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable"
                                        style={{ whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden' }}
                                    >
                                        <Table.Thead style={{ position: 'static' }}>
                                            <Table.Tr>
                                                <Table.Th>NUMBERPRGN</Table.Th>
                                                <Table.Th>BRIEF_DESCRIPTION</Table.Th>
                                                <Table.Th>NETWORK_NAME</Table.Th>
                                                <Table.Th>LOCATION</Table.Th>
                                                <Table.Th>TYPE</Table.Th>
                                                <Table.Th>Similarity</Table.Th>
                                            </Table.Tr>
                                        </Table.Thead>
                                        <Table.Tbody>{rowsIncidents ? rowsIncidents : 'No record found for the selected Event ID'}</Table.Tbody>
                                    </Table>
                                </Table.ScrollContainer>
                            </Accordion.Panel>
                        </Accordion.Item>
                        <Accordion.Item value={'acc_events'}>
                            <Accordion.Control>
                                <AccordionLabel label='Events' image='' description="Events based on Event ID" />
                            </Accordion.Control>
                            <Accordion.Panel>
                                <Table.ScrollContainer minWidth={500}>
                                    <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{ whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden' }}>
                                        <Table.Thead style={{ position: 'static' }}>
                                            <Table.Tr>
                                                <Table.Th>event_id</Table.Th>
                                                <Table.Th>event_title</Table.Th>
                                                <Table.Th>NETWORK_NAME</Table.Th>
                                                <Table.Th>LOCATION</Table.Th>
                                                <Table.Th>TYPE</Table.Th>
                                                <Table.Th>Similarity</Table.Th>
                                            </Table.Tr>
                                        </Table.Thead>
                                        <Table.Tbody>{rowsEvents ? rowsEvents : 'No Record Found for the selected Event ID.'}</Table.Tbody>
                                    </Table>
                                </Table.ScrollContainer>
                            </Accordion.Panel>
                        </Accordion.Item>
                        <Accordion.Item value={'acc_rfcs'}>
                            <Accordion.Control>
                                <AccordionLabel label='RFCS' image='' description="Rfcs based on Event ID" />
                            </Accordion.Control>
                            <Accordion.Panel>
                                <Table.ScrollContainer minWidth={500}>
                                    <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{ whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden' }}>
                                        <Table.Thead style={{ position: 'static' }}>
                                            <Table.Tr>
                                                <Table.Th>NUMBERPRGN</Table.Th>
                                                <Table.Th>STATUS</Table.Th>
                                                <Table.Th>OPEN_TIME</Table.Th>
                                                <Table.Th>ASSIGN_DEPT</Table.Th>
                                                <Table.Th>TYPE</Table.Th>
                                                <Table.Th>BRIEF_DESCRIPTION</Table.Th>
                                                <Table.Th>LOCATION</Table.Th>
                                                <Table.Th>NETWORK_NAME</Table.Th>
                                                <Table.Th>Text</Table.Th>
                                                <Table.Th>Embedding</Table.Th>
                                                <Table.Th>Similarity</Table.Th>
                                            </Table.Tr>
                                        </Table.Thead>
                                        <Table.Tbody>{rowsRfcs ? rowsRfcs : 'No Record Found for the selected Event ID.'}</Table.Tbody>
                                    </Table>
                                </Table.ScrollContainer>
                            </Accordion.Panel>
                        </Accordion.Item>
                    </Accordion>
                </>
            }
        </StyleContainer>
    )
}

export default CorelationDetails;