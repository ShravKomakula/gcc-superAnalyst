'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { Text, Paper, Skeleton, Anchor } from '@mantine/core';
import { sortBy } from 'lodash'
import { DataTable } from 'mantine-datatable';
import classes from '../styles/Table.styles.module.css';
import 'mantine-datatable/styles.css';
import { formatDateTime } from 'utils/Common';
import { CONFIGURATIONS } from 'utils/constants/configurations';

const PAGE_SIZES = [5, 10, 15, 20];

const CiBasedProblemTasks = (props: any) => {
    const { data, fetching } = props;
    const key = 'resize-complex-example';

    // const initialRecords = data && data.slice(0, PAGE_SIZE);

    const [sortStatus, setSortStatus] = useState<any>({
        columnAccessor: '',
        direction: '',
    });

    const [pageSize, setPageSize] = useState(PAGE_SIZES[0]);
    const [currPage, setCurrPage] = useState(1);
    const [records, setRecords] = useState<string[]>([]);
    const [latestRecords, setLatestRecords] = useState<string[]>([]);

    useEffect(() => {
        if(data && data.length > 0) {
            setRecords(data.slice(0, pageSize));
            setLatestRecords(data);
        }
    }, [data])

    useEffect(() => {
        const dataTmp = sortBy(latestRecords, sortStatus.columnAccessor);
        if(dataTmp && dataTmp.length > 0) {
            const sortData = sortStatus.direction === 'desc' ? dataTmp.reverse() : dataTmp;
            setLatestRecords(sortData);
            setRecords(sortData.slice(0, pageSize));
        }
    }, [sortStatus]);

    useEffect(() => {
        const from = (currPage - 1) * pageSize;
        const to = from + pageSize;
        if(latestRecords) {
            setRecords(latestRecords.slice(from, to));
        }
    }, [currPage, pageSize]);

    return (
        <Skeleton visible={fetching}>
        <Paper className="paperTbl">
            <Text
                size="lg"
                fw={700}
                // c={'red'}
                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                pb={10}
            >
                CI Based Problem Tasks
            </Text>
            <DataTable
                // height="70dvh"
                minHeight={200}
                maxHeight={1000}
                withTableBorder
                highlightOnHover
                borderRadius="sm"
                withColumnBorders
                striped
                verticalAlign="top"
                pinLastColumn
                horizontalSpacing="xs"
                verticalSpacing="xs"
                fz="sm"
                records={records}
                classNames={{
                    // header: classes.header,
                }}
                storeColumnsKey={key}
                columns={[
                    {
                        accessor: 'id',
                        title: 'Id',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'parent_problem', title: 'Parent Problem',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'open_time', title: 'Open Time',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ open_time }: any) => formatDateTime(open_time),
                    },
                    {
                        accessor: 'status', title: 'Status',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'assignment', title: 'Assignment',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'logical_name', title: 'Logical Name',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ logical_name }: any) => <Anchor href={`${CONFIGURATIONS.CI_LINK}${logical_name}`} target="_blank">
                        {logical_name}
                    </Anchor>,
                    },
                    {
                        accessor: 'brief_description', title: 'Brief Description',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    }
                ]}
                totalRecords={data && data.length}
                recordsPerPage={pageSize}
                page={currPage}
                fetching={fetching}
                onPageChange={(p) => setCurrPage(p)}
                recordsPerPageOptions={PAGE_SIZES}
                onRecordsPerPageChange={setPageSize}
                sortStatus={sortStatus}
                onSortStatusChange={setSortStatus}
                // 👇 uncomment the next line to use a custom pagination size
                // paginationSize="md"
                // 👇 uncomment the next line to use a custom loading text
                loadingText="Loading..."
                // 👇 uncomment the next line to display a custom text when no records were found
               emptyState={
                    <div style={{ textAlign: 'center', padding: '20px' }}>
                        <Text>No Results Found</Text>
                    </div>
                }
                noRecordsText=""
            // 👇 uncomment the next line to use a custom pagination text
                paginationText={({ from, to, totalRecords }) => `Records ${from} - ${to} of ${totalRecords}`}
            // 👇 uncomment the next lines to use custom pagination colors
                // paginationActiveBackgroundColor="green"
                // paginationActiveTextColor="#e6e348"
            />
        </Paper>
        </Skeleton>
    );
}

export default React.memo(CiBasedProblemTasks);