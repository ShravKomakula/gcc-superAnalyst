import { useState } from "react";
import { Accordion, Badge, Group, List, Paper, ThemeIcon, rem, Text, Skeleton, Container } from "@mantine/core";
import { IconCircleCheck } from "@tabler/icons-react";
import { notifications } from "@mantine/notifications";
import PossibleRelatedRecords from "./PossibleRelatedRecords";
import RecommendedTeamEngagement from "./RecommendedTeamEngagement";
import classes from '../Accordion.module.css'
import FeedbackForm from "../FeedbackForm";
import { submitCorrelationFeedbackAction } from "actions/Dashboard";

const ProbabaleRootCauseSection = (props: any) => {
    const [feedbackLoading, setFeedbackLoading] = useState<boolean>(false);
    const { triageDetails, summaryData, fetching, handleRefreshAction, eventId } = props;

    const handlePrcReviewSubmit = (isPositive: boolean, feedback: string = '', togglePopover: any, reason: string = '') => {
        const llmResp = summaryData.llm_prc.map((llm: any) => { return llm.Title } );
        handleCorrSubmitReview(isPositive, feedback, togglePopover, 'rca', llmResp, reason); 
    }

    const handleCorrSubmitReview = (isPositive: boolean, feedback: string = '', togglePopover: any, tabType: string, llmResponse: string, reason: string = '') => {
        const localStorageData = localStorage.getItem('jwt_Token') ?? null;
        if(localStorageData) {
            setFeedbackLoading(true);
            const userInfo = JSON.parse(localStorageData);
            const fullname = userInfo.username;
            const responseEvents = submitCorrelationFeedbackAction({
                "tab_type": tabType,
                "llm_response": llmResponse,
                "is_positive": isPositive,
                "text_feedback": feedback,
                "reason": reason,
                "id": eventId
            });
            responseEvents.then((result: any) => {
                if(result) {
                    if(isPositive === false) {
                        togglePopover(false);
                    }
                    notifications.show({
                        color: 'green',
                        title: 'Success!!',
                        message: 'Thanks for submitting your Review, Your review has been submitted.',
                        classNames: classes,
                    })
                } else {
                    notifications.show({
                        color: 'red',
                        title: 'Error!!',
                        message: 'There is some issue, please try again!',
                        classNames: classes,
                    })
                }
                setFeedbackLoading(false);
            });
        }
    }

    return (
        <Skeleton visible={fetching}>
            <Container fluid mih={30}>
                <Accordion chevronPosition="right" variant="contained" transitionDuration={200} bg={'white'} classNames={classes}>
                    {summaryData && summaryData.llm_prc && summaryData.llm_prc.length > 0 && summaryData.llm_prc.map((llmPrc: any, index: number) => {
                        return (
                            <Accordion.Item value={llmPrc.Title}>
                                <Accordion.Control>
                                    {/* <Card shadow="sm" padding="sm" pt={5} radius="md" style={{ textAlign: 'justify' }} tabIndex={index}> */}
                                    <Group justify="space-between" mt="5" mb={0}>
                                        <Text fw={500}>{llmPrc.Title}</Text>
                                        {/* <Badge variant="dot" color={'green'} size="lg">{llmPrc.likelihood}% Likelihood</Badge> */}
                                        <Badge variant="dot" color={llmPrc.likelihood >= 90 ? 'green' : (llmPrc.likelihood < 90 && llmPrc.likelihood >= 60 ? 'yellow' : (llmPrc.likelihood < 60 && llmPrc.likelihood >= 40 ? 'orange' : 'grey'))} size="lg">{llmPrc.likelihood}% Confidence</Badge>
                                    </Group>
                                    {/* </Card> */}
                                </Accordion.Control>
                                <Accordion.Panel>
                                    <PossibleRelatedRecords data={llmPrc && llmPrc.Possible_Related_Record && Array.isArray(llmPrc.Possible_Related_Record) ? llmPrc.Possible_Related_Record : []} fetching={fetching} />
                                    <RecommendedTeamEngagement data={llmPrc && llmPrc.Recommended_Team_Engagement && Array.isArray(llmPrc.Recommended_Team_Engagement) ? llmPrc.Recommended_Team_Engagement : []} fetching={fetching} />
                                    <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                                        <Text
                                            size="lg"
                                            fw={700}
                                            // c={'green'}
                                            style={{ textDecoration: 'underline', textAlign: 'justify' }}
                                            pb={10}
                                        >
                                            Recommended Remediation Steps
                                        </Text>
                                        {llmPrc && llmPrc.Recommended_Remediation_Steps && llmPrc.Recommended_Remediation_Steps.length > 0 && llmPrc.Recommended_Remediation_Steps.map((element: any, index: number) => {
                                            return (
                                                <List
                                                    spacing="xs"
                                                    size="sm"
                                                    center
                                                    icon={
                                                        <ThemeIcon color="teal" size={24} radius="xl">
                                                            <IconCircleCheck style={{ width: rem(16), height: rem(16) }} />
                                                        </ThemeIcon>
                                                    }
                                                >
                                                    <List.Item p={5}>{element}</List.Item>
                                                </List>
                                            )
                                        })
                                        }
                                    </Paper>
                                </Accordion.Panel>
                            </Accordion.Item>
                        )
                    })
                    }
                    { !fetching &&
                        <FeedbackForm loading={feedbackLoading} handleReviewSubmit={handlePrcReviewSubmit} handleRefreshAction={handleRefreshAction} />
                    }
                </Accordion>
            </Container>
        </Skeleton>
    )
}

export default ProbabaleRootCauseSection;