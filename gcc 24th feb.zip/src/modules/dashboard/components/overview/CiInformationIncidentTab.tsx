
import React, { useEffect, useState } from "react";
import { getCiCiInformationAction, getCiInformationAction, getEventCiInformationAction } from "actions/Dashboard";
import { Text, Skeleton, Tabs, Paper } from "@mantine/core";
import CiInfo from "./CiInfo";
import Downstream from "./Downstream";
import Upstream from "./Upstream";
import InfraStructureDependencies from "./InfraStructureDependencies";

const CiInformationIncidentTab = (props: any) => {
    const { reqId, overviewType, filterValueTotal } = props;
    const [activeTab, setActiveTab] = useState<string | null>('ciinfo');
    const [loading, setLoading] = useState<boolean>(false);
    const [detail, setDetail] = useState<any>({});


    useEffect(() => {
        handleGetCiInformation();
    }, [filterValueTotal])

    const handleGetCiInformation = () => {
        if(overviewType === 'INCIDENT') {
            setLoading(true);
            const responseEvents = getCiInformationAction({
                "numberprgn": reqId
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data) {
                    setDetail(result.data);
                }
                setLoading(false);
            });
        } else if(overviewType === 'CI') {
            setLoading(true);
            const responseEvents = getCiCiInformationAction({
                "numberprgn": reqId
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data) {
                    setDetail(result.data);
                }
                setLoading(false);
            });
        } else {
            setLoading(true);
            const responseEvents = getEventCiInformationAction({
                "numberprgn": reqId
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data) {
                    setDetail(result.data);
                }
                setLoading(false);
            });
        }
    }

    return (
        <React.Fragment>
            <Skeleton visible={loading}>
                <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                    <Tabs value={activeTab} onChange={setActiveTab} variant="outline">
                        <Tabs.List>
                            <Tabs.Tab value="ciinfo" leftSection={''}>
                                <Text fw={500} c={activeTab === 'ciinfo' ? 'grey' : 'black'}>CI Info</Text>
                            </Tabs.Tab>
                            <Tabs.Tab value="downstream" leftSection={''}>
                                <Text fw={500} c={activeTab === 'downstream' ? 'grey' : 'black'}>Downstream</Text>
                            </Tabs.Tab>
                            <Tabs.Tab value="upstream" leftSection={''}>
                                <Text fw={500} c={activeTab === 'upstream' ? 'grey' : 'black'}>Upstream</Text>
                            </Tabs.Tab>
                            <Tabs.Tab value="InfraStructureDependencies" leftSection={''}>
                                <Text fw={500} c={activeTab === 'InfraStructureDependencies' ? 'grey' : 'black'}>Infrastructure Dependencies</Text>
                            </Tabs.Tab>
                        </Tabs.List>
                        <Tabs.Panel value="ciinfo">
                            <CiInfo detail={detail && detail.ci_info} />                
                        </Tabs.Panel>
                        <Tabs.Panel value="downstream">
                            <Downstream data={detail && detail.downstream ? detail.downstream : []} fetching={loading} />
                        </Tabs.Panel>
                        <Tabs.Panel value="upstream">
                            <Upstream data={detail && detail.upstream ? detail.upstream : []} fetching={loading} />
                        </Tabs.Panel>
                        <Tabs.Panel value="InfraStructureDependencies">
                            <InfraStructureDependencies data={detail && detail.infrastructure_dependencies ? detail.infrastructure_dependencies : []} fetching={loading} />
                        </Tabs.Panel>
                    </Tabs>
                </Paper>
            </Skeleton>
        </React.Fragment>
    )
}

export default CiInformationIncidentTab;