'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { ActionIcon, Anchor, Button, Checkbox, Group, MultiSelect, Stack, Switch, TextInput, Text, Paper } from '@mantine/core';
import { useDebouncedValue } from '@mantine/hooks';
import { sortBy } from 'lodash'
import { IconSearch, IconX } from '@tabler/icons-react';
import { DataTable } from 'mantine-datatable';
import { CONFIGURATIONS } from "utils/constants/configurations";
import { Route_URL } from 'utils/constants/RouteURL';
import { formatDateTime } from 'utils/Common';
import classes from '../styles/Table.styles.module.css';
import 'mantine-datatable/styles.css';

const PAGE_SIZES = [10, 15, 20];

const EventTable = (props: any) => {
    const { data, rfcFilterValue, incidentFilterValue, fetching, currPage, setCurrPage, totalRecords, pageSize, setPageSize } = props;
    
    const key = 'resize-complex-example';

    // const initialRecords = data && data.slice(0, PAGE_SIZE);

    const [sortStatus, setSortStatus] = useState<any>({
        columnAccessor: '',
        direction: '',
    });

    // const [pageSize, setPageSize] = useState(PAGE_SIZES[1]);
    const [page, setPage] = useState(1);
    const [records, setRecords] = useState<string[]>([]);
    const [latestRecords, setLatestRecords] = useState<string[]>(data);

    const [searchEventId, setSearchEventId] = useState('');
    const [searchEventTitle, setSearchEventTitle] = useState('');
    const [selectedStatus, setSelectedStatus] = useState<string[]>([]);
    const [selectedSeverity, setSelectedSeverity] = useState<string[]>([]);
    const [debouncedQuery] = useDebouncedValue(searchEventId, 200);
    const [debouncedQueryTitle] = useDebouncedValue(searchEventTitle, 200);

    useEffect(() => {
        setRecords(data.slice(0, pageSize));
        setLatestRecords(data);
    }, [data])

    useEffect(() => {
        const dataTmp = sortBy(latestRecords, sortStatus.columnAccessor);
        if(dataTmp && dataTmp.length > 0) {
            setRecords(sortStatus.direction === 'desc' ? dataTmp.reverse() : dataTmp);
        }
    }, [sortStatus]);

    useEffect(() => {
        const from = (currPage - 1) * pageSize;
        const to = from + pageSize;
        if(latestRecords) {
            setRecords(latestRecords.slice(from, to));
        }
    }, [currPage, pageSize]);

    useEffect(() => {
        if(data) {
            const filteredRecords = data && data.filter(({ event_id, event_title, event_status, severity }: any) => {
                if (
                    debouncedQuery !== '' &&
                    !`${event_id}`.toLowerCase().includes(debouncedQuery.trim().toLowerCase())
                )
                    return false;
    
                if (
                    debouncedQueryTitle !== '' &&
                    !`${event_title}`.toLowerCase().includes(debouncedQueryTitle.trim().toLowerCase())
                )
                    return false;
    
                if (selectedStatus.length && !selectedStatus.some((d) => d === event_status)) return false;
    
                if (selectedSeverity.length && !selectedSeverity.some((d) => d === severity)) return false;
    
                return true;
            });
    
            if(filteredRecords) {
                const from = (currPage - 1) * pageSize;
                const to = from + pageSize;
                setRecords(filteredRecords.slice(from, to));
                setLatestRecords(filteredRecords);
            }
        }
    }, [debouncedQuery, debouncedQueryTitle, selectedStatus, selectedSeverity]);

    return (
        <Paper className="paperTbl">
            {debouncedQuery}
            <Text
                size="lg"
                fw={700}
                // c={'red'}
                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                pb={10}
            >
                Event List
            </Text>
            <DataTable
                height={"auto"}
                minHeight={"20dvh"}
                // maxHeight={"50dvh"}
                withTableBorder
                highlightOnHover
                borderRadius="sm"
                withColumnBorders
                striped
                verticalAlign="top"
                pinLastColumn
                horizontalSpacing="xs"
                verticalSpacing="xs"
                fz="sm"
                records={records}
                classNames={{
                    // header: classes.header,
                }}
                storeColumnsKey={key}
                columns={[
                    {
                        accessor: 'event_id',
                        title: 'Event ID',
                        width: '120px',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ event_id }: any) => <Anchor href={`${CONFIGURATIONS.EVENT_LINK}${event_id}`} target="_blank">
                            GCC-{event_id}
                        </Anchor>,
                        // filter: (
                        //     <TextInput
                        //         label="Event Id"
                        //         description="Show event id whose id include the specified text"
                        //         placeholder="Search event id..."
                        //         leftSection={<IconSearch size={16} />}
                        //         rightSection={
                        //             <ActionIcon size="sm" variant="transparent" c="dimmed" onClick={() => setSearchEventId('')}>
                        //                 <IconX size={14} />
                        //             </ActionIcon>
                        //         }
                        //         value={searchEventId}
                        //         onChange={(e) => setSearchEventId(e.currentTarget.value)}
                        //     />
                        // ),
                        // filtering: searchEventId !== '',
                    },
                    {
                        accessor: 'event_title',
                        title: 'Event Title',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ event_id, event_title }: any) => <Anchor href={`${Route_URL.eventOverview}?eventId=${event_id}&rfc_filter=${rfcFilterValue}&incident_filter=${incidentFilterValue}&eventTitle=${event_title}`} target="_blank">
                            {event_title}
                        </Anchor>,
                        // filter: (
                        //     <TextInput
                        //         label="Event Title"
                        //         description="Show events whose title include the specified text"
                        //         placeholder="Search event title..."
                        //         leftSection={<IconSearch size={16} />}
                        //         rightSection={
                        //             <ActionIcon size="sm" variant="transparent" c="dimmed" onClick={() => setSearchEventTitle('')}>
                        //                 <IconX size={14} />
                        //             </ActionIcon>
                        //         }
                        //         value={searchEventTitle}
                        //         onChange={(e) => setSearchEventTitle(e.currentTarget.value)}
                        //     />
                        // ),
                        // filtering: searchEventTitle !== '',
                    },
                    {
                        accessor: 'location', title: 'Location',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'severity', title: 'Severity',
                        width: '150px',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        // filter: (
                        //     <MultiSelect
                        //         label="Severity"
                        //         description="Show all events with the selected severity"
                        //         data={['Enterprise TIRM', 'GIRM', 'Informational', 'Managed Problem', 'Monitored Incident', 'TIRM']}
                        //         value={selectedSeverity}
                        //         placeholder="Search severity..."
                        //         onChange={setSelectedSeverity}
                        //         leftSection={<IconSearch size={16} />}
                        //         clearable
                        //         searchable
                        //     />
                        // ),
                        // filtering: selectedSeverity.length > 0,
                    },
                    {
                        accessor: 'event_status', title: 'Status',
                        width: '100px',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        // filter: (
                        //     <MultiSelect
                        //         label="Status"
                        //         description="Show all events with the selected status"
                        //         data={['Dismissed', 'Active', 'Passive', 'Closed', 'Under Review' , 'Resolved']}
                        //         value={selectedStatus}
                        //         placeholder="Search status..."
                        //         onChange={setSelectedStatus}
                        //         leftSection={<IconSearch size={16} />}
                        //         clearable
                        //         searchable
                        //     />
                        // ),
                        // filtering: selectedStatus.length > 0,
                    },
                    {
                        // accessor: 'created_ts', title: 'DATE/TIME',
                        accessor: 'created_ts', title: 'Open Time',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ created_ts }: any) => formatDateTime(created_ts),
                    }
                ]}
                totalRecords={totalRecords}
                recordsPerPage={pageSize}
                page={currPage}
                fetching={fetching}
                onPageChange={(p) => setCurrPage(p)}
                recordsPerPageOptions={PAGE_SIZES}
                onRecordsPerPageChange={setPageSize}
                sortStatus={sortStatus}
                onSortStatusChange={setSortStatus}
                // 👇 uncomment the next line to use a custom pagination size
                // paginationSize="md"
                // 👇 uncomment the next line to use a custom loading text
                loadingText="Loading..."
                // 👇 uncomment the next line to display a custom text when no records were found
               emptyState={
                    <div style={{ textAlign: 'center', padding: '20px' }}>
                        <Text>No Results Found</Text>
                    </div>
                }
                noRecordsText=""
            // 👇 uncomment the next line to use a custom pagination text
                paginationText={({ from, to, totalRecords }) => `Records ${from} - ${to} of ${totalRecords}`}
            // 👇 uncomment the next lines to use custom pagination colors
                // paginationActiveBackgroundColor="green"
                // paginationActiveTextColor="#e6e348"
            />
        </Paper>
    );
}

export default React.memo(EventTable);