'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { ActionIcon, Anchor, Button, Checkbox, Group, MultiSelect, Stack, Switch, TextInput, Text, Paper } from '@mantine/core';
import { useDebouncedValue } from '@mantine/hooks';
import { sortBy } from 'lodash'
import { IconSearch, IconX } from '@tabler/icons-react';
import { DataTable } from 'mantine-datatable';
import { CONFIGURATIONS } from "utils/constants/configurations";
import { Route_URL } from 'utils/constants/RouteURL';
import { formatDateTime } from 'utils/Common';
import classes from '../styles/Table.styles.module.css';
import 'mantine-datatable/styles.css';

const PAGE_SIZES = [10, 15, 20];

const CiTable = (props: any) => {
    const { data, rfcFilterValue, incidentFilterValue, fetching, currPage, setCurrPage, totalRecords, pageSize, setPageSize } = props;
    
    const key = 'resize-complex-example';

    // const initialRecords = data && data.slice(0, PAGE_SIZE);

    const [sortStatus, setSortStatus] = useState<any>({
        columnAccessor: '',
        direction: '',
    });

    // const [pageSize, setPageSize] = useState(PAGE_SIZES[1]);
    const [page, setPage] = useState(1);
    const [records, setRecords] = useState<string[]>([]);
    const [latestRecords, setLatestRecords] = useState<string[]>(data);

    const [searchLogicalName, setSearchLogicalName] = useState('');
    const [searchPfxApplicationName, setSearchPfxApplicationName] = useState('');
    const [searchNetworkName, setSearchNetworkName] = useState('');
    const [selectedStatus, setSelectedStatus] = useState<string[]>([]);
    const [debouncedQuery] = useDebouncedValue(searchLogicalName, 200);
    const [debouncedQueryTitle] = useDebouncedValue(searchPfxApplicationName, 200);
    const [debouncedQueryNetworkName] = useDebouncedValue(searchNetworkName, 200);

    useEffect(() => {
        setRecords(data.slice(0, pageSize));
        setLatestRecords(data);
    }, [data])

    useEffect(() => {
        const dataTmp = sortBy(latestRecords, sortStatus.columnAccessor);
        if(dataTmp && dataTmp.length > 0) {
            setRecords(sortStatus.direction === 'desc' ? dataTmp.reverse() : dataTmp);
        }
    }, [sortStatus]);

    useEffect(() => {
        const from = (currPage - 1) * pageSize;
        const to = from + pageSize;
        if(latestRecords) {
            setRecords(latestRecords.slice(from, to));
        }
    }, [currPage, pageSize]);

    useEffect(() => {
        if(data) {
            const filteredRecords = data.filter(({ NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS }: any) => {
                if (
                    debouncedQuery !== '' &&
                    !`${NUMBERPRGN}`.toLowerCase().includes(debouncedQuery.trim().toLowerCase())
                )
                    return false;
    
                if (
                    debouncedQueryTitle !== '' &&
                    !`${BRIEF_DESCRIPTION}`.toLowerCase().includes(debouncedQueryTitle.trim().toLowerCase())
                )
                    return false;
    
                if (
                    debouncedQueryNetworkName !== '' &&
                    !`${NETWORK_NAME}`.toLowerCase().includes(debouncedQueryNetworkName.trim().toLowerCase())
                )
                    return false;
    
                if (selectedStatus.length && !selectedStatus.some((d) => d === PROBLEM_STATUS)) return false;
    
                return true;
            });
    
            if(filteredRecords) {
                const from = (page - 1) * pageSize;
                const to = from + pageSize;
                setRecords(filteredRecords.slice(from, to));
                setLatestRecords(filteredRecords);
            }
        }
    }, [debouncedQuery, debouncedQueryTitle, debouncedQueryNetworkName, selectedStatus]);

    return (
        <Paper className="paperTbl">
            <Text
                size="lg"
                fw={700}
                // c={'red'}
                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                pb={10}
            >
                CI List
            </Text>
            <DataTable
                height={"auto"}
                minHeight={"20dvh"}
                // maxHeight={"50dvh"}
                withTableBorder
                highlightOnHover
                borderRadius="sm"
                withColumnBorders
                striped
                verticalAlign="top"
                pinLastColumn
                horizontalSpacing="xs"
                verticalSpacing="xs"
                fz="sm"
                records={records}
                classNames={{
                    // header: classes.header,
                }}
                storeColumnsKey={key}
                columns={[
                    {
                        accessor: 'logical_name',
                        title: 'CI ID',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ logical_name }: any) => <Anchor href={`${CONFIGURATIONS.CI_LINK}${logical_name}`} target="_blank">
                            {logical_name}
                        </Anchor>,
                        // filter: (
                        //     <TextInput
                        //         label="Logical Name"
                        //         description="Show CI whose id include the specified text"
                        //         placeholder="Search Logical Name..."
                        //         leftSection={<IconSearch size={16} />}
                        //         rightSection={
                        //             <ActionIcon size="sm" variant="transparent" c="dimmed" onClick={() => setSearchLogicalName('')}>
                        //                 <IconX size={14} />
                        //             </ActionIcon>
                        //         }
                        //         value={searchLogicalName}
                        //         onChange={(e) => setSearchLogicalName(e.currentTarget.value)}
                        //     />
                        // ),
                        // filtering: searchLogicalName !== '',
                    },
                    {
                        accessor: 'network_name', title: 'CI Name',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ logical_name, network_name }: any) => <Anchor href={`${Route_URL.ciOverview}?eventId=${network_name}&eventTitle=${network_name}&rfc_filter=${rfcFilterValue}&incident_filter=${incidentFilterValue}`} target="_blank">
                            {network_name}
                        </Anchor>,
                        // filter: (
                        //     <TextInput
                        //         label="CI Name"
                        //         description="Show all incidents with the specified text"
                        //         placeholder="Search by ci name..."
                        //         leftSection={<IconSearch size={16} />}
                        //         rightSection={
                        //             <ActionIcon size="sm" variant="transparent" c="dimmed" onClick={() => setSearchPfxApplicationName('')}>
                        //                 <IconX size={14} />
                        //             </ActionIcon>
                        //         }
                        //         value={searchPfxApplicationName}
                        //         onChange={(e) => setSearchNetworkName(e.currentTarget.value)}
                        //     />
                        // ),
                        // filtering: searchNetworkName !== '',
                    },
                    {
                        accessor: 'location', title: 'Location',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'description', title: 'Description',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'r_logical_name', title: 'Related CI ID',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'r_network_name', title: 'Related CI Name',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    }
                ]}
                totalRecords={totalRecords}
                recordsPerPage={pageSize}
                page={currPage}
                fetching={fetching}
                onPageChange={(p) => setCurrPage(p)}
                recordsPerPageOptions={PAGE_SIZES}
                onRecordsPerPageChange={setPageSize}
                sortStatus={sortStatus}
                onSortStatusChange={setSortStatus}
                // 👇 uncomment the next line to use a custom pagination size
                // paginationSize="md"
                // 👇 uncomment the next line to use a custom loading text
                loadingText="Loading..."
                // 👇 uncomment the next line to display a custom text when no records were found
                emptyState={
                    <div style={{ textAlign: 'center', padding: '20px' }}>
                        <Text>No Results Found</Text>
                    </div>
                }
              
                noRecordsText=""
            // 👇 uncomment the next line to use a custom pagination text
                paginationText={({ from, to, totalRecords }) => `Records ${from} - ${to} of ${totalRecords}`}
            // 👇 uncomment the next lines to use custom pagination colors
                // paginationActiveBackgroundColor="green"
                // paginationActiveTextColor="#e6e348"
            />
        </Paper>
    );
}

export default React.memo(CiTable);