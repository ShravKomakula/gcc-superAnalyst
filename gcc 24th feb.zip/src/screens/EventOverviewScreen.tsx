import EventOverview from 'modules/dashboard/components/EventOverview'
import ErrorHandler from 'modules/error/ErrorHandler'
import { ErrorBoundary } from 'react-error-boundary'
import PrivateLayout from 'ui/layouts/PrivateLayout'

export default function EventOverviewScreen() {
  return (
    <PrivateLayout>
      <ErrorBoundary FallbackComponent={ErrorHandler}>
        <EventOverview />
      </ErrorBoundary>
    </PrivateLayout>
  )
}
