import axiosInstance from "./AxiosInstance";


export const getTokenMonitoringListService = async (payload: any) => {
    const response = await axiosInstance.get(`token_table`, { params: payload });
    return response;
};