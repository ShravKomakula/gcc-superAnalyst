
import axiosInstance from "./AxiosInstance";

export const loginService = async (payload: any) => {
    const response = await axiosInstance.get(`login`, { params: payload });
    return response;
};

export const getAuthTokenRequest = async (request: any) => {
    const response = await axiosInstance.post(`token_oauth2`, request );
    return response;
}

export const validateAuthTokenRequest = async (request: any) => {
    return await axiosInstance.post(`validate_oauth2`, request).then((result: any) => {
        return result.data;
    }).catch((err: any) => {
        if (err.response) {
            return err.response;
        }
        return [];
    });
}

export const refreshTokenRequest = async (request: any) => {
    return await axiosInstance.post(`refresh_oauth2`, request).then((result: any) => {
        return result.data;
    }).catch((err: any) => {
        if (err.response) {
            return err.response;
        }
        return [];
    });
}

export const introspectionTokenRequest = async (request: any) => {
    return await axiosInstance.post(`introspect_oauth2`, request).then((result: any) => {
        return result.data;
    }).catch((err: any) => {
        if (err.response) {
            return err.response;
        }
        return [];
    });
}