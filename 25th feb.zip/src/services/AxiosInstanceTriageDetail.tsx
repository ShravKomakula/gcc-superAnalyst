import axios from 'axios'

const getToken = () => {
  const token = localStorage.getItem('jwt_Token') ?? ''
  return token
}

const axiosInstanceTriageDetail = axios.create({
  baseURL: process.env.REACT_APP_API_URL_TRIAGE_DETAIL ? process.env.REACT_APP_API_URL_TRIAGE_DETAIL : '',
  headers: {},
})
axiosInstanceTriageDetail.interceptors.request.use(
  (config: any) => {
    if (!config) {
      config = {}
    }
    if (!config.headers) {
      config.headers = {}
    }
    // config.headers['Authorization'] = `${'Bearer' + ' ' + getToken()}`
    // config.headers['Access-Control-Allow-origin'] = `*`;
    // config.headers['Content-Type'] = `application/json`;
    // config.headers['accept'] = `application/json`;
    return config
  },
  (error) => {
    Promise.reject(error)
  }
)

axiosInstanceTriageDetail.interceptors.response.use(
  (response) => response,
  (error) => {
    return Promise.reject(error)
  }
)

export default axiosInstanceTriageDetail
