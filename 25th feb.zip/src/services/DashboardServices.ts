import axiosInstance from "./AxiosInstance";


export const getIncidentService = async (payload: any) => {
    const response = await axiosInstance.get(`input_network_details?limit=5`, { params: payload });
    return response;
};

export const getIncidentInfoService = async (payload: any) => {
    const response = await axiosInstance.post(`get_response`, payload);
    return response;
};

export const getEventDetailsService = async (payload: any) => {
    const response = await axiosInstance.get(`event_details?limit=5`, { params: payload });
    return response;
};

export const getIncidentsDetailsService = async (payload: any) => {
    const response = await axiosInstance.get(`incidents_details?limit=5`, { params: payload });
    return response;
};

export const getRfcDetailsService = async (payload: any) => {
    const response = await axiosInstance.get(`rfc_details?limit=5`, { params: payload });
    return response;
};

export const getCoRelatedService = async (payload: any) => {
    const response = await axiosInstance.post(`co_related`, payload);
    return response;
};

export const getCoRelatedPlaybookService = async (payload: any) => {
    const response = await axiosInstance.get(`co_related_playbook/`, payload);
    return response;
};

export const getDashboardService = async (payload: any) => {
    const response = await axiosInstance.get(`dashboard`, { params: payload });
    return response;
};

export const getDashboardKeywordService = async (payload: any) => {
    const response = await axiosInstance.get(`api/events`, { params: payload });
    return response;
};

export const getDashboardICService = async (payload: any) => {
    const response = await axiosInstance.get(`dashboard_IC`, { params: payload });
    return response;
};

export const getDashboardICKeywordService = async (payload: any) => {
    const response = await axiosInstance.get(`api/Incidents`, { params: payload });
    return response;
};

export const getRelatedServices = async (payload: any) => {
    const response = await axiosInstance.get(`api/`, { params: payload });
    return response;
};

export const getTriageDetailServices = async (payload: any) => {
    const response = await axiosInstance.post(`triage?new_item=${payload.new_item}&title=${payload.title}&incident_filter=${payload.incident_filter}&rfc_filter=${payload.rfc_filter}`, payload);
    return response;
};

export const getEventByIdService = async (payload: any) => {
    const response = await axiosInstance.get(`get_event_byid`, { params: payload });
    return response;
};

export const getIncidentByIdService = async (payload: any) => {
    const response = await axiosInstance.get(`get_Incident_byid`, { params: payload });
    return response;
};

export const getTriageServices = async (payload: any) => {
    const response = await axiosInstance.post(`triage?new_item=${payload.new_item}`, payload );
    return response;
};

export const getCorelationServices = async (payload: any) => {
    const response = await axiosInstance.post(`correlation?new_item=${payload.new_item}`, payload );
    return response;
};

export const getSemanticSearchServices = async (payload: any) => {
    const response = await axiosInstance.post(`semantic_search`, payload );
    return response;
};

export const submitRcaFeedbackServices = async (payload: any) => {
    const response = await axiosInstance.post(`rca_feedback`, payload );
    return response;
};

export const submitTriageFeedbackServices = async (payload: any) => {
    const response = await axiosInstance.post(`triage_feedback`, payload );
    return response;
};

export const submitCorrelationFeedbackServices = async (payload: any) => {
    const response = await axiosInstance.post(`submit_feedback`, payload );
    return response;
};

export const getUniversalSearchService = async (payload: any) => {
    const response = await axiosInstance.get(`api/UniversalSearch`, { params: payload } );
    return response;
};

/*****************************Code Optimised Apis*******************************************/

export const getEventDashboardService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_event_dashboard`, payload);
    return response;
};

export const getIncidentDashboardService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_incident_dashboard`, payload);
    return response;
};

export const getSearchEventsService = async (payload: any) => {
    const response = await axiosInstance.post(`search_api_events`, payload);
    return response;
};

export const getSearchIncidentsService = async (payload: any) => {
    const response = await axiosInstance.post(`search_api_incidents`, payload);
    return response;
};

export const getEventByIdV2Service = async (payload: any) => {
    const response = await axiosInstance.post(`get_event_by_id`, payload);
    return response;
};

export const getIncidentByIdV2Service = async (payload: any) => {
    const response = await axiosInstance.post(`get_incident_by_id`, payload);
    return response;
};

export const getCiInformationService = async (payload: any) => {
    const response = await axiosInstance.post(`get-ci-info`, payload);
    return response;
};

export const getEventsCiInformationService = async (payload: any) => {
    const response = await axiosInstance.post(`/get-ci-info-events`, payload);
    return response;
};

export const getCiCiInformationService = async (payload: any) => {
    const response = await axiosInstance.post(`/get_ci_info_ci`, payload);
    return response;
};

export const getAllCiBasedIncidentsService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_ci_based_incidents`, payload);
    return response;
};

export const getAllCiBasedIncidentsCiService = async (payload: any) => {
    const response = await axiosInstance.post(`ci_based_incidents_ci`, payload);
    return response;
};

export const getEventsAllCiBasedIncidentsService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_ci_based_event_incidents`, payload);
    return response;
};

export const getAllCiBasedRfcsService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_ci_based_rfcs`, payload);
    return response;
};

export const getCiBasedRfcsCiService = async (payload: any) => {
    const response = await axiosInstance.post(`ci_based_rfcs_ci`, payload);
    return response;
};

export const getEventAllCiBasedRfcsService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_ci_based_rfcs_events`, payload);
    return response;
};

export const getAllOthersDataService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_others_data`, payload);
    return response;
};

export const getEventAllOthersDataService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_others_data_events`, payload);
    return response;
};

export const getAllIncidentLocationService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_incident_location`, payload);
    return response;
};

export const getAllIncidentLocationCiService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_incident_location_ci`, payload);
    return response;
};

export const getEventAllIncidentLocationService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_incident_location_events`, payload);
    return response;
};

export const getAllRfcLocationService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_rfc_location`, payload);
    return response;
};

export const getAllRfcLocationCiService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_rfc_location_ci`, payload);
    return response;
};

export const getEventAllRfcLocationService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_rfc_location_events`, payload);
    return response;
};

export const getAllIncidentAsignmentGroupDataService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_incident_asignment_group_data`, payload);
    return response;
};

export const getIncidentAsignmentGroupCiService = async (payload: any) => {
    const response = await axiosInstance.post(`incident_assignment_group_ci`, payload);
    return response;
};

export const getEventAllIncidentAsignmentGroupDataService = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_event_assignment_group_data`, payload);
    return response;
};

export const getRfcAssignmentGroupDataService = async (payload: any) => {
    const response = await axiosInstance.post(`get_rfc_assignment_group_data`, payload);
    return response;
};

export const getRfcAssignmentGroupCiService = async (payload: any) => {
    const response = await axiosInstance.post(`rfc_assignment_group_ci`, payload);
    return response;
};

export const getEventRfcAssignmentGroupDataService = async (payload: any) => {
    const response = await axiosInstance.post(`get_rfc_assignment_group_data_events`, payload);
    return response;
};


export const getTriageLServices = async (payload: any) => {
    const response = await axiosInstance.post(`get_all_triage_llm`, payload);
    return response;
};

export const getCiTriageLServices = async (payload: any) => {
    const response = await axiosInstance.post(`ci_triage`, payload);
    return response;
};

export const getSimilaritySearchServices = async (payload: any) => {
    const response = await axiosInstance.get(`similarity_api`, { params: payload });
    return response;
};

export const getTriageVoxLocationServices = async (payload: any) => {
    const response = await axiosInstance.post(`llm_new_vox_location_api`, payload);
    return response;
};

export const getTriageVoxAppServerServices = async (payload: any) => {
    const response = await axiosInstance.post(`llm_new_vox_app_server_api`, payload);
    return response;
};

export const getTriageVoxAssignGroupServices = async (payload: any) => {
    const response = await axiosInstance.post(`llm_new_vox_assign_group_api`, payload);
    return response;
};

export const getTriageVoxDeviceTypeServices = async (payload: any) => {
    const response = await axiosInstance.post(`llm_new_vox_device_type_api`, payload);
    return response;
};

export const getTriageVoxDownstreamServices = async (payload: any) => {
    const response = await axiosInstance.post(`llm_new_vox_up_downstream_api`, payload);
    return response;
};

export const getTriageVoxEventsServices = async (payload: any) => {
    const response = await axiosInstance.post(`llm_new_vox_Events_api`, payload);
    return response;
};

export const getSummaryDataServices = async (payload: any) => {
    const response = await axiosInstance.post(`get_summary_data`, payload);
    return response;
};

export const getInitialAnalysisServices = async (payload: any) => {
    const response = await axiosInstance.post(`ic_initial_analysis`, payload);
    return response;
};

