import Dashboard from 'modules/dashboard/components'
import ErrorHandler from 'modules/error/ErrorHandler'
import { ErrorBoundary } from 'react-error-boundary'
import PrivateLayout from 'ui/layouts/PrivateLayout'

export default function DashboardScreen() {
  return (
    <PrivateLayout>
      <ErrorBoundary FallbackComponent={ErrorHandler}>
        <Dashboard />
      </ErrorBoundary>
    </PrivateLayout>
  )
}
