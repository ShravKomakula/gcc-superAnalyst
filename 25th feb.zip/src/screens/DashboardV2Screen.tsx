import DashboardV2 from 'modules/dashboard/components/DashboardV2'
import ErrorHandler from 'modules/error/ErrorHandler'
import { ErrorBoundary } from 'react-error-boundary'
import PrivateLayout from 'ui/layouts/PrivateLayout'

export default function DashboardV2Screen() {
  return (
    <PrivateLayout>
      <ErrorBoundary FallbackComponent={ErrorHandler}>
        <DashboardV2 />
      </ErrorBoundary>
    </PrivateLayout>
  )
}
