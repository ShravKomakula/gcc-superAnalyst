import CiOverview from 'modules/dashboard/components/CiOverview'
import ErrorHandler from 'modules/error/ErrorHandler'
import { ErrorBoundary } from 'react-error-boundary'
import PrivateLayout from 'ui/layouts/PrivateLayout'

export default function CiOverviewScreen() {
  return (
    <PrivateLayout>
      <ErrorBoundary FallbackComponent={ErrorHandler}>
        <CiOverview />
      </ErrorBoundary>
    </PrivateLayout>
  )
}
