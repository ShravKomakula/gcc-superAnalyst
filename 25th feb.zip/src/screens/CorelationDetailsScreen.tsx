import CorelationDetails from 'modules/dashboard/components/CorelationDetails'
import ErrorHandler from 'modules/error/ErrorHandler'
import { ErrorBoundary } from 'react-error-boundary'
import PrivateLayout from 'ui/layouts/PrivateLayout'

export default function CorelationDetailsScreen() {
  return (
    <PrivateLayout>
      <ErrorBoundary FallbackComponent={ErrorHandler}>
        <CorelationDetails />
      </ErrorBoundary>
    </PrivateLayout>
  )
}
