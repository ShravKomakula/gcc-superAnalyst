import ErrorHandler from 'modules/error/ErrorHandler'
import Feedback from 'modules/feedback/components'
import { ErrorBoundary } from 'react-error-boundary'
import PrivateLayout from 'ui/layouts/PrivateLayout'

export default function FeedbackScreen() {
  return (
    <PrivateLayout>
      <ErrorBoundary FallbackComponent={ErrorHandler}>
        <Feedback />
      </ErrorBoundary>
    </PrivateLayout>
  )
}
