import styled from '@emotion/styled'
import { Container, Title } from '@mantine/core'
import { fontFamily, fontStyle } from 'utils/constants/TypographyProperties'

export const StyleContainer = styled(Container)`
    padding: 5px;
    .paperTbl {
        margin: 0px 10px 5px 10px;
        padding: 15px 15px 15px 15px;
        background: #FFFFFF 0% 0% no-repeat padding-box;
        box-shadow: 2px 13px 54px #695F9714;
        // border: 1px solid #D4D2D2;
        border-radius: 8px;
        opacity: 1;
        width: "100%",
        min-height: "100vh"
    }
`