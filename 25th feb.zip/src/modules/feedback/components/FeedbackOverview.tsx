import React, { useEffect, useState } from "react";
import {
    Badge,
    Group,
    Paper,
    Text,
    Button
} from "@mantine/core";
import FeedbackTable from "./FeedbackTable";
import { getFeedbackStatsAction } from "actions/Feedback";
import FeedbackStats from "./FeedbackStats";
import FeedbackChart from "./FeedbackChart";
import FDatePicker from "ui/datepicker/FDatePicker";
import { IconSearch } from "@tabler/icons-react";
import moment from "moment";
import { getCurrPrevDaysformatDateTime } from "utils/Common";

const FeedbackOverview = () => {
    const [statsLoading, setStatsLoading] = useState<boolean>(false);
    const [statsListData, setStatsListData] = useState<any>([]);
    const [statsCategoryData, setStatsCategoryData] = useState<any>({});
    const [dateFilter, setDateFilter] = useState<any>([
        getCurrPrevDaysformatDateTime(1, 0, 1),
        getCurrPrevDaysformatDateTime(0, 23, 59)
    ]);
    const [dateSelectedValue, setDateSelectedValue] = useState<any>([
        getCurrPrevDaysformatDateTime(1, 0, 1),
        getCurrPrevDaysformatDateTime(0, 23, 59)
    ]);

    useEffect(() => {
        setStatsLoading(true);
        setStatsListData([]);
        setStatsCategoryData({});
        const responseEvents = getFeedbackStatsAction({
            "filter_type": "custom_date",
            "start_date": moment(dateFilter[0]).format('YYYY-MM-DD'),
            "end_date": moment(dateFilter[1]).format('YYYY-MM-DD')
        });
        responseEvents.then((result: any) => {
            if (result && result.status === 404) {
                setStatsLoading(false);
                setStatsListData([]);
                setStatsCategoryData({});
                return;
            }

            if (result && result.category_stats) {
                setStatsListData(result.category_stats);
            }
            if (result && result.categories) {
                setStatsCategoryData(result.categories);
            }

            setStatsLoading(false);
        });
    }, [dateFilter])

    const handleSearch = () => {
        setDateFilter(dateSelectedValue);
    }

    return (
        <React.Fragment>
            <Paper className="paperTbl">
                <Group justify="center" grow={false} gap={"xs"}>
                    <FDatePicker
                        enableTime={false}
                        dateFormat = 'Y-m-d'
                        setValue={setDateSelectedValue}
                        defaultDate={dateSelectedValue}
                        disabled={statsLoading}
                    />
                    <Button rightSection={<IconSearch size={14} />} color="rgb(77, 77, 255)" onClick={() => handleSearch()} loading={statsLoading} loaderProps={{ type: 'dots' }}>Search</Button>
                </Group>
            </Paper>
            <Paper className="paperTbl">
                <Text
                    size="lg"
                    fw={700}
                    // c={'red'}
                    style={{ textDecoration: 'underline', textAlign: 'justify' }}
                    pb={10}
                >
                    Feedback Summary
                </Text>
                <Group justify="center">
                    {statsCategoryData && Object.keys(statsCategoryData).length > 0 && Object.keys(statsCategoryData).map((obj) => {
                        return (
                            <Badge color="rgb(77, 77, 255)" size="lg">{`${obj} : ${statsCategoryData[obj]}`}</Badge>
                        )
                    })}
                </Group>
                <FeedbackChart
                    data={statsListData}
                    fetching={statsLoading}
                />
                <FeedbackStats
                    data={statsListData}
                    fetching={statsLoading}
                />
            </Paper>
            <FeedbackTable dateFilter={dateFilter} />
        </React.Fragment>
    )
}

export default FeedbackOverview