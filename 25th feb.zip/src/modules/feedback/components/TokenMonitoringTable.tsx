'use client';

import React, { useEffect, useState } from 'react';
import { Text, Paper, Skeleton, Select, Group, Badge } from '@mantine/core';
import { DataTable } from 'mantine-datatable';
import { getTokenMonitoringListAction } from "actions/TokenMonitoring";
import 'mantine-datatable/styles.css';
import { formatDateTime } from 'utils/Common';

const PAGE_SIZES = [10, 15, 20];

const TokenMonitoringTable = () => {
    const key = 'resize-complex-example';

    // const initialRecords = data && data.slice(0, PAGE_SIZE);

    const [sortStatus, setSortStatus] = useState<any>({
        columnAccessor: '',
        direction: '',
    });

    const [records, setRecords] = useState<any[]>([]);
    const [currPage, setCurrPage] = useState<number>(1);
    const [monthlyAvgCount, setMonthlyAvgCount] = useState<number>(0);
    const [totalRecords, setTotalRecords] = useState<number>(0);
    const [pageSize, setPageSize] = useState<number>(20);
    const [fetching, setFetching] = useState<boolean>(false);

    useEffect(() => {
        fetchAllRecords();
    }, [currPage])

    const fetchAllRecords = () => {
        setFetching(true);
        setTotalRecords(0);
        setRecords([]);
        const responseEvents = getTokenMonitoringListAction({
            page: currPage,
            limit: pageSize
        });
        responseEvents.then((result: any) => {
            if (result && result.status === 404) {
                setFetching(false);
                setTotalRecords(0);
                setRecords([]);
                return;
            }
            if(result) {
                setRecords(result.data);
                setTotalRecords(result.total_records);
                if(result.avg > 0) {
                    setMonthlyAvgCount(result.avg);
                }
            }
            setFetching(false);
        });
    }

    return (
        <Skeleton visible={fetching}>
        <Paper className="paperTbl">
            <Group justify="space-between">
                <Text
                    size="lg"
                    fw={700}
                    // c={'red'}
                    style={{ textDecoration: 'underline', textAlign: 'justify' }}
                    pb={10}
                >
                    Token Monitoring List
                </Text>
                <Badge color="rgb(77, 77, 255)" size="lg">{`Monthly Average Count : ${monthlyAvgCount.toFixed(2)}`}</Badge>
            </Group>
            <DataTable
                height="70dvh"
                minHeight={200}
                maxHeight={1000}
                withTableBorder
                highlightOnHover
                borderRadius="sm"
                withColumnBorders
                striped
                verticalAlign="top"
                pinLastColumn
                horizontalSpacing="xs"
                verticalSpacing="xs"
                fz="sm"
                records={records}
                classNames={{
                    // header: classes.header,
                }}
                // storeColumnsKey={key}
                columns={[
                    {
                        accessor: 'id',
                        title: 'ID',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'title',
                        title: 'Title',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'token_count', title: 'Token Count',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'incident_start_datetime', title: 'Incident Start Time',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ incident_start_datetime }) => formatDateTime(incident_start_datetime),
                    },
                    {
                        accessor: 'incident_end_datetime', title: 'Incident End Time',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ incident_end_datetime }) => formatDateTime(incident_end_datetime),
                    },
                    {
                        accessor: 'rfc_start_datetime', title: 'Rfc Start Time',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ rfc_start_datetime }) => formatDateTime(rfc_start_datetime),
                    },
                    {
                        accessor: 'rfc_end_datetime', title: 'Rfc End Time',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ rfc_end_datetime }) => formatDateTime(rfc_end_datetime),
                    },
                    {
                        accessor: 'timestamp', title: 'Date/Time',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ timestamp }) => formatDateTime(timestamp),
                    }
                ]}
                totalRecords={totalRecords}
                recordsPerPage={pageSize}
                page={currPage}
                fetching={fetching}
                onPageChange={(p) => setCurrPage(p)}
                recordsPerPageOptions={PAGE_SIZES}
                onRecordsPerPageChange={setPageSize}
                sortStatus={sortStatus}
                onSortStatusChange={setSortStatus}
                // 👇 uncomment the next line to use a custom pagination size
                // paginationSize="md"
                // 👇 uncomment the next line to use a custom loading text
                loadingText="Loading..."
                // 👇 uncomment the next line to display a custom text when no records were found
               emptyState={
                    <div style={{ textAlign: 'center', padding: '20px' }}>
                        <Text>No Results Found</Text>
                    </div>
                }
                noRecordsText=""
            // 👇 uncomment the next line to use a custom pagination text
                paginationText={({ from, to, totalRecords }) => `Records ${from} - ${to} of ${totalRecords}`}
            // 👇 uncomment the next lines to use custom pagination colors
                // paginationActiveBackgroundColor="green"
                // paginationActiveTextColor="#e6e348"
            />
        </Paper>
        </Skeleton>
    );
}

export default React.memo(TokenMonitoringTable);