'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { Text, Paper, Skeleton, Anchor } from '@mantine/core';
import { sortBy } from 'lodash'
import { DataTable } from 'mantine-datatable';
import 'mantine-datatable/styles.css';

const PAGE_SIZES = [10, 15, 20];

const FeedbackStats = (props: any) => {
    const { data, fetching } = props;
    const key = 'resize-complex-example';

    // const initialRecords = data && data.slice(0, PAGE_SIZE);

    const [sortStatus, setSortStatus] = useState<any>({
        columnAccessor: '',
        direction: '',
    });

    const [pageSize, setPageSize] = useState(PAGE_SIZES[0]);
    const [currPage, setCurrPage] = useState(1);
    const [records, setRecords] = useState<string[]>([]);
    const [latestRecords, setLatestRecords] = useState<string[]>([]);

    useEffect(() => {
        if(data) {
            setRecords(data.slice(0, pageSize));
            setLatestRecords(data);
        }
    }, [data])

    useEffect(() => {
        const dataTmp = sortBy(latestRecords, sortStatus.columnAccessor);
        if(dataTmp) {
            const sortData = sortStatus.direction === 'desc' ? dataTmp.reverse() : dataTmp;
            setLatestRecords(sortData);
            setRecords(sortData.slice(0, pageSize));
        }
    }, [sortStatus]);

    useEffect(() => {
        const from = (currPage - 1) * pageSize;
        const to = from + pageSize;
        if(latestRecords) {
            setRecords(latestRecords.slice(from, to));
        }
    }, [currPage, pageSize]);

    return (
        <Skeleton visible={fetching}>
        <Paper className="paperTbl">
            {/* <Text
                size="lg"
                fw={700}
                // c={'red'}
                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                pb={10}
            >
                Feedback Stats
            </Text> */}
            <DataTable
                withTableBorder
                minHeight="100px"
                borderRadius="sm"
                shadow="sm"
                withColumnBorders
                striped
                highlightOnHover
                horizontalSpacing="xs"
                verticalSpacing="xs"
                fz="sm"
                verticalAlign="center"
                columns={[
                    {
                        accessor: 'category',
                        title: 'Category',
                        textAlign: 'left',
                        render: ({ category }: any) => String(category).charAt(0).toUpperCase() + String(category).slice(1),
                    },
                    {
                        accessor: 'positive',
                        title: 'Positive(TRUE)',
                        textAlign: 'left'
                    },
                    {
                        accessor: 'negative', title: 'Negative(FALSE)',
                        textAlign: 'left'
                    },
                    {
                        accessor: 'percentage_positive', title: '% Positive',
                        textAlign: 'left'
                    }
                ]}
                records={records}
                fetching={fetching}
                emptyState={
                    <div style={{ textAlign: 'center', padding: '20px' }}>
                        <Text>No Results Found</Text>
                    </div>
                }
                noRecordsText=""
            />
        </Paper>
        </Skeleton>
    );
}

export default React.memo(FeedbackStats);