'use client';

import React, { useEffect, useState } from 'react';
import { Text, Paper, Skeleton, Select } from '@mantine/core';
import { sortBy } from 'lodash'
import { DataTable } from 'mantine-datatable';
import { filterFeedbackStatusAction, getFeedbackListAction } from "actions/Feedback";
import { formatDateTime } from 'utils/Common';
import 'mantine-datatable/styles.css';
import moment from 'moment';

const PAGE_SIZES = [10, 15, 20];

const FeedbackTable = (props: any) => {
    const { dateFilter } = props;
    const key = 'resize-complex-example';

    // const initialRecords = data && data.slice(0, PAGE_SIZE);

    const [sortStatus, setSortStatus] = useState<any>({
        columnAccessor: '',
        direction: '',
    });

    const [records, setRecords] = useState<any[]>([]);
    const [feedbackType, setFeedbackType] = useState<string | null>('All');
    const [currPage, setCurrPage] = useState<number>(1);
    const [totalRecords, setTotalRecords] = useState<number>(0);
    const [pageSize, setPageSize] = useState<number>(20);
    const [fetching, setFetching] = useState<boolean>(false);

    useEffect(() => {
        if(feedbackType === 'All') {
            fetchAllRecords();
        } else {
            fetchFilteredRecords();
        }
    }, [currPage, feedbackType, pageSize, dateFilter])

    const fetchAllRecords = () => {
        setFetching(true);
        setTotalRecords(0);
        setRecords([]);
        const responseEvents = getFeedbackListAction({
            page: currPage,
            limit: pageSize,
            "filter_type": "custom_date",
            "start_date": moment(dateFilter[0]).format('YYYY-MM-DD'),
            "end_date": moment(dateFilter[1]).format('YYYY-MM-DD')
        });
        responseEvents.then((result: any) => {
            if (result && result.status === 404) {
                setFetching(false);
                setTotalRecords(0);
                setRecords([]);
                return;
            }
            if(result) {
                setRecords(result.data);
                setTotalRecords(result.total_records);
            }
            setFetching(false);
        });
    }

    const fetchFilteredRecords = () => {
        setFetching(true);
        setTotalRecords(0);
        setRecords([]);
        const responseEvents = filterFeedbackStatusAction({
            page: currPage,
            limit: pageSize,
            filter_option: feedbackType?.toLocaleLowerCase(),
            "filter_type": "custom_date",
            "start_date": moment(dateFilter[0]).format('YYYY-MM-DD'),
            "end_date": moment(dateFilter[1]).format('YYYY-MM-DD')
        });
        responseEvents.then((result: any) => {
            if (result && result.status === 404) {
                setFetching(false);
                setTotalRecords(0);
                setRecords([]);
                return;
            }
            if(result) {
                setRecords(result.data);
                setTotalRecords(result.total_records);
            }
            setFetching(false);
        });
    }

    return (
        <Skeleton visible={fetching}>
        <Paper className="paperTbl">
            <Text
                size="lg"
                fw={700}
                // c={'red'}
                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                pb={10}
            >
                Feedback List
            </Text>
            <DataTable
                height={totalRecords > 0 ? "70dvh" : "20dvh"}
                // minHeight={200}
                // maxHeight={1000}
                withTableBorder
                highlightOnHover
                borderRadius="sm"
                withColumnBorders
                striped
                verticalAlign="top"
                pinLastColumn
                horizontalSpacing="xs"
                verticalSpacing="xs"
                fz="sm"
                records={records}
                classNames={{
                    // header: classes.header,
                }}
                // storeColumnsKey={key}
                columns={[
                    {
                        accessor: 'id',
                        title: 'ID',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'is_positive',
                        title: 'Feedback Type',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        filter: () => (
                            <Select
                                label="Feedback Type"
                                description="Show all feedbacks with the selected status"
                                data={['All', 'Positive', 'Negative']}
                                value={feedbackType}
                                allowDeselect={false}
                                onChange={(value: string | null) => setFeedbackType(value)}
                                // comboboxProps={{withOverlay: true, withinPortal: false, withArrow: true}}
                            />
                        ),
                        filtering: feedbackType !== '',
                    },
                    {
                        accessor: 'tab_type', title: 'Category Type',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ tab_type }: any) => String(tab_type).charAt(0).toUpperCase() + String(tab_type).slice(1),
                    },
                    {
                        accessor: 'timestamp', title: 'Time',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ timestamp }: any) => formatDateTime(timestamp),
                    },
                    {
                        accessor: 'text_feedback', title: 'Feedback',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    }
                ]}
                totalRecords={totalRecords}
                recordsPerPage={pageSize}
                page={currPage}
                fetching={fetching}
                onPageChange={(p) => setCurrPage(p)}
                recordsPerPageOptions={PAGE_SIZES}
                onRecordsPerPageChange={setPageSize}
                sortStatus={sortStatus}
                onSortStatusChange={setSortStatus}
                // 👇 uncomment the next line to use a custom pagination size
                // paginationSize="md"
                // 👇 uncomment the next line to use a custom loading text
                loadingText="Loading..."
                // 👇 uncomment the next line to display a custom text when no records were found
               emptyState={
                    <div style={{ textAlign: 'center', padding: '20px' }}>
                        <Text>No Results Found</Text>
                    </div>
                }
                noRecordsText=""
            // 👇 uncomment the next line to use a custom pagination text
                paginationText={({ from, to, totalRecords }) => `Records ${from} - ${to} of ${totalRecords}`}
            // 👇 uncomment the next lines to use custom pagination colors
                // paginationActiveBackgroundColor="green"
                // paginationActiveTextColor="#e6e348"
            />
        </Paper>
        </Skeleton>
    );
}

export default React.memo(FeedbackTable);