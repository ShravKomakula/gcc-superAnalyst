import { useEffect, useState } from "react";
import {
    Paper, Table,
    Anchor, LoadingOverlay,
    Group,
    Stack, Text,
    Image,
    Avatar,
    ScrollArea,
    Select, Accordion,
    Button,
    Tooltip,
    Highlight,
    Input,
    Alert,
    Badge,
    Card
} from "@mantine/core";
import { useDisclosure } from '@mantine/hooks';
import { useParams, useSearchParams } from 'react-router-dom';
import { StyleContainer } from "../styles/Dashboard.styles";
import PageHeader from "./PageHeader";
import { Icons } from "assets/images";
import { getTriageAction } from "actions/Dashboard";
import reactStringReplace from "react-string-replace";
import { IconInfoCircle, IconSearch } from "@tabler/icons-react";
import moment from "moment";

interface AccordionLabelProps {
    label: string;
    image: string;
    description: string;
}

function AccordionLabel({ label, image, description }: AccordionLabelProps) {
    return (
      <Group wrap="nowrap">
        {/* <Avatar radius="xl" size="lg">
            <IconRobot size={1} />
        </Avatar> */}
        <div>
          <Text>{label}</Text>
          <Text size="sm" c="dimmed" fw={400}>
            {description}
          </Text>
        </div>
      </Group>
    );
}

const regx = /(?=.)(.*)(?<=:)/gim;

const TriageSection = (props: any) => {
    const icon = <IconInfoCircle />;
    const { triageDetails, loaderTriage } = props;
    const [searchParams] = useSearchParams();
    const eventTitle = searchParams.get('eventTitle');
    const [selectedRows, setSelectedRows] = useState<number[]>([]);

    const rowsDownstream = triageDetails && triageDetails.downstream && triageDetails.downstream.length > 0 && triageDetails.downstream.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['LOGICAL_NAME']}</Table.Td>
            <Table.Td>{element['NETWORK_NAME']}</Table.Td>
            <Table.Td>{element['R_LOGICAL_NAME']}</Table.Td>
            <Table.Td>{element['R_NETWORK_NAME']}</Table.Td>
            <Table.Td>{element['PFZ_STATUS']}</Table.Td>
        </Table.Tr>
    ));

    const rowsInfrastructure = triageDetails && triageDetails.infrastructure_dependencies && triageDetails.infrastructure_dependencies.length > 0 && triageDetails.infrastructure_dependencies.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['LOGICAL_NAME']}</Table.Td>
            <Table.Td>{element['NETWORK_NAME']}</Table.Td>
            <Table.Td>{element['R_LOGICAL_NAME']}</Table.Td>
            <Table.Td>{element['R_NETWORK_NAME']}</Table.Td>
            <Table.Td>{element['PFZ_STATUS']}</Table.Td>
        </Table.Tr>
    ));
    

    const rowsNEvents = triageDetails && triageDetails['Same_network_Events'] && triageDetails['Same_network_Events'].length > 0 && triageDetails['Same_network_Events'].map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['event_id']}</Table.Td>
            <Table.Td>{moment(element['created_time']).utc().format('MMMM DD YYYY, h:mm:ss A')}</Table.Td>
            <Table.Td>{element['responsible_service_area']}</Table.Td>
            <Table.Td>{element['event_title']}</Table.Td>
            <Table.Td>{element['config_item_id']}</Table.Td>
            <Table.Td>{element['network_name']}</Table.Td>
            <Table.Td>{element['description']}</Table.Td>
        </Table.Tr>
    ));

    const rowsIncidents = triageDetails && triageDetails['Same_network_Incidents'] && triageDetails['Same_network_Incidents'].length > 0 && triageDetails['Same_network_Incidents'].map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['STATUS']}</Table.Td>
            <Table.Td>{moment(element['OPEN_TIME']).utc().format('MMMM DD YYYY, h:mm:ss A')}</Table.Td>
            <Table.Td>{element['NETWORK_NAME']}</Table.Td>
            <Table.Td style={{whiteSpace: 'normal'}}>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
        </Table.Tr>
    ));

    const rowsRfc = triageDetails && triageDetails['Same_network_RFCs'] && triageDetails['Same_network_RFCs'].length > 0 && triageDetails['Same_network_RFCs'].map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['STATUS']}</Table.Td>
            <Table.Td>{moment(element['OPEN_TIME']).utc().format('MMMM DD YYYY, h:mm:ss A')}</Table.Td>
            <Table.Td>{element['NETWORK_NAME']}</Table.Td>
            <Table.Td>{element['ASSIGN_DEPT']}</Table.Td>
            <Table.Td style={{whiteSpace: 'normal'}}>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
        </Table.Tr>
    ));

    const rowsIcLocation = triageDetails && triageDetails['Incidents_by_location'] && triageDetails['Incidents_by_location'].length > 0 && triageDetails['Incidents_by_location'].map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['STATUS']}</Table.Td>
            <Table.Td style={{whiteSpace: 'normal'}}>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
        </Table.Tr>
    ));

    const rowsRfcLocation = triageDetails && triageDetails['RFCs_by_location'] && triageDetails['RFCs_by_location'].length > 0 && triageDetails['RFCs_by_location'].map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['STATUS']}</Table.Td>
            <Table.Td>{element['ASSIGN_DEPT']}</Table.Td>
            <Table.Td style={{whiteSpace: 'normal'}}>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
        </Table.Tr>
    ));

    const rowIcDetailsAssignGroup = triageDetails && triageDetails['Incidents_by_Assign_Group'] && triageDetails['Incidents_by_Assign_Group'].length > 0 && triageDetails['Incidents_by_Assign_Group'].map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['STATUS']}</Table.Td>
            <Table.Td>{element['ASSIGNMENT']}</Table.Td>
            <Table.Td>{element['OPEN_TIME']}</Table.Td>
            <Table.Td>{element['NETWORK_NAME']}</Table.Td>
            <Table.Td style={{whiteSpace: 'normal'}}>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
        </Table.Tr>
    ));

    const rowRfcDetailsAssignGroup = triageDetails && triageDetails['RFCs_by_Assign_Group'] && triageDetails['RFCs_by_Assign_Group'].length > 0 && triageDetails['RFCs_by_Assign_Group'].map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['STATUS']}</Table.Td>
            <Table.Td>{element['ASSIGN_DEPT']}</Table.Td>
            <Table.Td style={{whiteSpace: 'normal'}}>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
        </Table.Tr>
    ));

    return (
        <StyleContainer fluid>
            {/* <LoadingOverlay loaderProps={{ color: '#000484' }} visible={loaderTriage} zIndex={1000} overlayProps={{ radius: "sm", blur: 2, children: 'Loading....' }} /> */}
            { triageDetails && Object.keys(triageDetails).length > 0 ?
            <>
            <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                <ScrollArea h={200}>
                    <Text size="sm" fw={700} pb={0}>
                        RCA:
                    </Text><div style={{ whiteSpace: "pre-line" }}>
                    { triageDetails && triageDetails.llm_rca &&
                        triageDetails.llm_rca
                    }
                    </div>
                </ScrollArea>
            </Paper>
            <Accordion chevronPosition="right" variant="contained" pt={10} defaultValue={'probable_root_cause'}>
                <Accordion.Item value={'probable_root_cause'}>
                    <Accordion.Control>
                        <AccordionLabel label='Probable Root Cause' image='' description="" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        { triageDetails && triageDetails.llm_prc && triageDetails.llm_prc.length > 0 && triageDetails.llm_prc.map((llmPrc: any, index: number) => {
                            return (
                                <Card shadow="sm" padding="sm" radius="md" withBorder style={{textAlign: 'justify'}} tabIndex={index} mb={5}>
                                    <Group justify="space-between" mt="md" mb="xs">
                                        <Text fw={500}>{llmPrc.Title}</Text>
                                        <Badge variant="light" color={llmPrc.Likelihood >= 90 ? 'green' : (llmPrc.Likelihood < 90 && llmPrc.Likelihood >= 60 ? 'yellow' : (llmPrc.Likelihood < 60 && llmPrc.Likelihood >= 40 ? 'orange' : 'greay'))} size="lg">{llmPrc.Likelihood}% Confidence</Badge>
                                    </Group>

                                    <Text size="sm" c="dimmed">
                                        {llmPrc.Resolution}
                                    </Text>
                                </Card>
                            )
                        })}
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_triage_llm'}>
                    <Accordion.Control>
                        <AccordionLabel label='CI Information' image='' description="Basic Triage Details" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                            <ScrollArea h={350}>
                                {/* <Text fw={700}>GCC Notes:</Text> */}
                                <div style={{ whiteSpace: "pre-line" }}>
                                { triageDetails && triageDetails.triage_llm &&
                                    reactStringReplace(triageDetails.triage_llm, regx, (match: any, i) => (
                                        <strong>
                                            {match}
                                        </strong>
                                    ))
                                }
                                </div>
                            </ScrollArea>
                        </Paper>
                    </Accordion.Panel>
                </Accordion.Item>
                { triageDetails && triageDetails.downstream && triageDetails.downstream.length > 0 &&
                    <Accordion.Item value={'acc_downstream'}>
                        <Accordion.Control>
                            <AccordionLabel label='Downstream' image='' description="Downstream Relationships" />
                        </Accordion.Control>
                        <Accordion.Panel>
                            <Table.ScrollContainer minWidth={500}>
                            <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                                <Table.Thead style={{position: 'static'}}>
                                    <Table.Tr>
                                        <Table.Th>LOGICAL NAME</Table.Th>
                                        <Table.Th>CI Name</Table.Th>
                                        <Table.Th>RELATION LOGICAL_NAME</Table.Th>
                                        <Table.Th>RELATION NETWORK_NAME</Table.Th>
                                        <Table.Th>PFZ STATUS</Table.Th>
                                    </Table.Tr>
                                </Table.Thead>
                                <Table.Tbody>{rowsDownstream ? rowsDownstream : 'No Record Found.'}</Table.Tbody>
                            </Table>
                            </Table.ScrollContainer>
                        </Accordion.Panel>
                    </Accordion.Item>
                }
                { triageDetails && triageDetails.infrastructure_dependencies && triageDetails.infrastructure_dependencies.length > 0 &&
                <Accordion.Item value={'acc_infrastructure'}>
                    <Accordion.Control>
                        <AccordionLabel label='Infrastructure' image='' description="Infrastructure Relationships" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>LOGICAL NAME</Table.Th>
                                    <Table.Th>NETWORK NAME</Table.Th>
                                    <Table.Th>RELATION LOGICAL NAME</Table.Th>
                                    <Table.Th>RELATION NETWORK NAME</Table.Th>
                                    <Table.Th>PFZ STATUS</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsInfrastructure ? rowsInfrastructure : 'No Record Found.'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                }
                <Accordion.Item value={'acc_n_events'}>
                    <Accordion.Control>
                        <AccordionLabel label='Events' image='' description="Events by network name" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>event id</Table.Th>
                                    <Table.Th>created time</Table.Th>
                                    <Table.Th>responsible service area</Table.Th>
                                    <Table.Th>event title</Table.Th>
                                    <Table.Th>config item id</Table.Th>
                                    <Table.Th>network name</Table.Th>
                                    <Table.Th>description</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsNEvents ? rowsNEvents : 'No record found'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_n_incidents'}>
                    <Accordion.Control>
                        <AccordionLabel label='Incidents' image='' description="Incidents by network name" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>Incident Number</Table.Th>
                                    <Table.Th>STATUS</Table.Th>
                                    <Table.Th>OPEN TIME</Table.Th>
                                    <Table.Th>NETWORK NAME</Table.Th>
                                    <Table.Th>BRIEF DESCRIPTION</Table.Th>
                                    <Table.Th>LOCATION</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsIncidents ? rowsIncidents : 'No record found'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_n_rfc'}>
                    <Accordion.Control>
                        <AccordionLabel label='RFC' image='' description="Rfc by network name" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder withColumnBorders stickyHeader className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>RFC Number</Table.Th>
                                    <Table.Th>STATUS</Table.Th>
                                    <Table.Th>OPEN TIME</Table.Th>
                                    <Table.Th>NETWORK NAME</Table.Th>
                                    <Table.Th>ASSIGN DEPT</Table.Th>
                                    <Table.Th>BRIEF DESCRIPTION</Table.Th>
                                    <Table.Th>LOCATION</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsRfc ? rowsRfc : 'No record found'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_location'}>
                    <Accordion.Control>
                        <AccordionLabel label='Location' image='' description="Incidents/rfcs by location" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Stack
                            align="flex-start"
                            justify="center"
                            gap="0"
                        >
                        <Text size="sm" fw={700} td={'underline'}>
                            Incidents by location: 
                        </Text>
                        </Stack>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder withColumnBorders stickyHeader className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>Incident Number</Table.Th>
                                    <Table.Th>STATUS</Table.Th>
                                    <Table.Th>BRIEF DESCRIPTION</Table.Th>
                                    <Table.Th>LOCATION</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsIcLocation ? rowsIcLocation : 'No record found'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                        <Stack
                            align="flex-start"
                            justify="center"
                            gap="0"
                        >
                            <Text size="sm" fw={700} td={'underline'}>
                                RFCs by location: 
                            </Text>
                        </Stack>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder withColumnBorders stickyHeader className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>Incident Number</Table.Th>
                                    <Table.Th>STATUS</Table.Th>
                                    <Table.Th>ASSIGN_DEPT</Table.Th>
                                    <Table.Th>BRIEF DESCRIPTION</Table.Th>
                                    <Table.Th>LOCATION</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsRfcLocation ? rowsRfcLocation : 'No record found'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'pfz_assignment'}>
                    <Accordion.Control>
                        <AccordionLabel label='Assignment Group' image='' description="Incidents/rfcs by Assignment Group" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Stack
                            align="flex-start"
                            justify="center"
                            gap="0"
                        >
                        <Text size="sm" fw={700} td={'underline'}>
                            Incidents by Assign Group: 
                        </Text>
                        </Stack>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder withColumnBorders stickyHeader className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>Incident Number</Table.Th>
                                    <Table.Th>STATUS</Table.Th>
                                    <Table.Th>ASSIGNMENT</Table.Th>
                                    <Table.Th>OPEN TIME</Table.Th>
                                    <Table.Th>NETWORK NAME</Table.Th>
                                    <Table.Th>BRIEF DESCRIPTION</Table.Th>
                                    <Table.Th>LOCATION</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowIcDetailsAssignGroup ? rowIcDetailsAssignGroup : 'No record found'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                        <Stack
                            align="flex-start"
                            justify="center"
                            gap="0"
                        >
                            <Text size="sm" fw={700} td={'underline'}>
                                RFCs by Assign Group: 
                            </Text>
                        </Stack>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder withColumnBorders stickyHeader className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>Incident Number</Table.Th>
                                    <Table.Th>STATUS</Table.Th>
                                    <Table.Th>ASSIGN DEPT</Table.Th>
                                    <Table.Th>BRIEF DESCRIPTION</Table.Th>
                                    <Table.Th>LOCATION</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowRfcDetailsAssignGroup ? rowRfcDetailsAssignGroup : 'No record found'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
            </Accordion>
            </>
            : <Alert variant="outline" color="#000484" title="" icon={icon}>
                No triage result found for selected event/incident.
          </Alert>}
        </StyleContainer>
    )
}

export default TriageSection;