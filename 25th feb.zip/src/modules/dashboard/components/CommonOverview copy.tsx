import { useEffect, useState } from "react";
import {
    Paper, Table,
    Anchor, LoadingOverlay,
    Group,
    Stack, Text,
    Image,
    Avatar,
    ScrollArea,
    Select, Accordion,
    Button,
    Tooltip,
    Highlight,
    Tabs,
    Badge,
    Card
} from "@mantine/core";
import reactStringReplace from "react-string-replace";
import TriageSection from "./TriageSection";
import { Icons } from "assets/images";
import { IconInfoCircle } from "@tabler/icons-react";
import { CountryList } from "./CountryList";
import moment from "moment";

interface AccordionLabelProps {
    label: string;
    image: string;
    description: string;
}

const regx = /(?=.)(.*)(?<=:)/gim;

function AccordionLabel({ label, image, description }: AccordionLabelProps) {
    return (
        <Group wrap="nowrap">
            {/* <Avatar radius="xl" size="lg">
            <IconRobot size={1} />
        </Avatar> */}
            <div>
                <Text>{label}</Text>
                <Text size="sm" c="dimmed" fw={400}>
                    {description}
                </Text>
            </div>
        </Group>
    );
}

const CommonOverview = (props: any) => {
    const { eventListDetails, loaderTriage, triageDetails, setFilterSiteValue, pageType } = props;
    const [selectedRows, setSelectedRows] = useState<number[]>([]);

    const rowsSimilarEvents = eventListDetails && eventListDetails.similar_events && eventListDetails.similar_events.length > 0 && eventListDetails.similar_events.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{ textAlign: 'left' }}
        >
            <Table.Td>{element[0]['metadata'].event_id}</Table.Td>
            <Table.Td>{element[1].toFixed(2)}</Table.Td>
            <Table.Td>{element[0]['metadata'].issue_source}</Table.Td>
            <Table.Td>{element[0]['metadata'].responsible_service_area}</Table.Td>
            <Table.Td>{element[0]['metadata'].event_status}</Table.Td>
            <Table.Td style={{ whiteSpace: 'normal' }}>{element[0]?.page_content}</Table.Td>
        </Table.Tr>
    ));

    const rowsSimilarIncidents = eventListDetails && eventListDetails.similar_incidents && eventListDetails.similar_incidents.length > 0 && eventListDetails.similar_incidents.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{ textAlign: 'left' }}
        >
            <Table.Td>{element[0]['metadata'].NUMBERPRGN}</Table.Td>
            <Table.Td>{element[1].toFixed(2)}</Table.Td>
            <Table.Td>{element[0]['metadata'].STATUS}</Table.Td>
            <Table.Td>{element[0]['metadata'].LOCATION}</Table.Td>
            <Table.Td style={{ whiteSpace: 'normal' }}>{element[0].page_content}</Table.Td>
        </Table.Tr>
    ));

    const rowsSimilarRfc = eventListDetails && eventListDetails.similar_rfc && eventListDetails.similar_rfc.length > 0 && eventListDetails.similar_rfc.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{ textAlign: 'left' }}
        >
            <Table.Td>{element[0]['metadata'].NUMBERPRGN}</Table.Td>
            <Table.Td>{element[1].toFixed(2)}</Table.Td>
            <Table.Td>{element[0]['metadata'].STATUS}</Table.Td>
            <Table.Td>{element[0]['metadata'].LOCATION}</Table.Td>
            <Table.Td style={{ whiteSpace: 'normal' }}>{element[0].page_content}</Table.Td>
        </Table.Tr>
    ));

    const rowsSimilarProblems = eventListDetails && eventListDetails.similar_problems && eventListDetails.similar_problems.length > 0 && eventListDetails.similar_problems.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{ textAlign: 'left' }}
        >
            <Table.Td>{element[0]['metadata'].ID}</Table.Td>
            <Table.Td>{element[1].toFixed(2)}</Table.Td>
            <Table.Td>{element[0]['metadata'].STATUS}</Table.Td>
            <Table.Td style={{ whiteSpace: 'normal' }}>{element[0].page_content}</Table.Td>
        </Table.Tr>
    ));

    const rowsSimilarProblemTasks = eventListDetails && eventListDetails.similar_pt && eventListDetails.similar_pt.length > 0 && eventListDetails.similar_pt.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{ textAlign: 'left' }}
        >
            <Table.Td>{element[0]['metadata'].ID}</Table.Td>
            <Table.Td>{element[1].toFixed(2)}</Table.Td>
            <Table.Td>{element[0]['metadata'].ASSIGNMENT}</Table.Td>
            <Table.Td>{element[0]['metadata'].STATUS}</Table.Td>
            <Table.Td style={{ whiteSpace: 'normal' }}>{element[0].page_content}</Table.Td>
        </Table.Tr>
    ));

    const rowsCIEvents = triageDetails && triageDetails['Same_network_Events'] && triageDetails['Same_network_Events'].length > 0 && triageDetails['Same_network_Events'].map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{ textAlign: 'left' }}
        >
            <Table.Td>{element['event_id']}</Table.Td>
            <Table.Td>{moment(element['created_time']).utc().format('MMMM DD YYYY, h:mm:ss A')}</Table.Td>
            <Table.Td>{element['responsible_service_area']}</Table.Td>
            <Table.Td>{element['event_title']}</Table.Td>
            <Table.Td>{element['config_item_id']}</Table.Td>
            <Table.Td>{element['network_name']}</Table.Td>
            <Table.Td>{element['description']}</Table.Td>
        </Table.Tr>
    ));

    const rowsCIIncidents = triageDetails && triageDetails['Same_network_Incidents'] && triageDetails['Same_network_Incidents'].length > 0 && triageDetails['Same_network_Incidents'].map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['STATUS']}</Table.Td>
            <Table.Td>{moment(element['OPEN_TIME']).utc().format('MMMM DD YYYY, h:mm:ss A')}</Table.Td>
            <Table.Td>{element['NETWORK_NAME']}</Table.Td>
            <Table.Td style={{whiteSpace: 'normal'}}>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
        </Table.Tr>
    ));

    const rowsCIRfc = triageDetails && triageDetails['Same_network_RFCs'] && triageDetails['Same_network_RFCs'].length > 0 && triageDetails['Same_network_RFCs'].map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['STATUS']}</Table.Td>
            <Table.Td>{moment(element['OPEN_TIME']).utc().format('MMMM DD YYYY, h:mm:ss A')}</Table.Td>
            <Table.Td>{element['NETWORK_NAME']}</Table.Td>
            <Table.Td>{element['ASSIGN_DEPT']}</Table.Td>
            <Table.Td style={{whiteSpace: 'normal'}}>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
        </Table.Tr>
    ));

    return (
        <>
            <Paper className="paperTbl">
                <Group justify="space-between">
                    <Stack
                        align="stretch"
                        justify="center"
                        gap="0"
                    >
                        <Group justify="">
                            <Button variant="default" className="aiBtn">
                                AI Results <Image
                                    className="aiIcon"
                                    src={Icons.Imgbot_white}
                                    onClick={() => { }}
                                />
                            </Button>
                            {/* <Text size="sm">
                                Click for generated resolution steps
                            </Text> */}
                        </Group>
                    </Stack>
                    <Group wrap="nowrap">
                        <Select
                            label=""
                            w={240}
                            placeholder="Site Filter"
                            data={CountryList()}
                            defaultValue=""
                            allowDeselect={false}
                            searchable
                            clearable
                            onChange={(value: string | null) => setFilterSiteValue(value)}
                        />
                    </Group>
                </Group>
            </Paper>
            <Accordion chevronPosition="right" variant="contained" pt={5} transitionDuration={500}>
                <Accordion.Item value={'acc_triage_llm'} mb={5}>
                    <Accordion.Control>
                        <Group wrap="nowrap">
                            <Avatar src={'https://img.icons8.com/clouds/256/000000/futurama-bender.png'} radius="xl" size="lg" />
                            <div>
                                <Text>{'CI Information'}</Text>
                                <Text size="sm" c="dimmed" fw={400}>
                                    {'Basic Triage Details'}
                                </Text>
                            </div>
                        </Group>
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                            <ScrollArea h={350}>
                                {/* <Text fw={700}>GCC Notes:</Text> */}
                                <div style={{ whiteSpace: "pre-line" }}>
                                    {triageDetails && triageDetails.triage_llm &&
                                        reactStringReplace(triageDetails.triage_llm, regx, (match: any, i) => (
                                            <strong>
                                                {match}
                                            </strong>
                                        ))
                                    }
                                </div>
                            </ScrollArea>
                        </Paper>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_triage_summary'} mb={5}>
                    <Accordion.Control>
                        <Group wrap="nowrap">
                            <Avatar src={'https://img.icons8.com/clouds/256/000000/futurama-bender.png'} radius="xl" size="lg" />
                            <div>
                                <Text>{'Triage Summary'}</Text>
                                <Text size="sm" c="dimmed" fw={400}>
                                    {'Triage Detailed Summary'}
                                </Text>
                            </div>
                        </Group>
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                            <ScrollArea h={200}>
                                <div style={{ whiteSpace: "pre-line" }}>
                                    {triageDetails && triageDetails.llm_rca &&
                                        triageDetails.llm_rca
                                    }
                                </div>
                            </ScrollArea>
                        </Paper>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'probable_root_cause'}>
                    <Accordion.Control>
                        <Group wrap="nowrap">
                            <Avatar src={'https://img.icons8.com/clouds/256/000000/futurama-bender.png'} radius="xl" size="lg" />
                            <div>
                                <Text>{'Probable Root Cause'}</Text>
                                <Text size="sm" c="dimmed" fw={400}>
                                    {''}
                                </Text>
                            </div>
                        </Group>
                    </Accordion.Control>
                    <Accordion.Panel>
                        {triageDetails && triageDetails.llm_prc && triageDetails.llm_prc.length > 0 && triageDetails.llm_prc.map((llmPrc: any, index: number) => {
                            return (
                                <Card shadow="sm" padding="sm" radius="md" withBorder style={{ textAlign: 'justify' }} tabIndex={index} mb={5}>
                                    <Group justify="space-between" mt="md" mb="xs">
                                        <Text fw={500}>{llmPrc.Title}</Text>
                                        <Badge variant="light" color={llmPrc.Likelihood >= 90 ? 'green' : (llmPrc.Likelihood < 90 && llmPrc.Likelihood >= 60 ? 'yellow' : (llmPrc.Likelihood < 60 && llmPrc.Likelihood >= 40 ? 'orange' : 'greay'))} size="lg">{llmPrc.Likelihood}% Confidence</Badge>
                                    </Group>

                                    <Text size="sm" c="dimmed">
                                        {llmPrc.Resolution}
                                    </Text>
                                </Card>
                            )
                        })}
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'ci_embending_events'}>
                    <Accordion.Control>
                        <Group wrap="nowrap">
                            <Avatar src={'https://img.icons8.com/clouds/256/000000/futurama-bender.png'} radius="xl" size="lg" />
                            <div>
                                <Text>{'CI based / Embending based Events'}</Text>
                                <Text size="sm" c="dimmed" fw={400}>
                                    {'CI based / Embending based Information by network name'}
                                </Text>
                            </div>
                        </Group>
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Paper className="paperTbl">
                            <Text
                                size="xl"
                                fw={700}
                                c={'blue'}
                                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                                pb={10}
                            >
                                CI Based Events
                            </Text>
                            <Table.ScrollContainer minWidth={500}>
                                <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{ whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden' }}>
                                    <Table.Thead style={{ position: 'static' }}>
                                        <Table.Tr>
                                            <Table.Th>event id</Table.Th>
                                            <Table.Th>created time</Table.Th>
                                            <Table.Th>responsible service area</Table.Th>
                                            <Table.Th>event title</Table.Th>
                                            <Table.Th>config item id</Table.Th>
                                            <Table.Th>CI Name</Table.Th>
                                            <Table.Th>description</Table.Th>
                                        </Table.Tr>
                                    </Table.Thead>
                                    <Table.Tbody>{rowsCIEvents ? rowsCIEvents : 'No record found'}</Table.Tbody>
                                </Table>
                            </Table.ScrollContainer>
                        </Paper>
                        <Paper className="paperTbl">
                            <Text
                                size="xl"
                                fw={700}
                                c={'red'}
                                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                                pb={10}
                            >
                                Embending Based Events
                            </Text>
                            <Table.ScrollContainer minWidth={500}>
                                <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable"
                                    style={{ whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden' }}
                                >
                                    <Table.Thead style={{ position: 'static' }}>
                                        <Table.Tr>
                                            <Table.Th>Event ID</Table.Th>
                                            <Table.Th>
                                                Similarity Score
                                                <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Similarity score represents how similar two events are based on their title">
                                                      <IconInfoCircle size={20} />
                                                </Tooltip>
                                            </Table.Th>
                                            <Table.Th>issue source</Table.Th>
                                            <Table.Th>Responsible Service Area</Table.Th>
                                            <Table.Th>Status</Table.Th>
                                            <Table.Th>Event Title</Table.Th>
                                        </Table.Tr>
                                    </Table.Thead>
                                    <Table.Tbody>{rowsSimilarEvents ? rowsSimilarEvents : 'No record found for the selected incident'}</Table.Tbody>
                                </Table>
                            </Table.ScrollContainer>
                        </Paper>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'ci_embending_incidents'}>
                    <Accordion.Control>
                        <Group wrap="nowrap">
                            <Avatar src={'https://img.icons8.com/clouds/256/000000/futurama-bender.png'} radius="xl" size="lg" />
                            <div>
                                <Text>{'CI based / Embending based Incidents'}</Text>
                                <Text size="sm" c="dimmed" fw={400}>
                                    {'CI based / Embending based Information by network name'}
                                </Text>
                            </div>
                        </Group>
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Paper className="paperTbl">
                            <Text
                                size="xl"
                                fw={700}
                                c={'blue'}
                                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                                pb={10}
                            >
                                CI Based Incidents
                            </Text>
                            <Table.ScrollContainer minWidth={500}>
                            <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                                <Table.Thead style={{position: 'static'}}>
                                    <Table.Tr>
                                        <Table.Th>Incident Number</Table.Th>
                                        <Table.Th>STATUS</Table.Th>
                                        <Table.Th>OPEN TIME</Table.Th>
                                        <Table.Th>NETWORK NAME</Table.Th>
                                        <Table.Th>BRIEF DESCRIPTION</Table.Th>
                                        <Table.Th>LOCATION</Table.Th>
                                    </Table.Tr>
                                </Table.Thead>
                                <Table.Tbody>{rowsCIIncidents ? rowsCIIncidents : 'No record found'}</Table.Tbody>
                            </Table>
                        </Table.ScrollContainer>
                        </Paper>
                        <Paper className="paperTbl">
                            <Text
                                size="xl"
                                fw={700}
                                c={'red'}
                                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                                pb={10}
                            >
                                Embending Based Incidents
                            </Text>
                            <Table.ScrollContainer minWidth={500}>
                                <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{ whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden' }}>
                                    <Table.Thead style={{ position: 'static' }}>
                                        <Table.Tr>
                                            <Table.Th>Incident Number</Table.Th>
                                            <Table.Th>
                                                Similarity Score
                                                <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Similarity score represents how similar an incident is based on description and event title">
                                                    <IconInfoCircle size={20} />
                                                </Tooltip>
                                            </Table.Th>
                                            <Table.Th>STATUS</Table.Th>
                                            <Table.Th>LOCATION</Table.Th>
                                            <Table.Th>Incident Breif Description</Table.Th>
                                        </Table.Tr>
                                    </Table.Thead>
                                    <Table.Tbody>{rowsSimilarIncidents ? rowsSimilarIncidents : 'No Record Found for the selected incident description.'}</Table.Tbody>
                                </Table>
                            </Table.ScrollContainer>
                        </Paper>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'ci_embending_rfcs'}>
                    <Accordion.Control>
                        <Group wrap="nowrap">
                            <Avatar src={'https://img.icons8.com/clouds/256/000000/futurama-bender.png'} radius="xl" size="lg" />
                            <div>
                                <Text>{'CI based / Embending based Rfcs'}</Text>
                                <Text size="sm" c="dimmed" fw={400}>
                                    {'CI based / Embending based Information by network name'}
                                </Text>
                            </div>
                        </Group>
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Paper className="paperTbl">
                            <Text
                                size="xl"
                                fw={700}
                                c={'blue'}
                                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                                pb={10}
                            >
                                CI Based Rfcs
                            </Text>
                            <Table.ScrollContainer minWidth={500}>
                            <Table striped highlightOnHover withTableBorder withColumnBorders stickyHeader className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                                <Table.Thead style={{position: 'static'}}>
                                    <Table.Tr>
                                        <Table.Th>RFC Number</Table.Th>
                                        <Table.Th>STATUS</Table.Th>
                                        <Table.Th>OPEN TIME</Table.Th>
                                        <Table.Th>NETWORK NAME</Table.Th>
                                        <Table.Th>ASSIGN DEPT</Table.Th>
                                        <Table.Th>BRIEF DESCRIPTION</Table.Th>
                                        <Table.Th>LOCATION</Table.Th>
                                    </Table.Tr>
                                </Table.Thead>
                                <Table.Tbody>{rowsCIRfc ? rowsCIRfc : 'No record found'}</Table.Tbody>
                            </Table>
                        </Table.ScrollContainer>
                        </Paper>
                        <Paper className="paperTbl">
                            <Text
                                size="xl"
                                fw={700}
                                c={'red'}
                                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                                pb={10}
                            >
                                Embending Based Rfcs
                            </Text>
                            <Table.ScrollContainer minWidth={500}>
                                <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{ whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden' }}>
                                    <Table.Thead style={{ position: 'static' }}>
                                        <Table.Tr>
                                            <Table.Th>Incident Number</Table.Th>
                                            <Table.Th>
                                                Similarity Score
                                                <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Similarity score represents how similar an RFC is based on description and event title">
                                                    <IconInfoCircle size={20} />
                                                </Tooltip>
                                            </Table.Th>
                                            <Table.Th>STATUS</Table.Th>
                                            <Table.Th>LOCATION</Table.Th>
                                            <Table.Th>Incident Breif Description</Table.Th>
                                        </Table.Tr>
                                    </Table.Thead>
                                    <Table.Tbody>{rowsSimilarRfc ? rowsSimilarRfc : 'No record found for the selected incident description'}</Table.Tbody>
                                </Table>
                            </Table.ScrollContainer>
                        </Paper>
                    </Accordion.Panel>
                </Accordion.Item>
                <Paper className="paperTbl" style={{ textAlign: 'left' }} mb={5}>
                    <ScrollArea h={350}>
                        <Text fw={700}>Overall Runbook:</Text>
                        <div style={{ whiteSpace: "pre-line" }}>
                            {eventListDetails && eventListDetails.overall_runbook &&
                                reactStringReplace(eventListDetails.overall_runbook, regx, (match: any, i) => (
                                    <strong>
                                        {match}
                                    </strong>
                                ))
                            }
                        </div>
                    </ScrollArea>
                </Paper>
                <Accordion.Item value={'acc_similar_events'}>
                    <Accordion.Control>
                        <AccordionLabel label='Similar Events' image='' description="Similar event's based on Event title & incident description" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        {rowsSimilarEvents && rowsSimilarEvents.length > 0 &&
                            <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                                <ScrollArea h={350}>
                                    <Text fw={700}>GCC Notes:</Text>
                                    <div style={{ whiteSpace: "pre-line" }}>
                                        {eventListDetails && eventListDetails.gcc_notes &&
                                            eventListDetails.gcc_notes
                                        }
                                    </div>
                                </ScrollArea>
                            </Paper>
                        }
                        <Table.ScrollContainer minWidth={500}>
                            <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable"
                                style={{ whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden' }}
                            >
                                <Table.Thead style={{ position: 'static' }}>
                                    <Table.Tr>
                                        <Table.Th>Event ID</Table.Th>
                                        <Table.Th>
                                            Similarity Score
                                            <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Similarity score represents how similar two events are based on their title">
                                                <IconInfoCircle size={20} />
                                            </Tooltip>
                                        </Table.Th>
                                        <Table.Th>issue source</Table.Th>
                                        <Table.Th>Responsible Service Area</Table.Th>
                                        <Table.Th>Status</Table.Th>
                                        <Table.Th>Event Title</Table.Th>
                                    </Table.Tr>
                                </Table.Thead>
                                <Table.Tbody>{rowsSimilarEvents ? rowsSimilarEvents : 'No record found for the selected incident'}</Table.Tbody>
                            </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_similar_incidents'}>
                    <Accordion.Control>
                        <AccordionLabel label='Similar Incidents' image='' description="Similar Incidents based on incident description" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        {rowsSimilarIncidents && rowsSimilarIncidents.length > 0 &&
                            <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                                <ScrollArea h={350}>
                                    <Text fw={700}>Summary of Incident Steps:</Text>
                                    <div style={{ whiteSpace: "pre-line" }}>
                                        {eventListDetails && eventListDetails.incident_steps &&
                                            eventListDetails.incident_steps
                                        }
                                    </div>
                                </ScrollArea>
                            </Paper>
                        }
                        <Table.ScrollContainer minWidth={500}>
                            <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{ whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden' }}>
                                <Table.Thead style={{ position: 'static' }}>
                                    <Table.Tr>
                                        <Table.Th>Incident Number</Table.Th>
                                        <Table.Th>
                                            Similarity Score
                                            <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Similarity score represents how similar an incident is based on description and event title">
                                                <IconInfoCircle size={20} />
                                            </Tooltip>
                                        </Table.Th>
                                        <Table.Th>STATUS</Table.Th>
                                        <Table.Th>LOCATION</Table.Th>
                                        <Table.Th>Incident Breif Description</Table.Th>
                                    </Table.Tr>
                                </Table.Thead>
                                <Table.Tbody>{rowsSimilarIncidents ? rowsSimilarIncidents : 'No Record Found for the selected incident description.'}</Table.Tbody>
                            </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_similar_rfc'}>
                    <Accordion.Control>
                        <AccordionLabel label='Similar RFC' image='' description="Similar RFC based on incident description" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        {rowsSimilarRfc && rowsSimilarRfc.length > 0 &&
                            <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                                <ScrollArea h={350}>
                                    <Text fw={700}>RFC Steps:</Text>
                                    <div style={{ whiteSpace: "pre-line" }}>
                                        {eventListDetails && eventListDetails.rfc_steps &&
                                            eventListDetails.rfc_steps
                                        }
                                    </div>
                                </ScrollArea>
                            </Paper>
                        }
                        <Table.ScrollContainer minWidth={500}>
                            <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{ whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden' }}>
                                <Table.Thead style={{ position: 'static' }}>
                                    <Table.Tr>
                                        <Table.Th>Incident Number</Table.Th>
                                        <Table.Th>
                                            Similarity Score
                                            <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Similarity score represents how similar an RFC is based on description and event title">
                                                <IconInfoCircle size={20} />
                                            </Tooltip>
                                        </Table.Th>
                                        <Table.Th>STATUS</Table.Th>
                                        <Table.Th>LOCATION</Table.Th>
                                        <Table.Th>Incident Breif Description</Table.Th>
                                    </Table.Tr>
                                </Table.Thead>
                                <Table.Tbody>{rowsSimilarRfc ? rowsSimilarRfc : 'No record found for the selected incident description'}</Table.Tbody>
                            </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_similar_problems'}>
                    <Accordion.Control>
                        <AccordionLabel label='Similar Problems' image='' description="Similar problems based on incident description" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        {rowsSimilarProblems && rowsSimilarProblems.length > 0 &&
                            <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                                <ScrollArea h={350}>
                                    <Text fw={700}>Problem Data:</Text>
                                    <div style={{ whiteSpace: "pre-line" }}>
                                        {eventListDetails && eventListDetails.problem_data &&
                                            eventListDetails.problem_data
                                        }
                                    </div>
                                </ScrollArea>
                            </Paper>
                        }
                        <Table.ScrollContainer minWidth={500}>
                            <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{ whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden' }}>
                                <Table.Thead style={{ position: 'static' }}>
                                    <Table.Tr>
                                        <Table.Th>ID</Table.Th>
                                        <Table.Th>
                                            Similarity Score
                                            <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Similarity score represents how similar an problem is based on description and event title">
                                                <IconInfoCircle size={20} />
                                            </Tooltip>
                                        </Table.Th>
                                        <Table.Th>STATUS</Table.Th>
                                        <Table.Th>Problem Breif Description</Table.Th>
                                    </Table.Tr>
                                </Table.Thead>
                                <Table.Tbody>{rowsSimilarProblems ? rowsSimilarProblems : 'No record found for the selected incident description'}</Table.Tbody>
                            </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_similar_problems_tasks'}>
                    <Accordion.Control>
                        <AccordionLabel label='Similar Problems Tasks' image='' description="" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        {rowsSimilarProblemTasks && rowsSimilarProblemTasks.length > 0 &&
                            <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                                <ScrollArea h={350}>
                                    <Text fw={700}>Problem Task Data:</Text>
                                    <div style={{ whiteSpace: "pre-line" }}>
                                        {eventListDetails && eventListDetails.problem_task_data &&
                                            eventListDetails.problem_task_data
                                        }
                                    </div>
                                </ScrollArea>
                            </Paper>
                        }
                        <Table.ScrollContainer minWidth={500}>
                            <Table striped highlightOnHover withTableBorder withColumnBorders stickyHeader className="inctable" style={{ whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden' }}>
                                <Table.Thead style={{ position: 'static' }}>
                                    <Table.Tr>
                                        <Table.Th>ID</Table.Th>
                                        <Table.Th>
                                            Similarity Score
                                            <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Similarity score represents how similar an problem task is based on description and event title">
                                                <IconInfoCircle size={20} />
                                            </Tooltip>
                                        </Table.Th>
                                        <Table.Th>ASSIGNMENT</Table.Th>
                                        <Table.Th>Status</Table.Th>
                                        <Table.Th>Problem task Breif Description</Table.Th>
                                    </Table.Tr>
                                </Table.Thead>
                                <Table.Tbody>{rowsSimilarProblemTasks ? rowsSimilarProblemTasks : 'No record found for the selected incident description'}</Table.Tbody>
                            </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_network_data'}>
                    <Accordion.Control>
                        <AccordionLabel label='Triage Result' image='' description="" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <TriageSection triageDetails={triageDetails} loaderTriage={loaderTriage} />
                    </Accordion.Panel>
                </Accordion.Item>
            </Accordion>
        </>
    )
}

export default CommonOverview