import { Group, ThemeIcon, Button, Popover, Textarea, Stack, Radio, Text } from "@mantine/core"
import { IconThumbUp, IconThumbDown, IconRefresh } from "@tabler/icons-react"
import { useEffect, useState } from "react";
import classes from './Feedback.module.css';

const data = [
    { name: 'Incorrect answer', description: '' },
    { name: 'Not completely relevant', description: '' },
    { name: 'No answer provided when correlation exists', description: '' },
    { name: 'Incomplete answer', description: '' },
    { name: 'Other: Comments', description: '' },
];

const FeedbackForm = (props: any) => {
    const { handleReviewSubmit, handleRefreshAction, loading } = props;
    const [opened, setOpened] = useState(false);
    const [feedback, setFeedback] = useState<string | null>(null);
    const [feedbackOption, setFeedbackOption] = useState<string | null>('');

    // useEffect(() => {
    //     if(feedbackOption !== '') {
    //         setFeedback(feedbackOption + '-' + feedback);
    //     }
    // }, [feedbackOption])

    const cards = data.map((item) => (
        <Radio.Card className={classes.root} radius="md" value={item.name} key={item.name}>
          <Group wrap="nowrap" align="flex-start">
            <Radio.Indicator />
            <div>
              <Text className={classes.label}>{item.name}</Text>
              {/* <Text className={classes.description}>{item.description}</Text> */}
            </div>
          </Group>
        </Radio.Card>
    ));
    
    return <>
        <Group wrap="nowrap" p={10} justify="flex-end" style={{border: '1px solid cadetblue'}} mt={10}>
            <Button.Group>
                <Button type="button" variant="outline" disabled={loading} loading={loading} loaderProps={{ type: 'dots' }} onClick={() => handleReviewSubmit(true)}><IconThumbUp /></Button>
                <Popover width={300} position="bottom" withArrow shadow="md" opened={opened} onChange={setOpened}>
                    <Popover.Target>
                        <Button type="button" variant="outline" disabled={loading} loading={loading} loaderProps={{ type: 'dots' }} onClick={() => setOpened((o) => !o)}><IconThumbDown /></Button>
                    </Popover.Target>
                    <Popover.Dropdown bg="var(--mantine-color-body)">
                        <Stack
                            bg="var(--mantine-color-body)"
                            align="stretch"
                            justify="center"
                            gap="md"
                        >
                            <Radio.Group
                                value={feedbackOption}
                                onChange={setFeedbackOption}
                                label="Select reason"
                                description="Enhancing the user feedback thumbs down to select the following category selection"
                            >
                                <Stack pt="md" gap="xs">
                                {cards}
                                </Stack>
                            </Radio.Group>
                            <Textarea
                                label="Write your feedback"
                                // description="Input description"
                                placeholder="What could be improved? (Optional)"
                                onChange={(event) => setFeedback(feedbackOption !== '' ? (feedbackOption + ' - ' + event.currentTarget.value) : event.currentTarget.value)}
                            />
                            <Button variant="filled" onClick={() => { handleReviewSubmit(false, feedback, setOpened, feedbackOption) }} disabled={loading} loading={loading} loaderProps={{ type: 'dots' }}>Submit Review</Button>
                        </Stack>
                    </Popover.Dropdown>
                </Popover>
                <Button type="button" variant="outline" onClick={() => handleRefreshAction()} disabled={loading} loading={loading} loaderProps={{ type: 'dots' }}><IconRefresh /></Button>
            </Button.Group>
            {/* <ThemeIcon variant="outline" style={{ cursor: 'pointer' }} onClick={() => handleReviewSubmit(true)}>
                <IconThumbUp style={{ width: '70%', height: '70%' }} />
            </ThemeIcon>
            <ThemeIcon variant="outline" style={{ cursor: 'pointer' }} onClick={() => handleRefreshAction()}>
                <IconRefresh style={{ width: '70%', height: '70%' }} />
            </ThemeIcon> */}
        </Group>
    </>
}

export default FeedbackForm