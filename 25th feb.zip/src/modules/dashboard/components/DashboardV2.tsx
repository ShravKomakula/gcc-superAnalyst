import { useEffect, useState } from "react";
import { Group, Text, Stack, Paper, Button, Drawer, Input, ActionIcon, Menu, Box, ThemeIcon, useMantineTheme } from "@mantine/core"
import { useDisclosure } from '@mantine/hooks';
import { notifications } from "@mantine/notifications";
import { StyleContainer } from "../styles/Dashboard.styles"
import { getUniversalSearchAction } from "actions/Dashboard";
import { IconChevronDown, IconEyeSearch, IconSearch } from "@tabler/icons-react";
import classes from './Accordion.module.css'
import EventTable from "./EventTable";
import IncidentTable from "./IncidentTable";
import { getCurrPrevDaysformatDateTime, getformatedDateTime, showMessage } from "utils/Common";
import CiTable from "./CiTable";
import AdvancedTable from "./AdvancedTable";
import FDatePicker from "ui/datepicker/FDatePicker";
import Filter from "./Filter";
import { assignmentData } from "./data/assignmentData";
import { locationData } from "./data/locationData";
import { ciTypeData } from "./data/ciTypeData";
import MCombobox from "ui/mCombobox";

const DashboardV2 = () => {
    const theme = useMantineTheme();
    const [opened, { open, close }] = useDisclosure(false);
    const [rfcFilterValue, setRfcFilterValue] = useState<any>([
        getCurrPrevDaysformatDateTime(1, 0, 1),
        getCurrPrevDaysformatDateTime(0, 23, 59)
    ]);
    const [incidentFilterValue, setIncidentFilterValue] = useState<any>([
        getCurrPrevDaysformatDateTime(1, 0, 1),
        getCurrPrevDaysformatDateTime(0, 23, 59)
    ]);
    const [keyword, setKeyword] = useState<string>('');
    const [searchLocation, setSearchLocation] = useState<string>('');
    const [searchCIType, setSearchCIType] = useState<string>('');
    const [searchAssignment, setSearchAssignment] = useState<string>('');
    const [searchDate, setSearchDate] = useState<any>([
        getCurrPrevDaysformatDateTime(1, 0, 1),
        getCurrPrevDaysformatDateTime(0, 23, 59)
    ]);

    const [eventDetails, setEventDetails] = useState<any>({});
    const [eventPageNo, setEventPageNo] = useState<number>(1);
    const [loadingEvents, setLoadingEvents] = useState<boolean>(false);
    const [eventPageSize, setEventPageSize] = useState<number>(10);

    const [advanceDetails, setAdvanceDetails] = useState<any>({});
    const [advancePageNo, setAdvancePageNo] = useState<number>(1);
    const [loadingAdvance, setLoadingAdvance] = useState<boolean>(false);
    const [advancePageSize, setAdvancePageSize] = useState<number>(10);

    const [incidentDetails, setIncidentDetails] = useState<any>({});
    const [incidentPageNo, setIncidentPageNo] = useState<number>(1);
    const [loadingIncidents, setLoadingIncidents] = useState<boolean>(false);
    const [incidentPageSize, setIncidentPageSize] = useState<number>(10);

    const [ciDetails, setCiDetails] = useState<any>({});
    const [ciPageNo, setCiPageNo] = useState<number>(1);
    const [loadingCi, setLoadingCi] = useState<boolean>(false);
    const [ciPageSize, setCiPageSize] = useState<number>(10);

    const [searchType, setSearchType] = useState<string>("Search");

    useEffect(() => {
        if (keyword !== '') {
            handleKeywordSearch('event_list', eventPageNo, eventPageSize);
        }
    }, [eventPageNo, eventPageSize])

    useEffect(() => {
        if (keyword !== '') {
            handleKeywordSearch('incident_list', incidentPageNo, incidentPageSize);
        }
    }, [incidentPageNo, incidentPageSize])

    useEffect(() => {
        if (keyword !== '') {
            handleKeywordSearch('ci_list', ciPageNo, ciPageSize);
        }
    }, [ciPageNo, ciPageSize])

    useEffect(() => {
        if (keyword !== '') {
            handleKeywordSearch('advance_list', advancePageNo, advancePageSize);
        }
    }, [advancePageNo, advancePageSize])

    const handleKeywordSearch = (queryType: string, page: number, pageSize: number,) => {
        if (keyword === '') {
            notifications.show({
                color: 'red',
                title: 'Error!!',
                message: 'Please enter keyword to search!',
                classNames: classes,
            })
            return;
        }
        if (searchType === 'Advanced Search') {
            if (searchLocation === '') {
                notifications.show({
                    color: 'red',
                    title: 'Error!!',
                    message: 'Please enter location to search!',
                    classNames: classes,
                })
                open();
                return;
            }
            if ((searchCIType === '') && (searchAssignment === '')) {
                notifications.show({
                    color: 'red',
                    title: 'Error!!',
                    message: 'Please enter CI type or assignment to search!',
                    classNames: classes,
                })
                open();
                return;
            }
            if (searchDate.length === 0) {
                notifications.show({
                    color: 'red',
                    title: 'Error!!',
                    message: 'Please select timeline to search!',
                    classNames: classes,
                })
                open();
                return;
            }
        }

        if (queryType === '') {
            setEventPageNo(1)
            setIncidentPageNo(1)
            setCiPageNo(1)
            setAdvancePageNo(1);
        }
        if (queryType === '' || queryType === 'event_list') {
            setLoadingEvents(true);
        }
        if (queryType === '' || queryType === 'incident_list') {
            setLoadingIncidents(true);
        }
        if (queryType === '' || queryType === 'ci_list') {
            setLoadingCi(true);
        }
        if (queryType === '' || queryType === 'advance_list') {
            setLoadingAdvance(true);
        }
        const responseEvents = getUniversalSearchAction({
            query: keyword.trim(),
            limit: pageSize,
            page: page,
            query_type: queryType,
            advance_search: searchType === 'Advanced Search' ? true : false,
            location: searchType === 'Advanced Search' ? searchLocation : false,
            c_type: searchType === 'Advanced Search' ? searchCIType : false,
            assignment: searchType === 'Advanced Search' ? searchAssignment : false,
            start_date: searchType === 'Advanced Search' ? (searchDate && searchDate[0] ? getformatedDateTime(searchDate[0], 'YYYY-MM-DD HH:mm:ss.000') : null) : null,
            end_date: searchType === 'Advanced Search' ? (searchDate && searchDate[1] ? getformatedDateTime(searchDate[1], 'YYYY-MM-DD HH:mm:ss.000') : null) : null,
        });
        responseEvents.then((result: any) => {
            if (result && result.status === 404) {
                setLoadingEvents(false);
                setLoadingIncidents(false);
                setLoadingCi(false);
                setLoadingAdvance(false);
                setEventDetails({});
                setAdvanceDetails({});
                setIncidentDetails({});
                setCiDetails({});
                showMessage('red', 'Error!!', 'No Record found');
                return;
            }
            if (result) {
                if (result.result && result.result.event_list) {
                    setEventDetails(result.result.event_list);
                } else {
                    if (queryType === '') {
                        setEventDetails({});
                    }
                }
                if (result.result && result.result.adv_list) {
                    setAdvanceDetails(result.result.adv_list);
                } else {
                    if (queryType === '') {
                        setAdvanceDetails({});
                    }
                }
                if (result.result && result.result.incident_list) {
                    setIncidentDetails(result.result.incident_list);
                } else {
                    if (queryType === '') {
                        setIncidentDetails({});
                    }
                }
                if (result.result && result.result.ci_list) {
                    setCiDetails(result.result.ci_list);
                } else {
                    if (queryType === '') {
                        setCiDetails({});
                    }
                }
                close();
            }
            setLoadingEvents(false);
            setLoadingIncidents(false);
            setLoadingCi(false);
            setLoadingAdvance(false);
        });
    }

    return (
        <StyleContainer fluid>
            <Drawer position="right" offset={8} radius="md" opened={opened} onClose={close} title={<Text fw={500}>Advanced Search</Text>}>
                <Box style={{ overflow: 'hidden' }}>
                    <Box maw={'100%'} p="md" mx="auto" style={{ border: "1px solid #dee2e6", borderRadius: "var(--mantine-radius-sm)" }}>
                        <Stack justify="center" gap={'md'}>
                            <Stack
                                align="flext-start"
                                justify="flext-start"
                                gap="0"
                            >
                                <Text size="sm" fw={700}>
                                    Keyword*
                                </Text>
                                <Input w={'100%'} mr={5} size="md" rightSection={<IconSearch size={16} />}
                                    placeholder="Enter Keyword, Event/Incident details"
                                    onKeyDown={event => { event.key === 'Enter' && handleKeywordSearch("", 1, 10) }}
                                    onChange={(event: any) => setKeyword(event.currentTarget.value)}
                                    value={keyword}
                                    disabled={(loadingEvents || loadingIncidents || loadingCi || loadingAdvance)}
                                />
                            </Stack>
                            <Stack
                                align="flext-start"
                                justify="flext-start"
                                gap="0"
                            >
                                <Text size="sm" fw={700}>Location*</Text>
                                <MCombobox
                                    data={locationData}
                                    value={searchLocation}
                                    setValue={setSearchLocation}
                                    disabled={(loadingEvents || loadingIncidents || loadingCi || loadingAdvance)}
                                />
                            </Stack>
                            <Stack
                                align="stretch"
                                justify="center"
                                gap="0"
                            >
                                <Text size="sm" fw={700}>Assignment</Text>
                                <MCombobox
                                    data={assignmentData}
                                    value={searchAssignment}
                                    setValue={setSearchAssignment}
                                    disabled={(loadingEvents || loadingIncidents || loadingCi || loadingAdvance)}
                                />
                            </Stack>
                            <Stack
                                align="stretch"
                                justify="center"
                                gap="0"
                            >
                                <Text size="sm" fw={700}>CI Type</Text>
                                <MCombobox
                                    data={ciTypeData}
                                    value={searchCIType}
                                    setValue={setSearchCIType}
                                    disabled={(loadingEvents || loadingIncidents || loadingCi || loadingAdvance)}
                                />
                            </Stack>
                            <Stack
                                align="stretch"
                                justify="center"
                                gap="0"
                            >
                                <Text size="sm" fw={700}>
                                    Timeline
                                </Text>
                                <FDatePicker
                                    enableTime={true}
                                    dateFormat='Y-m-d H:i'
                                    inputWidth={'100%'}
                                    setValue={setSearchDate}
                                    defaultDate={searchDate}
                                    disabled={(loadingEvents || loadingIncidents || loadingCi || loadingAdvance)}
                                />
                            </Stack>
                            
                            <Stack
                                align="stretch"
                                justify="center"
                                gap="0"
                            >
                                <Button
                                    size="md"
                                    className={classes.button}
                                    variant="outline"
                                    color={"rgb(77, 77, 255)"}
                                    disabled={loadingEvents || loadingIncidents || loadingCi || loadingAdvance}
                                    onClick={() => handleKeywordSearch("", 1, 10)}
                                >
                                    {'Search'}
                                </Button>
                            </Stack>
                        </Stack>
                    </Box>
                </Box>
            </Drawer>
            <Paper className="paperTbl">
                <Group justify="center" wrap="nowrap" gap={0} pb={0}>
                    <Input w={'500px'} mr={5} size="md" rightSection={<IconSearch size={14} />}
                        placeholder="Enter Keyword, Event/Incident details"
                        onKeyDown={event => { event.key === 'Enter' && handleKeywordSearch("", 1, 10) }}
                        onChange={(event: any) => setKeyword(event.currentTarget.value)}
                        value={keyword}
                        disabled={(loadingEvents || loadingIncidents || loadingCi || loadingAdvance)}
                    />
                    <Button
                        size="md"
                        className={classes.button}
                        variant="outline"
                        color={"rgb(77, 77, 255)"}
                        disabled={loadingEvents || loadingIncidents || loadingCi || loadingAdvance}
                        onClick={() => {
                            if(searchType === 'Advanced Search') {
                                open();
                            } else {
                                handleKeywordSearch("", 1, 10)
                            }
                        }}
                    >
                        {searchType}
                    </Button>
                    <Menu transitionProps={{ transition: 'pop' }} position="bottom-end" withinPortal>
                        <Menu.Target>
                            <ActionIcon
                                disabled={loadingEvents || loadingIncidents || loadingCi || loadingAdvance}
                                variant="outline"
                                // color={"rgb(77, 77, 255)"}
                                size={42}
                            // className={classes.menuControl}
                            >
                                <ThemeIcon variant="filled" color={"rgb(77, 77, 255)"}>
                                    <IconChevronDown size={16} stroke={1.5} />
                                </ThemeIcon>
                            </ActionIcon>
                        </Menu.Target>
                        <Menu.Dropdown>
                            <Menu.Item
                                leftSection={<IconEyeSearch size={16} stroke={1.5} color={theme.colors.blue[5]} />}
                            >
                                <Text onClick={() => setSearchType('Search')}>Search</Text>
                            </Menu.Item>
                            <Menu.Item
                                leftSection={<IconSearch size={14} stroke={1.5} color={theme.colors.blue[5]} onClick={() => setSearchType('Advanced Search')} />}
                            >
                                <Text onClick={() => {
                                    setSearchType('Advanced Search')
                                    open();
                                }}>Advanced Search</Text>
                            </Menu.Item>
                        </Menu.Dropdown>
                    </Menu>
                </Group>
                {((eventDetails && eventDetails.data && eventDetails.data.length > 0) || (incidentDetails && incidentDetails.data && incidentDetails.data.length > 0) ||
                    (ciDetails && ciDetails.data && ciDetails.data.length > 0)) &&
                    <Paper className="filterSection" mb={10} pt={0} style={{ display: "flex", justifyContent: "space-around" }}>
                        <Group justify="center" p={10} style={{ flexWrap: "wrap", display: "flex", gap: "1rem" }}>
                            <Filter
                                setRfcFilterValue={setRfcFilterValue}
                                rfcFilterValue={rfcFilterValue}
                                incidentFilterValue={incidentFilterValue}
                                setIncidentFilterValue={setIncidentFilterValue}
                            />
                        </Group>
                    </Paper>
                }
                <EventTable
                    currPage={eventPageNo}
                    setCurrPage={setEventPageNo}
                    pageSize={eventPageSize}
                    setPageSize={setEventPageSize}
                    totalRecords={eventDetails && eventDetails.total_matches ? eventDetails.total_matches : 0}
                    data={eventDetails && eventDetails.data ? eventDetails.data : []}
                    fetching={loadingEvents}
                    rfcFilterValue={rfcFilterValue}
                    incidentFilterValue={incidentFilterValue}
                />
                <IncidentTable
                    currPage={incidentPageNo}
                    setCurrPage={setIncidentPageNo}
                    pageSize={incidentPageSize}
                    setPageSize={setIncidentPageSize}
                    totalRecords={incidentDetails && incidentDetails.total_matches ? incidentDetails.total_matches : 0}
                    data={incidentDetails && incidentDetails.data ? incidentDetails.data : []}
                    fetching={loadingIncidents}
                    rfcFilterValue={rfcFilterValue}
                    incidentFilterValue={incidentFilterValue}
                />
                <CiTable
                    currPage={ciPageNo}
                    setCurrPage={setCiPageNo}
                    pageSize={ciPageSize}
                    setPageSize={setCiPageSize}
                    totalRecords={ciDetails && ciDetails.total_matches ? ciDetails.total_matches : 0}
                    data={ciDetails && ciDetails.data ? ciDetails.data : []}
                    fetching={loadingCi}
                    rfcFilterValue={rfcFilterValue}
                    incidentFilterValue={incidentFilterValue}
                />
                <AdvancedTable
                    currPage={advancePageNo}
                    setCurrPage={setAdvancePageNo}
                    pageSize={advancePageSize}
                    setPageSize={setAdvancePageSize}
                    totalRecords={advanceDetails && advanceDetails.total_matches ? advanceDetails.total_matches : 0}
                    data={advanceDetails && advanceDetails.data ? advanceDetails.data : []}
                    fetching={loadingAdvance}
                    rfcFilterValue={rfcFilterValue}
                    incidentFilterValue={incidentFilterValue}
                />
            </Paper>
        </StyleContainer>
    )
}

export default DashboardV2