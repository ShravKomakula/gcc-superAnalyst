import { useEffect, useState } from "react";
import { Group, Text, Stack, Paper, Button, Input, Accordion } from "@mantine/core"
import { useDisclosure } from '@mantine/hooks';
import { StyleContainer } from "../styles/Dashboard.styles"
import { Icons } from "assets/images"
import { CSVLink } from "react-csv";
import { useNavigate } from 'react-router-dom';
import PageHeader from "./PageHeader";
import { Route_URL } from "utils/constants/RouteURL";
import { getDashboardAction, getDashboardICAction, getDashboardICKeywordAction, getDashboardKeywordAction, getEventByIdAction, getIncidentByIdAction } from "actions/Dashboard";
import { IconSearch } from "@tabler/icons-react";
import TriageDetails from "./TriageDetails";
import classes from './Accordion.module.css'
import SliderFilter from "./SliderFilter";
import EventTable from "./EventTable";
import IncidentTable from "./IncidentTable";

const perPageLimit = 1000000;

const Dashboard = () => {
    const navigate = useNavigate()
    const [activeTab, setActiveTab] = useState<string | null>('events');
    const [selectedRows, setSelectedRows] = useState<number[]>([]);
    const [currPage, setCurrPage] = useState<number>(1);
    const [eventDetails, setEventDetails] = useState<any>([]);
    const [currPageIncidents, setCurrPageIncidents] = useState<number>(1);
    const [incidentDetails, setIncidentDetails] = useState<any>([]);
    const [eventNum, setEventNum] = useState<string>('');
    const [rfcFilterValue, setRfcFilterValue] = useState<number>(1);
    const [incidentFilterValue, setIncidentFilterValue] = useState<number>(1);
    const [rfcIncFilterValue, setRfcIncFilterValue] = useState<number>(1);
    const [incidentIncFilterValue, setIncidentIncFilterValue] = useState<number>(1);
    const [incidentNum, setIncidentNum] = useState<string>('');
    const [eventKeyword, setEventKeyword] = useState<string>('');
    const [incidentKeyword, setIncidentKeyword] = useState<string>('');
    const [listData, setListData] = useState<any>();
    const [visible, handlers] = useDisclosure(false);
    const [loadingEvents, setLoadingEvents] = useState<boolean>(false);
    const [loadingIncidents, setLoadingIncidents] = useState<boolean>(false);
    const [showPagination, setShowPagination] = useState<boolean>(false);
    const [showPaginationIncidents, setShowPaginationIncidents] = useState<boolean>(false);

    useEffect(() => {
        setLoadingEvents(true);
        const responseEvents = getDashboardAction({ page: currPage, per_page: perPageLimit });
        responseEvents.then((result: any) => {
            if (result && result.length > 0) {
                setShowPagination(true);
                setEventDetails(result);
            }
            setLoadingEvents(false);
        });
    }, [currPage])

    useEffect(() => {
        setLoadingIncidents(true);
        const responseIncidents = getDashboardICAction({ page: currPageIncidents, per_page: perPageLimit });
        responseIncidents.then((result: any) => {
            if (result && result.length > 0) {
                setShowPaginationIncidents(true);
                setIncidentDetails(result);
            }
            setLoadingIncidents(false);
        });
    }, [currPageIncidents])

    const handleEventSearch = () => {
        if (eventNum === '') {
            setLoadingEvents(true);
            const responseEvents = getDashboardAction({ page: currPage, per_page: perPageLimit });
            responseEvents.then((result: any) => {
                if (result && result.length > 0) {
                    setShowPagination(true);
                }
                setEventDetails(result);
                setLoadingEvents(false);
            });
            return;
        }
        setLoadingEvents(true);
        const responseEvents = getEventByIdAction({ id: eventNum });
        responseEvents.then((result: any) => {
            if (result && (result.status === 404 || result.status === 422)) {
                setLoadingEvents(false);
                setShowPagination(false);
                setEventDetails([]);
                return;
            }
            setShowPagination(false);
            if (result && result.event_id) {
                setEventDetails([result]);
            }
            setLoadingEvents(false);
        });
    }

    const handleIncidentSearch = () => {
        if (incidentNum === '') {
            setLoadingIncidents(true);
            const responseEvents = getDashboardICAction({ page: currPage, per_page: perPageLimit });
            responseEvents.then((result: any) => {
                if (result && result.length > 0) {
                    setShowPaginationIncidents(true);
                }
                setIncidentDetails(result);
                setLoadingIncidents(false);
            });
            return;
        }
        setLoadingIncidents(true);
        const responseEvents = getIncidentByIdAction({ id: incidentNum });
        responseEvents.then((result: any) => {
            if (result && result.status === 404) {
                setLoadingIncidents(false);
                setShowPaginationIncidents(false);
                setIncidentDetails([]);
                return;
            }
            setShowPaginationIncidents(false);
            setIncidentDetails([result]);
            setLoadingIncidents(false);
        });
    }

    const handleEventKeywordSearch = () => {
        if (eventKeyword === '') {
            setLoadingEvents(true);
            const responseEvents = getDashboardAction({ page: currPage, per_page: perPageLimit });
            responseEvents.then((result: any) => {
                if (result && result.length > 0) {
                    setShowPagination(true);
                }
                setEventDetails(result);
                setLoadingEvents(false);
            });
            return;
        }
        setLoadingEvents(true);
        const responseEvents = getDashboardKeywordAction({ query: eventKeyword });
        responseEvents.then((result: any) => {
            if (result && result.status === 404) {
                setLoadingEvents(false);
                setShowPagination(false);
                setEventDetails([]);
                return;
            }
            setShowPagination(false);
            setEventDetails(result);
            setLoadingEvents(false);
        });
    }

    const handleIncidentKeywordSearch = () => {
        if (incidentKeyword === '') {
            setLoadingIncidents(true);
            const responseEvents = getDashboardICAction({ page: currPage, per_page: perPageLimit });
            responseEvents.then((result: any) => {
                if (result && result.length > 0) {
                    setShowPaginationIncidents(false);
                }
                setIncidentDetails(result);
                setLoadingIncidents(false);
            });
            return;
        }
        setLoadingIncidents(true);
        const responseEvents = getDashboardICKeywordAction({ query: incidentKeyword });
        responseEvents.then((result: any) => {
            if (result && result.status === 404) {
                setLoadingIncidents(false);
                setShowPaginationIncidents(false);
                setIncidentDetails([]);
                return;
            }
            setShowPaginationIncidents(false);
            setIncidentDetails(result);
            setLoadingIncidents(false);
        });
    }

    return (
        <StyleContainer fluid>
            {/* <LoadingOverlay loaderProps={{ color: '#000484' }} visible={visible} zIndex={1000} overlayProps={{ radius: "sm", blur: 2 }} /> */}
            <PageHeader />
            <Paper className="paperTbl">
                <Accordion chevronPosition="right" variant="contained" pt={5} transitionDuration={200} classNames={classes} defaultValue={'event_list'}>
                    <Accordion.Item value={'event_list'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <div>
                                    <Group wrap="nowrap">
                                        <Text fw={600}>{'Event List'}</Text>
                                    </Group>
                                </div>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <Paper className="filterSection" mb={10} pt={0}>
                                <Group justify="center">
                                    <Stack
                                        align="stretch"
                                        justify="center"
                                        gap="0"
                                    >
                                        {/* <Text className="tableTitle">Events List</Text> */}
                                        {/* <Text size="sm" className="tableSubTitle">Server Potential Issues</Text> */}
                                    </Stack>
                                    <Group mb={10}>
                                        <SliderFilter rfcFilterValue={rfcFilterValue} setRfcFilterValue={setRfcFilterValue} incidentFilterValue={incidentFilterValue} setIncidentFilterValue={setIncidentFilterValue} />
                                        <Group justify="center" style={{ paddingTop: '20px' }}>
                                            <Input placeholder="Search By Keyword" mr={'-20px'} maw={145} value={eventKeyword} onKeyDown={event => { event.key === 'Enter' && handleEventKeywordSearch() }} onChange={(event: any) => setEventKeyword(event.currentTarget.value)} disabled={loadingEvents} />
                                            <Button onClick={() => { handleEventKeywordSearch() }} disabled={loadingEvents}><IconSearch size={18} /></Button>
                                        </Group>
                                        <Group justify="center" style={{ paddingTop: '20px' }}>
                                            <Input placeholder="Search By Event ID" mr={'-20px'} maw={145} value={eventNum} onKeyDown={event => { event.key === 'Enter' && handleEventSearch() }} onChange={(event: any) => setEventNum(event.currentTarget.value)} disabled={loadingEvents} />
                                            <Button onClick={() => { handleEventSearch() }} disabled={loadingEvents}><IconSearch size={18} /></Button>
                                        </Group>
                                        {/* <CSVLink data={listData ?? ''} filename="device_overview">
                                    <Image
                                        src={Icons.Imgicon_dowload_sm}
                                    />
                                </CSVLink> */}
                                        {/* <Image
                            src={Icons.Imgicon_3_dots_options}
                            onClick={() => { }}
                        /> */}
                                    </Group>
                                </Group>
                            </Paper>
                            <EventTable data={eventDetails} fetching={loadingEvents} rfcFilterValue={rfcFilterValue} incidentFilterValue={incidentFilterValue} />
                        </Accordion.Panel>
                    </Accordion.Item>
                    <Accordion.Item value={'incident_list'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <div>
                                    <Group wrap="nowrap">
                                        <Text fw={600}>{'Incident List'}</Text>
                                    </Group>
                                </div>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <Paper className="filterSection" mb={10} pt={0}>
                                <Group justify="center">
                                    <Stack
                                        align="stretch"
                                        justify="center"
                                        gap="0"
                                    >
                                        {/* <Text className="tableTitle">Incidents List</Text> */}
                                        {/* <Text size="sm" className="tableSubTitle">Server Potential Issues</Text> */}
                                    </Stack>
                                    <Group mb={10}>
                                        {/* <Button type="button" variant="filled" rightSection={<IconPlus size={14} />} className="btnCreate" onClick={() => {}}>Create</Button> */}
                                        <SliderFilter rfcFilterValue={rfcIncFilterValue} setRfcFilterValue={setRfcIncFilterValue} incidentFilterValue={incidentIncFilterValue} setIncidentFilterValue={setIncidentIncFilterValue} />
                                        <Group justify="center" style={{ paddingTop: '25px' }}>
                                            <Input placeholder="Search By Keyword" mr={'-20px'} maw={145}
                                                onKeyDown={event => { event.key === 'Enter' && handleIncidentKeywordSearch() }}
                                                onChange={(event: any) => setIncidentKeyword(event.currentTarget.value)}
                                                disabled={loadingIncidents}
                                            />
                                            <Button onClick={() => { handleIncidentKeywordSearch() }} disabled={loadingIncidents}><IconSearch size={18} /></Button>
                                        </Group>
                                        <Group justify="center" style={{ paddingTop: '25px' }}>
                                            <Input placeholder="Search by Incident ID" mr={'-20px'} maw={145}
                                                onKeyDown={event => { event.key === 'Enter' && handleIncidentSearch() }}
                                                onChange={(event: any) => setIncidentNum(event.currentTarget.value)}
                                                disabled={loadingIncidents}
                                            />
                                            <Button onClick={() => { handleIncidentSearch() }} disabled={loadingIncidents}><IconSearch size={18} /></Button>
                                        </Group>
                                        {/* <CSVLink data={listData ?? ''} filename="device_overview">
                                        <Image
                                            src={Icons.Imgicon_dowload_sm}
                                        />
                                    </CSVLink> */}
                                    </Group>
                                </Group>
                            </Paper>
                            <IncidentTable data={incidentDetails} fetching={loadingIncidents} rfcFilterValue={rfcIncFilterValue} incidentFilterValue={incidentIncFilterValue} />
                        </Accordion.Panel>
                    </Accordion.Item>
                </Accordion>
                {/* <TriageDetails /> */}
            </Paper>
        </StyleContainer>
    )
}

export default Dashboard