'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { Text, Paper, Skeleton, Anchor } from '@mantine/core';
import { sortBy } from 'lodash'
import { DataTable } from 'mantine-datatable';
import classes from '../styles/Table.styles.module.css';
import 'mantine-datatable/styles.css';
import { getAllCiBasedIncidentsAction, getAllCiBasedIncidentsCiAction, getEventsAllCiBasedIncidentsAction } from 'actions/Dashboard';
import { formatDateTime, formatFilterPayloadDateTime } from 'utils/Common';
import { CONFIGURATIONS } from 'utils/constants/configurations';

const PAGE_SIZES = [5, 10, 15, 20];

const CiBasedIncidents = (props: any) => {
    const { reqId, overviewType, filterValueTotal, rfcFilter, incidentFilter, subTitle } = props;
    const key = 'resize-complex-example';

    // const initialRecords = data && data.slice(0, PAGE_SIZE);

    const [sortStatus, setSortStatus] = useState<any>({
        columnAccessor: '',
        direction: '',
    });

    const [pageSize, setPageSize] = useState(PAGE_SIZES[0]);
    const [currPage, setCurrPage] = useState(1);
    const [records, setRecords] = useState<string[]>([]);
    const [latestRecords, setLatestRecords] = useState<string[]>([]);
    const [fetching, setFetching] = useState<boolean>(false);
    const [data, setData] = useState<any>([]);


    useEffect(() => {
        if(overviewType === 'INCIDENT') {
            setFetching(true);
            const responseEvents = getAllCiBasedIncidentsAction({
                "numberprgn": reqId,
                "title": subTitle,
                "incident_filter": formatFilterPayloadDateTime(incidentFilter),
                "rfc_filter": formatFilterPayloadDateTime(rfcFilter)
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data && result.data.ci_based_incidents) {
                    setData(result.data.ci_based_incidents);
                }
                setFetching(false);
            });
        } else if(overviewType === 'CI') {
            setFetching(true);
            const responseEvents = getAllCiBasedIncidentsCiAction({
                "numberprgn": reqId,
                "title": subTitle,
                "incident_filter": formatFilterPayloadDateTime(incidentFilter),
                "rfc_filter": formatFilterPayloadDateTime(rfcFilter)
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data && result.data.ci_based_incidents) {
                    setData(result.data.ci_based_incidents);
                }
                setFetching(false);
            });
        } else {
            setFetching(true);
            const responseEvents = getEventsAllCiBasedIncidentsAction({
                "numberprgn": reqId,
                "title": subTitle,
                "incident_filter": formatFilterPayloadDateTime(incidentFilter),
                "rfc_filter": formatFilterPayloadDateTime(rfcFilter)
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data && result.data.ci_based_incidents) {
                    setData(result.data.ci_based_incidents);
                }
                setFetching(false);
            });
        }
    }, [filterValueTotal])

    useEffect(() => {
        if(data && data.length > 0) {
            setRecords(data.slice(0, pageSize));
            setLatestRecords(data);
        }
    }, [data])

    useEffect(() => {
        const dataTmp = sortBy(latestRecords, sortStatus.columnAccessor);
        if(dataTmp && dataTmp.length > 0) {
            const sortData = sortStatus.direction === 'desc' ? dataTmp.reverse() : dataTmp;
            setLatestRecords(sortData);
            setRecords(sortData.slice(0, pageSize));
        }
    }, [sortStatus]);

    useEffect(() => {
        const from = (currPage - 1) * pageSize;
        const to = from + pageSize;
        if(latestRecords) {
            setRecords(latestRecords.slice(from, to));
        }
    }, [currPage, pageSize]);

    return (
        <Skeleton visible={fetching}>
        <Paper className="paperTbl">
            <Text
                size="lg"
                fw={700}
                // c={'red'}
                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                pb={10}
            >
                CI Based Incidents
            </Text>
            <DataTable
                // height="70dvh"
                minHeight={200}
                maxHeight={1000}
                withTableBorder
                highlightOnHover
                borderRadius="sm"
                withColumnBorders
                striped
                verticalAlign="top"
                pinLastColumn
                horizontalSpacing="xs"
                verticalSpacing="xs"
                fz="sm"
                records={records}
                classNames={{
                    // header: classes.header,
                }}
                storeColumnsKey={key}
                columns={[
                    {
                        accessor: 'numberprgn',
                        title: 'Incident ID',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ numberprgn }:any) => <Anchor href={`${CONFIGURATIONS.SMWEB_LINK}${numberprgn}`} target="_blank">
                            {numberprgn}
                        </Anchor>,
                    },
                    {
                        accessor: 'status', title: 'Status',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'open_time', title: 'Open Time',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ open_time }: any) => formatDateTime(open_time),
                    },
                    {
                        accessor: 'assignment', title: 'Assignment Group',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'location', title: 'Client Location',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'brief_description', title: 'Incident Brief Description',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    }
                ]}
                totalRecords={data && data.length}
                recordsPerPage={pageSize}
                page={currPage}
                fetching={fetching}
                onPageChange={(p) => setCurrPage(p)}
                recordsPerPageOptions={PAGE_SIZES}
                onRecordsPerPageChange={setPageSize}
                sortStatus={sortStatus}
                onSortStatusChange={setSortStatus}
                // 👇 uncomment the next line to use a custom pagination size
                // paginationSize="md"
                // 👇 uncomment the next line to use a custom loading text
                loadingText="Loading..."
                // 👇 uncomment the next line to display a custom text when no records were found
               emptyState={
                    <div style={{ textAlign: 'center', padding: '20px' }}>
                        <Text>No Results Found</Text>
                    </div>
                }
                noRecordsText=""
            // 👇 uncomment the next line to use a custom pagination text
                paginationText={({ from, to, totalRecords }) => `Records ${from} - ${to} of ${totalRecords}`}
            // 👇 uncomment the next lines to use custom pagination colors
                // paginationActiveBackgroundColor="green"
                // paginationActiveTextColor="#e6e348"
            />
        </Paper>
        </Skeleton>
    );
}

export default React.memo(CiBasedIncidents);