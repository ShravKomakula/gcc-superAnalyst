import { useState } from "react";
import { Paper, ScrollArea, Skeleton, Tabs, Text } from "@mantine/core";
import { notifications } from "@mantine/notifications";
import CorrIncidentLocation from "./CorrIncidentLocation";
import FeedbackForm from "../FeedbackForm";
import classes from '../Accordion.module.css'
import { submitCorrelationFeedbackAction } from "actions/Dashboard";
import CorrRfcsLocation from "./CorrRfcsLocation";
import CorrSameCiIncidents from "./CorrSameCiIncidents";
import CorrSameCiRfcs from "./CorrSameCiRfcs";
import CorrUpstreamIncidents from "./CorrUpstreamIncidents";
import CorrUpstreamRfcs from "./CorrUpstreamRfcs";
import CorrDownstramInfrastructureIncidents from "./CorrDownstramInfrastructureIncidents";
import CorrDownstramInfrastructureRfcs from "./CorrDownstramInfrastructureRfcs";
import CorrIncidentsAssignGroup from "./CorrIncidentsAssignGroup";
import CorrRfcsAssignGroup from "./CorrRfcsAssignGroup";
import CorrEvents from "./CorrEvents";
import CorrIncidentsbyType from "./CorrIncidentsbyType";
import CorrRfcsbyType from "./CorrRfcsbyType";
import { parseTextWithHyperlinks } from "utils/Common";

const CorrelationSection = (props: any) => {
    const { triageDetails, summaryData, fetching, 
        fetchSummary, handleRefreshAction, voxLocationLoading, voxLocationData, voxAppServerLoading,
        voxAppServerData, voxAssignedGroupLoading, voxAssignedGroupData,
        voxDeviceTypeLoading, voxDeviceTypeData, voxUpDownstreamLoading, voxUpDownstreamData,
        voxEventsLoading, voxEventsData, eventId } = props;

    const [feedbackLoading, setFeedbackLoading] = useState<boolean>(false);
    const [activeTab, setActiveTab] = useState<string | null>('summary');

    const handleCorrSummaryReview = (isPositive: boolean, feedback: string = '', togglePopover: any, reason: string = '') => {
        handleCorrSubmitReview(isPositive, feedback, togglePopover, 'summary', summaryData.vox_summary ?? '', reason);
    }

    const handleCorrLocationReview = (isPositive: boolean, feedback: string = '', togglePopover: any, reason: string = '') => {
        handleCorrSubmitReview(isPositive, feedback, togglePopover, 'location', voxLocationData && voxLocationData.vox_location && voxLocationData.vox_location[0] ? voxLocationData.vox_location[0] : '', reason);
    }

    const handleCorrCIReview = (isPositive: boolean, feedback: string = '', togglePopover: any, reason: string = '') => {
        handleCorrSubmitReview(isPositive, feedback, togglePopover, 'configuration', voxAppServerData && voxAppServerData.vox_app_server && voxAppServerData.vox_app_server[0] ? voxAppServerData.vox_app_server[0] : '', reason);
    }

    const handleCorrApplicationInfraReview = (isPositive: boolean, feedback: string = '', togglePopover: any, reason: string = '') => {
        handleCorrSubmitReview(isPositive, feedback, togglePopover, 'application', voxUpDownstreamData && voxUpDownstreamData.vox_up_downstream && voxUpDownstreamData.vox_up_downstream[0] ? voxUpDownstreamData.vox_up_downstream[0] : '', reason);
    }

    const handleCorrAssignmentGroupReview = (isPositive: boolean, feedback: string = '', togglePopover: any, reason: string = '') => {
        handleCorrSubmitReview(isPositive, feedback, togglePopover, 'assignment', voxAssignedGroupData && voxAssignedGroupData.vox_assign_group && voxAssignedGroupData.vox_assign_group[0] ? voxAssignedGroupData.vox_assign_group[0] : '', reason);
    }

    const handleCorrDC1Review = (isPositive: boolean, feedback: string = '', togglePopover: any, reason: string = '') => {
        handleCorrSubmitReview(isPositive, feedback, togglePopover, 'dc1', voxEventsData && voxEventsData.vox_events && voxEventsData.vox_events[0] ? voxEventsData.vox_events[0] : '', reason);
    }

    const handleCorrDeviceTypeReview = (isPositive: boolean, feedback: string = '', togglePopover: any, reason: string = '') => {
        handleCorrSubmitReview(isPositive, feedback, togglePopover, 'device', voxDeviceTypeData && voxDeviceTypeData.vox_device_type && voxDeviceTypeData.vox_device_type[0] ? voxDeviceTypeData.vox_device_type[0] : '', reason);
    }

    const handleCorrSubmitReview = (isPositive: boolean, feedback: string = '', togglePopover: any, tabType: string, llmResponse: string, reason: string = '') => {
        setFeedbackLoading(true);
        const responseEvents = submitCorrelationFeedbackAction({
            "tab_type": tabType,
            "llm_response": [llmResponse],
            "is_positive": isPositive,
            "text_feedback": feedback,
            'reason': reason,
            "id": eventId
        });
        responseEvents.then((result: any) => {
            if(result) {
                if(isPositive === false) {
                    togglePopover(false);
                }
                notifications.show({
                    color: 'green',
                    title: 'Success!!',
                    message: 'Thanks for submitting your Review, Your review has been submitted.',
                    classNames: classes,
                })
            } else {
                notifications.show({
                    color: 'red',
                    title: 'Error!!',
                    message: 'There is some issue, please try again!',
                    classNames: classes,
                })
            }
            setFeedbackLoading(false);
        });
    }

    return (
        <Paper className="paperTbl" style={{ textAlign: 'left' }}>
            <Tabs value={activeTab} onChange={setActiveTab} variant="outline">
                <Tabs.List>
                    <Tabs.Tab value="summary" leftSection={''}>
                        <Text fw={500} c={activeTab === 'summary' ? 'grey' : 'black'}>Summary</Text>
                    </Tabs.Tab>
                    <Tabs.Tab value="location" leftSection={''}>
                        <Text fw={500} c={activeTab === 'location' ? 'grey' : 'black'}>Location</Text>
                    </Tabs.Tab>
                    <Tabs.Tab value="network" leftSection={''}>
                        <Text fw={500} c={activeTab === 'network' ? 'grey' : 'black'}>Configuration Item</Text>
                    </Tabs.Tab>
                    <Tabs.Tab value="application_infrastructure" leftSection={''}>
                        <Text fw={500} c={activeTab === 'application_infrastructure' ? 'grey' : 'black'}>Application & Infrastructure</Text>
                    </Tabs.Tab>
                    <Tabs.Tab value="assigned_groups" leftSection={''}>
                        <Text fw={500} c={activeTab === 'assigned_groups' ? 'grey' : 'black'}>Assignment Groups</Text>
                    </Tabs.Tab>
                    <Tabs.Tab value="dc1_correlation" leftSection={''}>
                        <Text fw={500} c={activeTab === 'dc1_correlation' ? 'grey' : 'black'}>DC1 Correlation</Text>
                    </Tabs.Tab>
                    <Tabs.Tab value="device_type" leftSection={''}>
                        <Text fw={500} c={activeTab === 'device_type' ? 'grey' : 'black'}>Device Type</Text>
                    </Tabs.Tab>
                </Tabs.List>
                <Tabs.Panel value="summary">
                    <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                        <Skeleton visible={fetchSummary}>
                            <ScrollArea h={400}>
                                <div style={{ whiteSpace: "pre-line" }}>
                                    {summaryData && summaryData.vox_summary ? <div dangerouslySetInnerHTML={{ __html: parseTextWithHyperlinks(summaryData.vox_summary) }} /> : ''}
                                </div>
                            </ScrollArea>
                        </Skeleton>
                    </Paper>
                    { !fetchSummary && 
                        <FeedbackForm loading={feedbackLoading} handleReviewSubmit={handleCorrSummaryReview} handleRefreshAction={handleRefreshAction} />
                    }
                </Tabs.Panel>
                <Tabs.Panel value="location">
                    <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                        <Skeleton visible={voxLocationLoading}>
                            <div style={{ whiteSpace: "pre-line" }}>
                                {voxLocationData && voxLocationData.vox_location && voxLocationData.vox_location[0] ? voxLocationData.vox_location[0] : 'No data found'}
                            </div>
                        </Skeleton>
                    </Paper>
                    <CorrIncidentLocation data={voxLocationData && voxLocationData.vox_location && voxLocationData.vox_location[1] && Array.isArray(voxLocationData.vox_location[1]) ? voxLocationData.vox_location[1] : []} fetching={voxLocationLoading} />
                    <CorrRfcsLocation data={voxLocationData && voxLocationData.vox_location && voxLocationData.vox_location[2] && Array.isArray(voxLocationData.vox_location[2]) ? voxLocationData.vox_location[2] : []} fetching={voxLocationLoading} />
                    { !voxLocationLoading && 
                        <FeedbackForm loading={feedbackLoading} handleReviewSubmit={handleCorrLocationReview} handleRefreshAction={handleRefreshAction} />
                    }
                </Tabs.Panel>
                <Tabs.Panel value="network">
                    <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                        <Skeleton visible={voxAppServerLoading}>
                            <div style={{ whiteSpace: "pre-line" }}>
                                {voxAppServerData && voxAppServerData.vox_app_server && voxAppServerData.vox_app_server[0] ? voxAppServerData.vox_app_server[0] : 'No data found'}
                            </div>
                        </Skeleton>
                    </Paper>
                    <CorrSameCiIncidents data={voxAppServerData && voxAppServerData.vox_app_server && voxAppServerData.vox_app_server[1] && Array.isArray(voxAppServerData.vox_app_server[1]) ? voxAppServerData.vox_app_server[1] : []} fetching={voxAppServerLoading} />
                    <CorrSameCiRfcs data={voxAppServerData && voxAppServerData.vox_app_server && voxAppServerData.vox_app_server[2] && Array.isArray(voxAppServerData.vox_app_server[2]) ? voxAppServerData.vox_app_server[2] : []} fetching={voxAppServerLoading} />
                    { !voxAppServerLoading && 
                        <FeedbackForm loading={feedbackLoading} handleReviewSubmit={handleCorrCIReview} handleRefreshAction={handleRefreshAction} />
                    }
                </Tabs.Panel>
                <Tabs.Panel value="application_infrastructure">
                    <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                        <Skeleton visible={voxUpDownstreamLoading}>
                            <div style={{ whiteSpace: "pre-line" }}>
                                {voxUpDownstreamData && voxUpDownstreamData.vox_up_downstream && voxUpDownstreamData.vox_up_downstream[0] ? voxUpDownstreamData.vox_up_downstream[0] : 'No data found'}
                            </div>
                        </Skeleton>
                    </Paper>
                    <CorrUpstreamIncidents data={voxUpDownstreamData && voxUpDownstreamData.vox_up_downstream && voxUpDownstreamData.vox_up_downstream[1] && Array.isArray(voxUpDownstreamData.vox_up_downstream[1]) ? voxUpDownstreamData.vox_up_downstream[1] : []} fetching={voxUpDownstreamLoading} />
                    <CorrUpstreamRfcs data={voxUpDownstreamData && voxUpDownstreamData.vox_up_downstream && voxUpDownstreamData.vox_up_downstream[2] && Array.isArray(voxUpDownstreamData.vox_up_downstream[2]) ? voxUpDownstreamData.vox_up_downstream[2] : []} fetching={voxUpDownstreamLoading} />
                    <CorrDownstramInfrastructureIncidents data={voxUpDownstreamData && voxUpDownstreamData.vox_up_downstream && voxUpDownstreamData.vox_up_downstream[3] && Array.isArray(voxUpDownstreamData.vox_up_downstream[3]) ? voxUpDownstreamData.vox_up_downstream[3] : []} fetching={voxUpDownstreamLoading} />
                    <CorrDownstramInfrastructureRfcs data={voxUpDownstreamData && voxUpDownstreamData.vox_up_downstream && voxUpDownstreamData.vox_up_downstream[4] && Array.isArray(voxUpDownstreamData.vox_up_downstream[4]) ? voxUpDownstreamData.vox_up_downstream[4] : []} fetching={voxUpDownstreamLoading} />
                    { !voxUpDownstreamLoading && 
                        <FeedbackForm loading={feedbackLoading} handleReviewSubmit={handleCorrApplicationInfraReview} handleRefreshAction={handleRefreshAction} />
                    }
                </Tabs.Panel>
                <Tabs.Panel value="assigned_groups">
                    <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                        <Skeleton visible={voxAssignedGroupLoading}>
                            <div style={{ whiteSpace: "pre-line" }}>
                                {voxAssignedGroupData && voxAssignedGroupData.vox_assign_group && voxAssignedGroupData.vox_assign_group[0] ? voxAssignedGroupData.vox_assign_group[0] : 'No data found'}
                            </div>
                        </Skeleton>
                    </Paper>
                    <CorrIncidentsAssignGroup data={voxAssignedGroupData && voxAssignedGroupData.vox_assign_group && voxAssignedGroupData.vox_assign_group[1] && Array.isArray(voxAssignedGroupData.vox_assign_group[1]) ? voxAssignedGroupData.vox_assign_group[1] : []} fetching={voxAssignedGroupLoading} />
                    <CorrRfcsAssignGroup data={voxAssignedGroupData.vox_assign_group && voxAssignedGroupData.vox_assign_group[2] && Array.isArray(voxAssignedGroupData.vox_assign_group[2]) ? voxAssignedGroupData.vox_assign_group[2] : []} fetching={voxAssignedGroupLoading} />
                    { !voxAssignedGroupLoading && 
                        <FeedbackForm loading={feedbackLoading} handleReviewSubmit={handleCorrAssignmentGroupReview} handleRefreshAction={handleRefreshAction} />
                    }
                </Tabs.Panel>
                <Tabs.Panel value="dc1_correlation">
                    <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                        <Skeleton visible={voxEventsLoading}>
                            <div style={{ whiteSpace: "pre-line" }}>
                                {voxEventsData && voxEventsData.vox_events && voxEventsData.vox_events[0] ? voxEventsData.vox_events[0] : 'No data found'}
                            </div>
                        </Skeleton>
                    </Paper>
                    <CorrEvents data={voxEventsData && voxEventsData.vox_events && voxEventsData.vox_events[1] && Array.isArray(voxEventsData.vox_events[1]) ? voxEventsData.vox_events[1] : []} fetching={voxEventsLoading} />
                    { !voxEventsLoading && 
                        <FeedbackForm loading={feedbackLoading} handleReviewSubmit={handleCorrDC1Review} handleRefreshAction={handleRefreshAction} />
                    }
                </Tabs.Panel>
                <Tabs.Panel value="device_type">
                    <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                        <Skeleton visible={voxDeviceTypeLoading}>
                            <div style={{ whiteSpace: "pre-line" }}>
                                {voxDeviceTypeData && voxDeviceTypeData.vox_device_type && voxDeviceTypeData.vox_device_type[0] ? voxDeviceTypeData.vox_device_type[0] : 'No data found'}
                            </div>
                        </Skeleton>
                    </Paper>
                    <CorrIncidentsbyType data={voxDeviceTypeData && voxDeviceTypeData.vox_device_type && voxDeviceTypeData.vox_device_type[1] && Array.isArray(voxDeviceTypeData.vox_device_type[1]) ? voxDeviceTypeData.vox_device_type[1] : []} fetching={voxDeviceTypeLoading} />
                    <CorrRfcsbyType data={voxDeviceTypeData && voxDeviceTypeData.vox_device_type && voxDeviceTypeData.vox_device_type[2] && Array.isArray(voxDeviceTypeData.vox_device_type[2]) ? voxDeviceTypeData.vox_device_type[2] : []} fetching={voxDeviceTypeLoading} />
                    { !voxDeviceTypeLoading && 
                        <FeedbackForm loading={feedbackLoading} handleReviewSubmit={handleCorrDeviceTypeReview} handleRefreshAction={handleRefreshAction} />
                    }
                </Tabs.Panel>
            </Tabs>
        </Paper>
    )
}

export default CorrelationSection;