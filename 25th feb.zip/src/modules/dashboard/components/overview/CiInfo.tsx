import React from "react";
import { Paper, ScrollArea, Alert, Text, Group, List, Anchor } from "@mantine/core";
import { CONFIGURATIONS } from "utils/constants/configurations";

const BASE_URL = CONFIGURATIONS.CI_LINK;
const ciInfoKeys: any = {
    "logical_name": "CI ID",
    "network_name": "CI Name",
    "relationship_subtype": "Relationship Subtype",
    "istatus": "Status",
    "pfz_usage": "Usage",
    "type": "Type",
    "subtype": "Sub Type",
    "pfz_added_time": "Added Time",
    "operating_system": "Operating System",
    "location": "Client Location",
    // "pfz_assignment": "Assignment",
    "primary_ci_contact": "Primary CI Contact",
    "pfz_assignment": "CI Management Group",
    "primary_contact":"Primary Site Contact",
    "ci_contacts": "CI Contacts",
    // "pfz_esc_assignment": "Esc Assignment",
    "pfz_esc_assignment": "Incident Assignment Group",
    "site_category": "Site Category",
    "time_zone": "Time Zone",
    "corp_structure": "Corp Structure",
    "aliases": "Aliases",
    "r_logical_name": "Related CI ID",
    "r_network_name": "Related CI Name",
    "description": "Description"
}

const CiInfo = (props: any) => {
    const { detail } = props;

    return <React.Fragment>
        {detail ?
        <Paper className="paperTbl" style={{ textAlign: 'left' }}>
            <ScrollArea h={400}>
                <div style={{ whiteSpace: "pre-line" }}>
                    <List type="ordered">
                    { Object.keys(detail).map((obj: any) => {
                        const value = detail[obj];
                        return (
                            <List.Item key={obj}>
                                <Group wrap="nowrap">
                                    <Text fw={700}>{ciInfoKeys[obj]} :</Text>
                                    {/* Check if the key is "logical_name" and render a hyperlink */}
                                    {obj === "logical_name" ? (
                                        <Anchor
                                            href={`${BASE_URL}${value}`}
                                            target="_blank"
                                            style={{ textDecoration: "underline" }}
                                        >
                                            {value}
                                        </Anchor>
                                    ) : (
                                        <Text size="md">{value}</Text>
                                    )}
                                </Group>
                            </List.Item>
                        )
                    })}
                    </List>
                </div>
            </ScrollArea>
        </Paper>
        : <Alert variant="default" color="#000484" title="" icon={''} mb={10}>
            No CI Information Found.
        </Alert>}
    </React.Fragment>
}

export default CiInfo;