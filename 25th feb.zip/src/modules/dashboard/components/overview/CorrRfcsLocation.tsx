'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { Text, Paper, Skeleton, Anchor } from '@mantine/core';
import { sortBy } from 'lodash'
import { DataTable } from 'mantine-datatable';
import classes from '../styles/Table.styles.module.css';
import 'mantine-datatable/styles.css';
import { formatDateTime } from 'utils/Common';
import { CONFIGURATIONS } from 'utils/constants/configurations';

const PAGE_SIZES = [5, 10, 15, 20];

const CorrRfcsLocation = (props: any) => {
    const { data, fetching } = props;
    const key = 'resize-complex-example';

    // const initialRecords = data && data.slice(0, PAGE_SIZE);

    const [sortStatus, setSortStatus] = useState<any>({
        columnAccessor: '',
        direction: '',
    });

    const [pageSize, setPageSize] = useState(PAGE_SIZES[0]);
    const [currPage, setCurrPage] = useState(1);
    const [records, setRecords] = useState<string[]>([]);
    const [latestRecords, setLatestRecords] = useState<string[]>([]);

    useEffect(() => {
        if(data && data.length > 0) {
            setRecords(data.slice(0, pageSize));
            setLatestRecords(data);
        }
    }, [data])

    useEffect(() => {
        const dataTmp = sortBy(latestRecords, sortStatus.columnAccessor);
        if(dataTmp && dataTmp.length > 0) {
            const sortData = sortStatus.direction === 'desc' ? dataTmp.reverse() : dataTmp;
            setLatestRecords(sortData);
            setRecords(sortData.slice(0, pageSize));
        }
    }, [sortStatus]);

    useEffect(() => {
        const from = (currPage - 1) * pageSize;
        const to = from + pageSize;
        if(latestRecords) {
            setRecords(latestRecords.slice(from, to));
        }
    }, [currPage, pageSize]);

    return (
        <Skeleton visible={fetching}>
        <Paper className="paperTbl">
            <Text
                size="lg"
                fw={700}
                // c={'red'}
                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                pb={10}
            >
                Correlated RFCs by location
            </Text>
            <DataTable
                // height="70dvh"
                minHeight={200}
                maxHeight={1000}
                withTableBorder
                highlightOnHover
                borderRadius="sm"
                withColumnBorders
                striped
                verticalAlign="top"
                pinLastColumn
                horizontalSpacing="xs"
                verticalSpacing="xs"
                fz="sm"
                records={records}
                classNames={{
                    // header: classes.header,
                }}
                storeColumnsKey={key}
                columns={[
                    {
                        accessor: 'RFC',
                        title: 'RFC Id',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ RFC }: any) => <Anchor href={`${CONFIGURATIONS.SMWEBRFC_LINK}${RFC}`} target="_blank">
                        {RFC}
                    </Anchor>,
                    },
                    {
                        accessor: 'CONFIDENCE_SCORE',
                        title: 'Confidence Score',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'STATUS', title: 'Status',
                        width: 100,
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'OPEN_TIME', title: 'Open Time',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ OPEN_TIME }: any) => formatDateTime(OPEN_TIME),
                    },
                    {
                        accessor: 'LOCATION', title: 'Client Location',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'BRIEF_DESCRIPTION', title: 'Brief Description',
                        sortable: true,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    }
                ]}
                totalRecords={data && data.length}
                recordsPerPage={pageSize}
                page={currPage}
                fetching={fetching}
                onPageChange={(p) => setCurrPage(p)}
                recordsPerPageOptions={PAGE_SIZES}
                onRecordsPerPageChange={setPageSize}
                sortStatus={sortStatus}
                onSortStatusChange={setSortStatus}
                // 👇 uncomment the next line to use a custom pagination size
                // paginationSize="md"
                // 👇 uncomment the next line to use a custom loading text
                loadingText="Loading..."
                // 👇 uncomment the next line to display a custom text when no records were found
               emptyState={
                    <div style={{ textAlign: 'center', padding: '20px' }}>
                        <Text>No Results Found</Text>
                    </div>
                }
                noRecordsText=""
            // 👇 uncomment the next line to use a custom pagination text
                paginationText={({ from, to, totalRecords }) => `Records ${from} - ${to} of ${totalRecords}`}
            // 👇 uncomment the next lines to use custom pagination colors
                // paginationActiveBackgroundColor="green"
                // paginationActiveTextColor="#e6e348"
            />
        </Paper>
        </Skeleton>
    );
}

export default React.memo(CorrRfcsLocation);