'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { ActionIcon, Anchor, Button, Checkbox, Group, MultiSelect, Stack, Switch, TextInput, Text, Paper } from '@mantine/core';
import { useDebouncedValue } from '@mantine/hooks';
import { sortBy } from 'lodash'
import { IconSearch, IconX } from '@tabler/icons-react';
import { DataTable } from 'mantine-datatable';
import { CONFIGURATIONS } from "utils/constants/configurations";
import { Route_URL } from 'utils/constants/RouteURL';

import { formatDateTime } from 'utils/Common';
import 'mantine-datatable/styles.css';
// import classes from '../styles/Table.styles.module.css'

const PAGE_SIZES = [10, 15, 20];

const IncidentTable = (props: any) => {
    const { data, rfcFilterValue, incidentFilterValue, fetching, currPage, setCurrPage, totalRecords, pageSize, setPageSize } = props;
    const key = 'resize-complex-example';

    const [sortStatus, setSortStatus] = useState<any>({
        columnAccessor: '',
        direction: '',
    });
    // const [pageSize, setPageSize] = useState(PAGE_SIZES[1]);
    const [page, setPage] = useState(1);
    const [records, setRecords] = useState([]);
    const [latestRecords, setLatestRecords] = useState(data);

    const [searchIncidentId, setSearchIncidentId] = useState('');
    const [searchIncidentTitle, setSearchIncidentTitle] = useState('');
    const [searchNetworkName, setSearchNetworkName] = useState('');
    const [selectedStatus, setSelectedStatus] = useState<string[]>([]);
    const [debouncedQuery] = useDebouncedValue(searchIncidentId, 200);
    const [debouncedQueryTitle] = useDebouncedValue(searchIncidentTitle, 200);
    const [debouncedQueryNetworkName] = useDebouncedValue(searchNetworkName, 200);
    
    useEffect(() => {
        setRecords(data.slice(0, pageSize));
        setLatestRecords(data);
    }, [data])

    useEffect(() => {
        const dataTmp = sortBy(records, sortStatus.columnAccessor);
        setRecords(sortStatus.direction === 'desc' ? dataTmp.reverse() : dataTmp);
    }, [sortStatus]);

    useEffect(() => {
        const from = (currPage - 1) * pageSize;
        const to = from + pageSize;
        if(latestRecords) {
            setRecords(latestRecords.slice(from, to));
        }
    }, [currPage, pageSize]);

    useEffect(() => {
        if(data) {
            const filteredRecords = data.filter(({ NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS }: any) => {
                if (
                    debouncedQuery !== '' &&
                    !`${NUMBERPRGN}`.toLowerCase().includes(debouncedQuery.trim().toLowerCase())
                )
                    return false;
    
                if (
                    debouncedQueryTitle !== '' &&
                    !`${BRIEF_DESCRIPTION}`.toLowerCase().includes(debouncedQueryTitle.trim().toLowerCase())
                )
                    return false;
    
                if (
                    debouncedQueryNetworkName !== '' &&
                    !`${NETWORK_NAME}`.toLowerCase().includes(debouncedQueryNetworkName.trim().toLowerCase())
                )
                    return false;
    
                if (selectedStatus.length && !selectedStatus.some((d) => d === PROBLEM_STATUS)) return false;
    
                return true;
            });
    
            if(filteredRecords) {
                const from = (currPage - 1) * pageSize;
                const to = from + pageSize;
                setRecords(filteredRecords.slice(from, to));
                setLatestRecords(filteredRecords);
            }
        }
    }, [debouncedQuery, debouncedQueryTitle, debouncedQueryNetworkName, selectedStatus]);

    return (
        <Paper className="paperTbl">
            <Text
                size="lg"
                fw={700}
                // c={'red'}
                style={{ textDecoration: 'underline', textAlign: 'justify' }}
                pb={10}
            >
                Incident List
            </Text>
            <DataTable
                height={"auto"}
                minHeight={"20dvh"}
                // maxHeight={"50dvh"}
                withTableBorder
                highlightOnHover
                borderRadius="sm"
                withColumnBorders
                striped
                verticalAlign="top"
                pinLastColumn
                horizontalSpacing="xs"
                verticalSpacing="xs"
                fz="sm"
                records={records}
                classNames={{
                    // header: classes.header,
                }}
                storeColumnsKey={key}
                columns={[
                    {
                        accessor: 'numberprgn',
                        title: 'Incident ID',
                        width: '120px',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ numberprgn }) => <Anchor href={`${CONFIGURATIONS.SMWEB_LINK}${numberprgn}`} target="_blank">
                            {numberprgn}
                        </Anchor>,
                        // filter: (
                        //     <TextInput
                        //         label="Incident Id"
                        //         description="Show Incidents whose id include the specified text"
                        //         placeholder="Search incident id..."
                        //         leftSection={<IconSearch size={16} />}
                        //         rightSection={
                        //             <ActionIcon size="sm" variant="transparent" c="dimmed" onClick={() => setSearchIncidentId('')}>
                        //                 <IconX size={14} />
                        //             </ActionIcon>
                        //         }
                        //         value={searchIncidentId}
                        //         onChange={(e) => setSearchIncidentId(e.currentTarget.value)}
                        //     />
                        // ),
                        // filtering: searchIncidentId !== '',
                    },
                    {
                        accessor: 'brief_description',
                        title: 'Incident Brief Description',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ numberprgn, brief_description }) => <Anchor href={`${Route_URL.incidentOverview}?eventId=${numberprgn}&rfc_filter=${rfcFilterValue}&incident_filter=${incidentFilterValue}&eventTitle=${brief_description}`} target="_blank">
                            {brief_description}
                        </Anchor>,
                        // filter: (
                        //     <TextInput
                        //         label="Incident Brief Description"
                        //         description="Show incidents whose title include the specified text"
                        //         placeholder="Search incident title..."
                        //         leftSection={<IconSearch size={16} />}
                        //         rightSection={
                        //             <ActionIcon size="sm" variant="transparent" c="dimmed" onClick={() => setSearchIncidentTitle('')}>
                        //                 <IconX size={14} />
                        //             </ActionIcon>
                        //         }
                        //         value={searchIncidentTitle}
                        //         onChange={(e) => setSearchIncidentTitle(e.currentTarget.value)}
                        //     />
                        // ),
                        // filtering: searchIncidentTitle !== '',
                    },
                    {
                        accessor: 'location', title: 'Location',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'logical_name', title: 'CI ID',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left'
                    },
                    {
                        accessor: 'network_name', title: 'CI Name',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        // filter: (
                        //     <TextInput
                        //         label="CI Name"
                        //         description="Show all incidents with the specified text"
                        //         placeholder="Search by ci name..."
                        //         leftSection={<IconSearch size={16} />}
                        //         rightSection={
                        //             <ActionIcon size="sm" variant="transparent" c="dimmed" onClick={() => setSearchIncidentTitle('')}>
                        //                 <IconX size={14} />
                        //             </ActionIcon>
                        //         }
                        //         value={searchIncidentTitle}
                        //         onChange={(e) => setSearchNetworkName(e.currentTarget.value)}
                        //     />
                        // ),
                        // filtering: searchNetworkName !== '',
                    },
                    {
                        accessor: 'problem_status', title: 'Status',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        // filter: (
                        //     <MultiSelect
                        //         label="Status"
                        //         description="Show all events with the selected status"
                        //         data={['Pending Customer', 'Work in progress', 'Open', 'Resolved','Pending Pfizer', 'Restored', 'Pending Vendor', 'Pending RFC','Closed', 'Re-Opened']}
                        //         value={selectedStatus}
                        //         placeholder="Search status..."
                        //         onChange={setSelectedStatus}
                        //         leftSection={<IconSearch size={16} />}
                        //         clearable
                        //         searchable
                        //     />
                        // ),
                        // filtering: selectedStatus.length > 0,
                    },
                    {
                        accessor: 'open_time', title: 'Open Time',
                        sortable: false,
                        resizable: false,
                        toggleable: false,
                        draggable: false,
                        textAlign: 'left',
                        render: ({ open_time }) => formatDateTime(open_time),
                    }
                ]}
                totalRecords={totalRecords}
                recordsPerPage={pageSize}
                page={currPage}
                fetching={fetching}
                onPageChange={(p) => setCurrPage(p)}
                recordsPerPageOptions={PAGE_SIZES}
                onRecordsPerPageChange={setPageSize}
                sortStatus={sortStatus}
                onSortStatusChange={setSortStatus}
                // 👇 uncomment the next line to use a custom pagination size
                // paginationSize="md"
                // 👇 uncomment the next line to use a custom loading text
                loadingText="Loading..."
                // 👇 uncomment the next line to display a custom text when no records were found
               emptyState={
                    <div style={{ textAlign: 'center', padding: '20px' }}>
                        <Text>No Results Found</Text>
                    </div>
                }
                noRecordsText=""
            // 👇 uncomment the next line to use a custom pagination text
                paginationText={({ from, to, totalRecords }) => `Records ${from} - ${to} of ${totalRecords}`}
            // 👇 uncomment the next lines to use custom pagination colors
                // paginationActiveBackgroundColor="green"
                // paginationActiveTextColor="#e6e348"
            />
        </Paper>
    );
}

export default React.memo(IncidentTable)