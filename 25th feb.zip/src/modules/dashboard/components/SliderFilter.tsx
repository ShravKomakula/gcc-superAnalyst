import { Group, Stack, Tooltip, Slider, Text, SegmentedControl } from "@mantine/core";
import { IconInfoCircle } from "@tabler/icons-react";

const SliderFilter = (props: any) => {
    const { rfcFilterValue, setRfcFilterValue, incidentFilterValue, setIncidentFilterValue } = props
    
    return (
        <>
            <Group justify="center">
                <Stack
                    align="stretch"
                    justify="center"
                    gap="0"
                >
                    <Text size="sm" fw={700}>
                        RFC Filter
                        <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Filters will not apply to similarity results.">
                            <IconInfoCircle size={20} />
                        </Tooltip>
                    </Text>
                    <Slider
                        min={1}
                        max={30}
                        color="blue"
                        style={{ width: '200px' }}
                        thumbSize={20}
                        defaultValue={rfcFilterValue}
                        marks={[
                            { value: 1, label: '1' },
                            { value: 3, label: '3' },
                            { value: 5, label: '5' },
                            { value: 8, label: '8' },
                            { value: 10, label: '10' },
                            { value: 15, label: '15' },
                            { value: 24, label: '24' },
                            { value: 30, label: '30' },
                        ]}
                        onChange={(value: number) => setRfcFilterValue(value)}
                    />
                </Stack>
            </Group>
            <Group justify="center">
                <Stack
                    align="stretch"
                    justify="center"
                    gap="0"
                >
                    <Text size="sm" fw={700}>
                        Incident Filter
                        <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Filters will not apply to similarity results.">
                            <IconInfoCircle size={20} />
                        </Tooltip>
                    </Text>
                    <Slider
                        min={1}
                        max={30}
                        defaultValue={incidentFilterValue}
                        color="blue"
                        style={{ width: '200px' }}
                        thumbSize={20}
                        marks={[
                            { value: 1, label: '1' },
                            { value: 3, label: '3' },
                            { value: 5, label: '5' },
                            { value: 8, label: '8' },
                            { value: 10, label: '10' },
                            { value: 15, label: '15' },
                            { value: 24, label: '24' },
                            { value: 30, label: '30' },
                        ]}
                        onChange={(value: number) => setIncidentFilterValue(value)}
                    />
                </Stack>
                <SegmentedControl data={['Days', 'Hours']} mt={20} defaultValue={''} disabled={false} onChange={() => {}} />
            </Group>
        </>
    )
}

export default SliderFilter;