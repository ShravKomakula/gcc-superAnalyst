import { Group, Text, Avatar, Stack, Space } from "@mantine/core";
import { useEffect, useState } from "react";

const PageHeader = (props: any) => {
    const { title, subTitle } = props;
    const [username, setUsername] = useState('-');
    const localStorageData = localStorage.getItem('jwt_Token') ?? null;
    
    useEffect(() => {
        if(localStorageData) {
            const userInfo = JSON.parse(localStorageData);
            const fullname = userInfo.username.substring(0, userInfo.username.indexOf('@'));
            const fullnameArr = fullname.split('.');
            let fName = fullnameArr.shift(0);
            let lName = fullnameArr.pop();
            fName = fName[0].toUpperCase() + fName.slice(1);
            lName = lName[0].toUpperCase() + lName.slice(1);
            setUsername(`${fName} ${lName}`);
        }
    }, [localStorageData]);

    return (
        <Group justify="space-between">
            <Stack
                align="stretch"
                justify="left"
                style={{textAlign: 'left'}}
                gap="0"
            >
                <Text className="" size="xl" fw={700}>{title}</Text>
                { subTitle &&
                    <Text className="pageSubTitle">{subTitle}</Text>
                }
            </Stack>
            {/* <Group>
                <Avatar variant="filled" radius="sm" src="" />
                <Stack
                    align="stretch"
                    justify="center"
                    gap="0"
                >
                    <Text className="textUserName">
                        <span className="textHello">
                            Hello</span> <span className="textname">{username}
                        </span>
                    </Text> */}
                    {/* <Text size="sm" className="textRole">Sr. Database Engineer</Text> */}
                {/* </Stack>
            </Group> */}
        </Group>
    )
}

export default PageHeader;