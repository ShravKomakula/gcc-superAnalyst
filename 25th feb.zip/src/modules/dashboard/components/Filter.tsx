import { Group, Stack, Tooltip, Text } from "@mantine/core";
import { IconInfoCircle } from "@tabler/icons-react";
import FDatePicker from "ui/datepicker/FDatePicker";

const Filter = (props: any) => {
    const { rfcFilterValue, setRfcFilterValue, incidentFilterValue, setIncidentFilterValue } = props
    
    return (
        <>
            <Group justify="center">
                <Stack
                    align="stretch"
                    justify="center"
                    gap="0"
                >
                    <Text size="sm" fw={700}>
                        RFC Date Filter
                        <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Filters will not apply to similarity results.">
                            <IconInfoCircle size={20} />
                        </Tooltip>
                    </Text>
                    <FDatePicker
                        enableTime={true}
                        dateFormat='Y-m-d H:i'
                        inputWidth={380}
                        setValue={setRfcFilterValue}
                        defaultDate={rfcFilterValue}
                        // disabled={(loadingEvents || loadingIncidents || loadingCi || loadingAdvance)}
                    />
                </Stack>
            </Group>
            <Group justify="center">
                <Stack
                    align="stretch"
                    justify="center"
                    gap="0"
                >
                    <Text size="sm" fw={700}>
                        Incident Date Filter
                        <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Filters will not apply to similarity results.">
                            <IconInfoCircle size={20} />
                        </Tooltip>
                    </Text>
                    <FDatePicker
                        enableTime={true}
                        dateFormat='Y-m-d H:i'
                        inputWidth={380}
                        setValue={setIncidentFilterValue}
                        defaultDate={incidentFilterValue}
                        // disabled={(loadingEvents || loadingIncidents || loadingCi || loadingAdvance)}
                    />
                </Stack>
            </Group>
        </>
    )
}

export default Filter;