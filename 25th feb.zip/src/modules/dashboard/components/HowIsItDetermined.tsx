import React from "react";
import { Button, Group, Modal, Paper, ScrollArea, Text } from "@mantine/core";
import { useDisclosure } from '@mantine/hooks';

const HowIsItDetermined = () => {
    const [opened, { open, close }] = useDisclosure(false);

    return (
        <React.Fragment>
            <Group wrap="nowrap" justify="flex-end">
                <Button onClick={open} variant="transparent" type="button">How is it Determined?</Button>
            </Group>
            <Modal opened={opened} onClose={close} title="How is it Determined?" centered>
                <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                    <ScrollArea h={350}>
                        <Text size="md">
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                        </Text>
                    </ScrollArea>
                </Paper>
            </Modal>
        </React.Fragment>
    )
}

export default HowIsItDetermined;