import { useEffect, useState } from "react";
import {
    Paper, Table,
    Group,
    Text,
    ScrollArea,
    Accordion,
    Tooltip,
    Alert,
    Skeleton,
    Box
} from "@mantine/core";
import reactStringReplace from "react-string-replace";
import { IconRobot } from "@tabler/icons-react";
import classes from './Accordion.module.css'
import { notifications } from "@mantine/notifications";
import { formatFilterDateTimeString, formatFilterPayloadDateTime, parseTextWithHyperlinks } from "utils/Common";
import FeedbackForm from "./FeedbackForm";
import { getAllOthersDataAction, getCiTriageLlmAction, getEventAllOthersDataAction, getSimilaritySearchAction, getSummaryDataAction, submitCorrelationFeedbackAction, getTriageVoxLocationAction, getTriageVoxAppServerAction, getTriageVoxAssignGroupAction, getTriageVoxDeviceTypeAction, getTriageVoxDownstreamAction, getTriageVoxEventsAction, getInitialAnalysisAction } from "actions/Dashboard";
import CiInformationIncidentTab from "./overview/CiInformationIncidentTab";
import CiBasedIncidents from "./overview/CiBasedIncidents";
import CiBasedRfcs from "./overview/CiBasedRfcs";
import CiBasedEvents from "./overview/CiBasedEvents";
import CiBasedProblems from "./overview/CiBasedProblems";
import CiBasedProblemTasks from "./overview/CiBasedProblemTasks";
import IncidentLocation from "./overview/IncidentLocation";
import RfcLocation from "./overview/RfcLocation";
import IncidentGroupData from "./overview/IncidentGroupData";
import RfcGroupData from "./overview/RfcGroupData";
import CorrelationSection from "./overview/CorrelationSection";
import ProbabaleRootCauseSection from "./overview/ProbabaleRootCauseSection";
import SimilarityBasedEvents from "./overview/SimilarityBasedEvents";
import SimilarityBasedIncidents from "./overview/SimilarityBasedIncidents";
import SimilarityBasedRfcs from "./overview/SimilarityBasedRfcs";

// const regx = /(?=.)(.*?)(?=:)/gim;
const regx = /^(.*?:)/gim;

const CommonOverview = (props: any) => {
    const { rfcFilterValue, rfcFilterShowValue,
        incidentFilterValue, incidentFilterShowValue, eventId, subTitle, overviewType,
        filterValueTotal, setLoadingOverview
    } = props;
    const [feedbackLoading, setFeedbackLoading] = useState<boolean>(false);
    const [selectedRows, setSelectedRows] = useState<number[]>([]);
    const [allOthersDataLoading, setAllOthersDataLoading] = useState<boolean>(false);
    const [triageLoading, setTriageLoading] = useState<boolean>(false);
    const [voxLoading, setVoxLoading] = useState<any>({
        location: false,
        appServer: false
    });
    const [voxLocationLoading, setVoxLocationLoading] = useState<boolean>(false);
    const [voxLocationData, setVoxLocationData] = useState<any>({});
    const [voxAppServerLoading, setVoxAppServerLoading] = useState<boolean>(false);
    const [voxAppServerData, setVoxAppServerData] = useState<any>({});
    const [voxAssignedGroupLoading, setVoxAssignedGroupLoading] = useState<boolean>(false);
    const [voxAssignedGroupData, setVoxAssignedGroupData] = useState<any>({});
    const [voxDeviceTypeLoading, setVoxDeviceTypeLoading] = useState<boolean>(false);
    const [voxDeviceTypeData, setVoxDeviceTypeData] = useState<any>({});
    const [voxUpDownstreamLoading, setVoxUpDownstreamLoading] = useState<boolean>(false);
    const [voxUpDownstreamData, setVoxUpDownstreamData] = useState<any>({});
    const [voxEventsLoading, setVoxEventsLoading] = useState<boolean>(false);
    const [voxEventsData, setVoxEventsData] = useState<any>({});
    const [voxTotalTokenCount, setVoxTotalTokenCount] = useState<number>(0);

    const [summaryLoading, setSummaryLoading] = useState<boolean>(false);
    const [allOthersData, setAllOthersData] = useState<any>({});
    const [triageDetails, setTriageDetails] = useState<any>();
    const [summaryData, setSummaryData] = useState<any>();
    const [similaritySearchDetails, setSimilaritySearchDetails] = useState<any>();
    const [similaritySearchLoading, setSimilaritySearchLoading] = useState<boolean>(false);
    const [initialAnalysisData, setInitialAnalysisData] = useState<any>();
    const [initialAnalysisDataLoading, setInitialAnalysisDataLoading] = useState<boolean>(false);

    useEffect(() => {
        if (overviewType === 'INCIDENT') {
            handleGetInitialAnalysis();
            setAllOthersDataLoading(true);
            const responseEvents = getAllOthersDataAction({
                "numberprgn": eventId,
                "title": subTitle,
                "incident_filter": formatFilterPayloadDateTime(incidentFilterValue),
                "rfc_filter": formatFilterPayloadDateTime(rfcFilterValue)
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data) {
                    setAllOthersData(result.data);
                }
                setAllOthersDataLoading(false);
            });
        } else if (overviewType === 'CI') {

        } else {
            setAllOthersDataLoading(true);
            const responseEvents = getEventAllOthersDataAction({
                "numberprgn": eventId,
                "title": subTitle,
                "incident_filter": formatFilterPayloadDateTime(incidentFilterValue),
                "rfc_filter": formatFilterPayloadDateTime(rfcFilterValue)
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data) {
                    setAllOthersData(result.data);
                }
                setAllOthersDataLoading(false);
            });
        }
        handleGetTriageDetails();
        handleGetSimilaritySearch();
    }, [filterValueTotal])

    const handleGetInitialAnalysis = () => {
        setInitialAnalysisDataLoading(true);
        const responseEvents = getInitialAnalysisAction({
            "numberprgn": eventId,
            "title": subTitle,
            "incident_filter": formatFilterPayloadDateTime(incidentFilterValue),
            "rfc_filter": formatFilterPayloadDateTime(rfcFilterValue)
        });
        responseEvents.then((result: any) => {
            if (result && result.status === 404) {
                setInitialAnalysisDataLoading(false);
                return;
            }
            if (result) {
                setInitialAnalysisData(result);
            }
            setInitialAnalysisDataLoading(false);
        });
    }

    const handleGetSimilaritySearch = () => {
        setSimilaritySearchLoading(true);
        const responseEvents = getSimilaritySearchAction({
            "event_id": eventId,
            "input_query": subTitle,
            "incident_filter": formatFilterPayloadDateTime(incidentFilterValue),
            "rfc_filter": formatFilterPayloadDateTime(rfcFilterValue)
        });
        responseEvents.then((result: any) => {
            if (result && result.status === 404) {
                setSimilaritySearchLoading(false);
                return;
            }
            if (result) {
                setSimilaritySearchDetails(result);
            }
            setSimilaritySearchLoading(false);
        });
    }

    const handleGetTriageDetails = async () => {
        if (overviewType === 'CI') {
            setTriageLoading(true);
            setLoadingOverview(true);
            const responseEvents = getCiTriageLlmAction({
                "numberprgn": eventId,
                "title": subTitle,
                "incident_filter": formatFilterPayloadDateTime(incidentFilterValue),
                "rfc_filter": formatFilterPayloadDateTime(rfcFilterValue)
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data) {
                    setVoxLocationData({
                        vox_location: result.data.vox_location
                    });
                    setVoxAppServerData({
                        vox_app_server: result.data.vox_app_server
                    });
                    setVoxAssignedGroupData({
                        vox_assign_group: result.data.vox_assign_group
                    });
                    setVoxDeviceTypeData({
                        vox_device_type: result.data.vox_device_type
                    });
                    setVoxEventsData({
                        vox_events: result.data.vox_events
                    });
                    setVoxUpDownstreamData({
                        vox_up_downstream: result.data.vox_up_downstream
                    });
                    if(result && result.data) {
                        if(result.data.total_tokens) {
                            setVoxTotalTokenCount(result.data.total_tokens);
                        }
                        setSummaryData(result.data);
                    }
                    // setTriageDetails(result.data);
                }
                setTriageLoading(false);
                setLoadingOverview(false);
            });
        } else {
            setTriageLoading(true);
            setSummaryLoading(true);
            setLoadingOverview(true);
            Promise.all([
                handleGetVoxLocation(),
                handleGetVoxUpDownstream(),
                handleGetVoxAppServer(),
                handleGetVoxAssignedGroup(),
                handleGetVoxEvents(),
                handleGetVoxDeviceType()
            ]).then(function (values) {
                const [locationData, upDownstreamData, appServerData, assignGroupData, eventsData, deviceTypeData]: any = values;
                const tokenCount = (locationData.total_tokens ?? 0) + (upDownstreamData.total_tokens ?? 0) + (appServerData.total_tokens ?? 0) + (assignGroupData.total_tokens ?? 0) + (eventsData.total_tokens ?? 0) + (deviceTypeData.total_tokens ?? 0);
                // setVoxTotalTokenCount(tokenCount);
                setLoadingOverview(false);
                setSummaryLoading(false);
                handleGetSummaryData({
                    "title": locationData.title ?? subTitle,
                    "numberprgn": eventId,
                    "incident_filter": formatFilterPayloadDateTime(incidentFilterValue),
                    "rfc_filter": formatFilterPayloadDateTime(rfcFilterValue),
                    "triage_llm": "",
                    "vox_location": locationData.vox_location,
                    "vox_events": eventsData.vox_events,
                    "vox_app_server": appServerData.vox_app_server,
                    "vox_assign_group": assignGroupData.vox_assign_group,
                    "vox_up_downstream": upDownstreamData.vox_up_downstream,
                    "vox_device_type": deviceTypeData.vox_device_type,
                    "total_tokens": tokenCount
                });
                setTriageLoading(false);
            });
        }
    }

    const handleGetVoxLocation = () => {
        return new Promise((resolve, reject) => {
            setVoxLocationLoading(true);
            const responseEvents = getTriageVoxLocationAction({
                "numberprgn": eventId,
                "title": subTitle,
                "incident_filter": formatFilterPayloadDateTime(incidentFilterValue),
                "rfc_filter": formatFilterPayloadDateTime(rfcFilterValue)
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data) {
                    setVoxLocationData(result.data);
                }
                setVoxLocationLoading(false);
                if(result && result.data) {
                    resolve(result.data);
                } else {
                    resolve(true);
                }
            });
        });
    }

    const handleGetVoxUpDownstream = () => {
        return new Promise((resolve, reject) => {
            setVoxUpDownstreamLoading(true);
            const responseEvents = getTriageVoxDownstreamAction({
                "numberprgn": eventId,
                "title": subTitle,
                "incident_filter": formatFilterPayloadDateTime(incidentFilterValue),
                "rfc_filter": formatFilterPayloadDateTime(rfcFilterValue)
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data) {
                    setVoxUpDownstreamData(result.data);
                }
                setVoxUpDownstreamLoading(false);
                if(result && result.data) {
                    resolve(result.data);
                } else {
                    resolve(true);
                }
            });
        });
    }

    const handleGetVoxEvents = () => {
        return new Promise((resolve, reject) => {
            setVoxEventsLoading(true);
            const responseEvents = getTriageVoxEventsAction({
                "numberprgn": eventId,
                "title": subTitle,
                "incident_filter": formatFilterPayloadDateTime(incidentFilterValue),
                "rfc_filter": formatFilterPayloadDateTime(rfcFilterValue)
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data) {
                    setVoxEventsData(result.data);
                }
                setVoxEventsLoading(false);
                if(result && result.data) {
                    resolve(result.data);
                } else {
                    resolve(true);
                }
            });
        });
    }

    const handleGetVoxAppServer = () => {
        return new Promise((resolve, reject) => {
            setVoxAppServerLoading(true);
            const responseEvents = getTriageVoxAppServerAction({
                "numberprgn": eventId,
                "title": subTitle,
                "incident_filter": formatFilterPayloadDateTime(incidentFilterValue),
                "rfc_filter": formatFilterPayloadDateTime(rfcFilterValue)
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data) {
                    setVoxAppServerData(result.data);
                }
                setVoxAppServerLoading(false);
                if(result && result.data) {
                    resolve(result.data);
                } else {
                    resolve(true);
                }
            });
        });
    }

    const handleGetVoxAssignedGroup = () => {
        return new Promise((resolve, reject) => {
            setVoxAssignedGroupLoading(true);
            const responseEvents = getTriageVoxAssignGroupAction({
                "numberprgn": eventId,
                "title": subTitle,
                "incident_filter": formatFilterPayloadDateTime(incidentFilterValue),
                "rfc_filter": formatFilterPayloadDateTime(rfcFilterValue)
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data) {
                    setVoxAssignedGroupData(result.data);
                }
                setVoxAssignedGroupLoading(false);
                if(result && result.data) {
                    resolve(result.data);
                } else {
                    resolve(true);
                }
            });
        });
    }

    const handleGetVoxDeviceType = () => {
        return new Promise((resolve, reject) => {
            setVoxDeviceTypeLoading(true);
            const responseEvents = getTriageVoxDeviceTypeAction({
                "numberprgn": eventId,
                "title": subTitle,
                "incident_filter": formatFilterPayloadDateTime(incidentFilterValue),
                "rfc_filter": formatFilterPayloadDateTime(rfcFilterValue)
            });
            responseEvents.then((result: any) => {
                if (result && result.status === 404) {
                    return;
                }
                if (result && result.data) {
                    setVoxDeviceTypeData(result.data);
                }
                setVoxDeviceTypeLoading(false);
                if(result && result.data) {
                    resolve(result.data);
                } else {
                    resolve(true);
                }
            });
        });
    }

    const handleGetSummaryData = (triageData: any) => {
        setSummaryLoading(true);
        setLoadingOverview(true);
        const responseEvents = getSummaryDataAction({
            "numberprgn": triageData.numberprgn.toString(),
            "incident_filter": triageData.incident_filter,
            "rfc_filter": triageData.rfc_filter,
            "title": triageData.title ?? "",
            "triage_llm": triageData.triage_llm ?? "",
            "vox_location": triageData.vox_location ?? [],
            "vox_events": triageData.vox_events ?? [],
            "vox_app_server": triageData.vox_app_server ?? [],
            "vox_assign_group": triageData.vox_assign_group ?? [],
            "vox_up_downstream": triageData.vox_up_downstream ?? [],
            "vox_device_type": triageData.vox_device_type ?? [],
            "total_tokens": triageData.total_tokens ?? 0
        });
        responseEvents.then((result: any) => {
            if (result && result.status === 404) {
                return;
            }
            if (result && result.data) {
                setSummaryData(result.data);
                if(result.data.total_tokens) {
                    setVoxTotalTokenCount(result.data.total_tokens);
                }
            }
            setSummaryLoading(false)
            setLoadingOverview(false);
        });

    }


    const handleTriageReviewSubmit = (isPositive: boolean, feedback: string = '', togglePopover: any, reason: string = '') => {
        handleCorrSubmitReview(isPositive, feedback, togglePopover, 'triage', summaryData && summaryData.llm_rca ? summaryData.llm_rca : '', reason);
    }

    const handleCorrSubmitReview = (isPositive: boolean, feedback: string = '', togglePopover: any, tabType: string, llmResponse: string, reason: string = '') => {
        setFeedbackLoading(true);
        const responseEvents = submitCorrelationFeedbackAction({
            "tab_type": tabType,
            "llm_response": [llmResponse],
            "is_positive": isPositive,
            "text_feedback": feedback,
            "reason": reason,
            "id": eventId
        });
        responseEvents.then((result: any) => {
            if (result) {
                if (isPositive === false) {
                    togglePopover(false);
                }
                notifications.show({
                    color: 'green',
                    title: 'Success!!',
                    message: 'Thanks for submitting your Review, Your review has been submitted.',
                    classNames: classes,
                })
            } else {
                notifications.show({
                    color: 'red',
                    title: 'Error!!',
                    message: 'There is some issue, please try again!',
                    classNames: classes,
                })
            }
            setFeedbackLoading(false);
        });
    }

    const handleRefreshAction = () => {
        handleGetTriageDetails();
    }

    return (
        <>
            <Paper className="paperTbl">
                {/* <HowIsItDetermined /> */}
                <Skeleton visible={triageLoading || summaryLoading}>
                    <Group justify="flex-end">
                        <Text ta="center" fz="md" td="underline" lh={1} fw={500}>Token Count : {voxTotalTokenCount}</Text>
                    </Group>
                </Skeleton>
                <Accordion chevronPosition="right" variant="contained" pt={5} transitionDuration={200} classNames={classes} defaultValue={[overviewType === 'INCIDENT' ? 'acc_initial_analysis' : 'acc_triage_summary']} multiple={true}>
                    { overviewType === 'INCIDENT' &&
                    <Accordion.Item value={'acc_initial_analysis'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <Box>
                                    <Group wrap="nowrap">
                                        <Text fw={600} style={{ fontSize: "20px", fontWeight: 600, color: "#4D4DFF", paddingLeft: "12px" }}>{'Initial Analysis'}</Text>
                                    </Group>
                                    <Text size="sm" c="dimmed" fw={600} pl={"12px"}>
                                        {`Initial analysis for ${eventId} - detailed analysis follows`}
                                    </Text>
                                </Box>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <Skeleton visible={initialAnalysisDataLoading}>
                                <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                                    <ScrollArea h={350}>
                                        <div style={{ whiteSpace: "pre-line" }}>
                                            {initialAnalysisData && initialAnalysisData.data ? <div dangerouslySetInnerHTML={{ __html: parseTextWithHyperlinks(initialAnalysisData.data) }} /> : 'No Triage Information Found.'}
                                        </div>
                                    </ScrollArea>
                                </Paper>
                            </Skeleton>
                        </Accordion.Panel>
                    </Accordion.Item>
                    }
                    <Accordion.Item value={'acc_triage_summary'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <div>
                                    <Group wrap="nowrap">
                                        <Text fw={600} style={{ fontSize: "20px", fontWeight: 600, color: "#4D4DFF", paddingLeft: "12px" }}>{'Triage Summary'}</Text>
                                        <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Vox-based summaries from all related configuration items (CIs)">
                                            <IconRobot size={25} />
                                        </Tooltip>
                                    </Group>
                                    <Text size="sm" c="dimmed" fw={600} pl={"12px"}>
                                        {'Triage Detailed Summary'}
                                    </Text>
                                </div>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <Skeleton visible={triageLoading || summaryLoading}>
                                <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                                    <ScrollArea h={400}>
                                        <div style={{ whiteSpace: "pre-line" }}>
                                            {summaryData && summaryData.llm_rca ? <div dangerouslySetInnerHTML={{ __html: parseTextWithHyperlinks(summaryData.llm_rca) }} /> : 'No Triage Information Found.'}
                                        </div>
                                    </ScrollArea>
                                </Paper>
                            </Skeleton>
                            {!triageLoading &&
                                <FeedbackForm loading={feedbackLoading} handleReviewSubmit={handleTriageReviewSubmit} handleRefreshAction={handleRefreshAction} />
                            }
                        </Accordion.Panel>
                    </Accordion.Item>
                    <Accordion.Item value={'acc_triage_llm'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <div>
                                    <Group wrap="nowrap">
                                        <Text fw={600} style={{ fontSize: "20px", fontWeight: 600, color: "#4D4DFF", paddingLeft: "12px" }}>{'CI Information'}</Text>
                                        <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Vox-based summaries from all related configuration items (CIs)">
                                            <IconRobot size={25} />
                                        </Tooltip>
                                    </Group>
                                    <Text size="sm" c="dimmed" fw={600} pl={"12px"}>
                                        {'Basic Triage Details'}
                                    </Text>
                                </div>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <CiInformationIncidentTab reqId={eventId} overviewType={overviewType} filterValueTotal={filterValueTotal} />
                        </Accordion.Panel>
                    </Accordion.Item>
                    <Accordion.Item value={'acc_correlation'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <div>
                                    <Group wrap="nowrap">
                                        <Text fw={600} style={{ fontSize: "20px", fontWeight: 600, color: "#4D4DFF", paddingLeft: "12px" }}>{'Correlation'}</Text>
                                        <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Vox-based summaries from all related configuration items (CIs)">
                                            <IconRobot size={25} />
                                        </Tooltip>
                                    </Group>
                                    <Text size="sm" c="dimmed" fw={600} pl={"12px"}>
                                        {`Correlation Details - for RFCs within ${formatFilterDateTimeString(rfcFilterShowValue)} and incidents within ${formatFilterDateTimeString(incidentFilterShowValue)}`}
                                    </Text>
                                </div>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <CorrelationSection
                                handleRefreshAction={handleRefreshAction}
                                triageDetails={triageDetails}
                                summaryData={summaryData}
                                fetching={voxLoading}
                                fetchSummary={summaryLoading}
                                voxLocationLoading={voxLocationLoading}
                                voxLocationData={voxLocationData}
                                voxAppServerLoading={voxAppServerLoading}
                                voxAppServerData={voxAppServerData}
                                voxAssignedGroupLoading={voxAssignedGroupLoading}
                                voxAssignedGroupData={voxAssignedGroupData}
                                voxDeviceTypeLoading={voxDeviceTypeLoading}
                                voxDeviceTypeData={voxDeviceTypeData}
                                voxUpDownstreamLoading={voxUpDownstreamLoading}
                                voxUpDownstreamData={voxUpDownstreamData}
                                voxEventsLoading={voxEventsLoading}
                                voxEventsData={voxEventsData}
                                eventId={eventId}
                            />
                        </Accordion.Panel>
                    </Accordion.Item>
                    <Accordion.Item value={'probable_root_cause'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <div>
                                    <Group wrap="nowrap">
                                        <Text fw={600} style={{ fontSize: "20px", fontWeight: 600, color: "#4D4DFF", paddingLeft: "12px" }}>{'Probable Root Cause'}</Text>
                                        <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Vox-based summaries from all related configuration items (CIs)">
                                            <IconRobot size={25} />
                                        </Tooltip>
                                    </Group>
                                    <Text size="sm" c="dimmed" fw={600} pl={"12px"}>
                                        {'Probable Root Cause Information'}
                                    </Text>
                                </div>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <ProbabaleRootCauseSection triageDetails={triageDetails} summaryData={summaryData} fetching={triageLoading} handleRefreshAction={handleGetTriageDetails} eventId={eventId} />
                        </Accordion.Panel>
                    </Accordion.Item>
                    <Accordion.Item value={'ci_Embedding_events'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <div>
                                    <Text fw={600} style={{ fontSize: "20px", fontWeight: 600, color: "#4D4DFF", paddingLeft: "12px" }}>{'CI based / Similarity Based Events'}</Text>
                                    <Text size="sm" c="dimmed" fw={600} pl={"12px"}>
                                        {'CI based / Similarity Based Information by configuration item'}
                                    </Text>
                                </div>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <CiBasedEvents fetching={allOthersDataLoading} data={allOthersData && allOthersData.ci_based_events ? allOthersData.ci_based_events : []} />
                            <SimilarityBasedEvents fetching={similaritySearchLoading} data={similaritySearchDetails && similaritySearchDetails.format_results && similaritySearchDetails.format_results.events ? similaritySearchDetails.format_results.events : []} />
                        </Accordion.Panel>
                    </Accordion.Item>
                    <Accordion.Item value={'ci_Embedding_incidents'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <div>
                                    <Text fw={600} style={{ fontSize: "20px", fontWeight: 600, color: "#4D4DFF", paddingLeft: "12px" }}>{'CI based / Similarity Based Incidents'}</Text>
                                    <Text size="sm" c="dimmed" fw={600} pl={"12px"}>
                                        {'CI based / Similarity Based Information by configuration item'}
                                    </Text>
                                </div>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <CiBasedIncidents reqId={eventId} overviewType={overviewType} filterValueTotal={filterValueTotal} rfcFilter={rfcFilterValue} incidentFilter={incidentFilterValue} subTitle={subTitle} />
                            <SimilarityBasedIncidents fetching={similaritySearchLoading} data={similaritySearchDetails && similaritySearchDetails.format_results && similaritySearchDetails.format_results.incidents ? similaritySearchDetails.format_results.incidents : []} />
                        </Accordion.Panel>
                    </Accordion.Item>
                    <Accordion.Item value={'ci_Embedding_rfcs'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <div>
                                    <Text fw={600} style={{ fontSize: "20px", fontWeight: 600, color: "#4D4DFF", paddingLeft: "12px" }}>{'CI based / Similarity Based RFCs'}</Text>
                                    <Text size="sm" c="dimmed" fw={600} pl={"12px"}>
                                        {'CI based / Similarity Based Information by configuration item'}
                                    </Text>
                                </div>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <CiBasedRfcs reqId={eventId} overviewType={overviewType} filterValueTotal={filterValueTotal} rfcFilter={rfcFilterValue} incidentFilter={incidentFilterValue} subTitle={subTitle} />
                            <SimilarityBasedRfcs fetching={similaritySearchLoading} data={similaritySearchDetails && similaritySearchDetails.format_results && similaritySearchDetails.format_results.rfcs ? similaritySearchDetails.format_results.rfcs : []} />
                        </Accordion.Panel>
                    </Accordion.Item>
                    <Accordion.Item value={'acc_location'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <div>
                                    <Text fw={600} style={{ fontSize: "20px", fontWeight: 600, color: "#4D4DFF", paddingLeft: "12px" }}>{'Location'}</Text>
                                    <Text size="sm" c="dimmed" fw={600} pl={"12px"}>
                                        {'Incidents/RFCs by location'}
                                    </Text>
                                </div>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <IncidentLocation reqId={eventId} rfcFilter={rfcFilterValue} incidentFilter={incidentFilterValue} subTitle={subTitle} overviewType={overviewType} filterValueTotal={filterValueTotal} />
                            <RfcLocation reqId={eventId} rfcFilter={rfcFilterValue} incidentFilter={incidentFilterValue} subTitle={subTitle} overviewType={overviewType} filterValueTotal={filterValueTotal} />
                        </Accordion.Panel>
                    </Accordion.Item>
                    <Accordion.Item value={'pfz_assignment'} mb={5}>
                        <Accordion.Control>
                            <Group wrap="nowrap">
                                <div>
                                    <Text fw={600} style={{ fontSize: "20px", fontWeight: 600, color: "#4D4DFF", paddingLeft: "12px" }}>{'Assignment Group'}</Text>
                                    <Text size="sm" c="dimmed" fw={600} pl={"12px"}>
                                        {'Incidents/RFCs by Assignment Group'}
                                    </Text>
                                </div>
                            </Group>
                        </Accordion.Control>
                        <Accordion.Panel>
                            <IncidentGroupData reqId={eventId} rfcFilter={rfcFilterValue} incidentFilter={incidentFilterValue} subTitle={subTitle} overviewType={overviewType} filterValueTotal={filterValueTotal} />
                            <RfcGroupData reqId={eventId} rfcFilter={rfcFilterValue} incidentFilter={incidentFilterValue} subTitle={subTitle} overviewType={overviewType} filterValueTotal={filterValueTotal} />
                        </Accordion.Panel>
                    </Accordion.Item>
                    {overviewType !== 'CI' &&
                        <>
                            <Accordion.Item value={'acc_similar_problems'} mb={5}>
                                <Accordion.Control>
                                    <Group wrap="nowrap">
                                        <div>
                                            <Text fw={600} style={{ fontSize: "20px", fontWeight: 600, color: "#4D4DFF", paddingLeft: "12px" }}>{'Similar Problems'}</Text>
                                            <Text size="sm" c="dimmed" fw={600} pl={"12px"}>
                                                {'Similar problems based on incident description'}
                                            </Text>
                                        </div>
                                    </Group>
                                </Accordion.Control>
                                <Accordion.Panel>
                                    <CiBasedProblems data={allOthersData && allOthersData.problems ? allOthersData.problems : []} fetching={allOthersDataLoading} />
                                </Accordion.Panel>
                            </Accordion.Item>
                            <Accordion.Item value={'acc_similar_problems_tasks'} mb={5}>
                                <Accordion.Control>
                                    <Group wrap="nowrap">
                                        <div>
                                            <Text fw={600} style={{ fontSize: "20px", fontWeight: 600, color: "#4D4DFF", paddingLeft: "12px" }}>{'Similar Problems Tasks'}</Text>
                                            <Text size="sm" c="dimmed" fw={600} pl={"12px"}>
                                                {'Similar Problems Tasks'}
                                            </Text>
                                        </div>
                                    </Group>
                                </Accordion.Control>
                                <Accordion.Panel>
                                    <CiBasedProblemTasks data={allOthersData && allOthersData.problems_tasks ? allOthersData.problems_tasks : []} fetching={allOthersDataLoading} />
                                </Accordion.Panel>
                            </Accordion.Item>
                        </>
                    }
                </Accordion>
            </Paper>
            <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                <Skeleton visible={similaritySearchLoading}>
                    <ScrollArea h={350}>
                        <Text fw={700}>Overall Runbook:</Text>
                        <div style={{ whiteSpace: "pre-line" }}>
                            {similaritySearchDetails && similaritySearchDetails.overall_runbook ?
                                reactStringReplace(similaritySearchDetails.overall_runbook, regx, (match: any, i) => (
                                    <strong>
                                        {match}
                                    </strong>
                                ))
                                : <Alert variant="default" color="#000484" title="" icon={''} mb={10}>
                                    No Overall Runbook Information Found.
                                </Alert>}
                        </div>
                    </ScrollArea>
                </Skeleton>
            </Paper>
        </>
    )
}

export default CommonOverview
