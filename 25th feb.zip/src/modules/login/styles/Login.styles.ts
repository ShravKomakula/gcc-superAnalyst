import styled from '@emotion/styled'
import { ThemeInterface, monochromeColor } from 'utils/constants/ColorPalette'
import { fontFamily, fontStyle } from 'utils/constants/TypographyProperties'

export const StyleLoginButtonText = styled.div`
  border-left: 1px solid ${monochromeColor[3]};
  height: 80%;
  text-align: center;
  display: flex;
  align-items: center;
  margin-left: 10px;
  padding-left: 10px;
  font-family: ${fontFamily};
  font-style: ${fontStyle}
  font-weight: 400;
  font-size: 0.875rem;
  line-height: 1.0625rem;
  color: ${monochromeColor[0]};
`
export const StyleLoginButton = styled.div`
  border: 1px solid ${monochromeColor[3]};
  border-radius: 50px;
  width: 270px;
  height: 50px;
  padding: 0px 0 0px 16px;
  display: inline-flex;
  align-items: center;
  margin-bottom: 20px;
  cursor: pointer;
`
export const StyleModalBox = styled.div`
  background: ${monochromeColor[6]};
  box-shadow: 0px 3px 24px rgba(28, 50, 79, 0.1);
  border-radius: 4px;
  width: 100%;
  max-width: 500px;
  height: 440px;
  margin-left: auto;
  margin-right: auto;
  margin-top: auto;
  top: -8vh;
  margin-bottom: auto;
  z-index: 10;
  position: relative;
  @media only screen and (max-height: 1140px) {
    top: auto;
    margin-top: 85px;
    margin-bottom: 120px;
  }
  @media only screen and (max-width: 550px) {
    margin-left: 10px;
    margin-right: 10px;
    padding: 20px;
  }
`
