import { getAuthTokenRequest, loginService, validateAuthTokenRequest } from "services/AuthServices";

export const loginAction = async (payload: any) => {
    return await loginService(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const getAuthTokenAction = async (payload: any) => {
    return await getAuthTokenRequest(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const validateAuthTokenAction = async (payload: any) => {
    return await validateAuthTokenRequest(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

