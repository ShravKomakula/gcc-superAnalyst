export interface FontTypographyInterface {
  fontFamily: string
  fontStyle: string
}
export const fontFamily = 'Roboto'//Noto Sans
export const fontStyle = 'normal'
