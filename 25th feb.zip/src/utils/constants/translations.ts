export const Strings = {
  no__internet: 'No Internet Connection',
  something__went__wrong__header: 'Something Went Wrong',
  access__denied: 'Access Denied'
}
