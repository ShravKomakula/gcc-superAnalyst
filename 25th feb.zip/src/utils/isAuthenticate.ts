export default function isAuthenticate(): boolean {
    const token = localStorage.getItem("jwt_Token") // this isn't the key used wtf.
    let isAuthenticated = false;
    if (token && token !== '') {
        isAuthenticated = true;
    }
    return isAuthenticated
}
