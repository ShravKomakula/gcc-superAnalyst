import * as React from "react";

function BGLogo(props) {
  return (
    <svg width="1em" height="1em" viewBox="0 0 815 921" fill="none" {...props}>
    </svg>
  );
}

const MemoBGLogo = React.memo(BGLogo);
export default MemoBGLogo;
