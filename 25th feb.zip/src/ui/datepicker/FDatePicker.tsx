import FlatPicker from "react-flatpickr";
import {
    Input
} from "@mantine/core";
import { IconCalendar } from "@tabler/icons-react";
// import "flatpickr/dist/themes/material_green.css";
import "flatpickr/dist/flatpickr.min.css";

const FDatePicker = ({ enableTime = true, dateFormat = 'Y-m-d H:i', mode = 'range', setValue, defaultDate = '', disabled = false, inputSize = 'md', inputWidth = '400' }: any) => {
    return (
        <FlatPicker
            data-enable-time={enableTime}
            color="blue"
            options={{ 
                mode: mode,
                enableTime: enableTime,
                minDate: "1999-01-05",
                allowInput: true,
                time_24hr: true,
                dateFormat: dateFormat,
                defaultDate: defaultDate
            }}
            onChange={(data) => {
                setValue(data);
            }}
            render={(innerprops, ref) => {
                return (
                    <Input
                        placeholder="Select date & time range"
                        leftSection={<IconCalendar size={16} />}
                        size={inputSize}
                        ref={ref}
                        w={inputWidth}
                        onChange={(e) => {
                            // console.log("2----" + e);
                        }}
                        disabled={disabled}
                    />
                );
            }}
        />
    )
}

export default FDatePicker