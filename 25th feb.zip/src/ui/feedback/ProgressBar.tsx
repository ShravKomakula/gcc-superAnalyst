import styled from '@emotion/styled'
import { useMantineTheme } from '@mantine/core'
import { ThemeInterface } from 'utils/constants/ColorPalette'

const Wrapper2 = styled.div`
  border: 1px solid ${(props) => (props.theme as ThemeInterface).other.monochromeColor[3]};
  border-radius: 4px;
  position: relative;
  border-collapse: collapse;
  overflow: hidden;
  z-index: 3;
`
const Wrapper1 = styled.div`
  background: ${(props) => (props.theme as ThemeInterface).other.monochromeColor[4]};
  border-radius: 10px;
  z-index: 2;
`
const PregressBar1 = styled.div`
  background: ${(props) => (props.theme as ThemeInterface).other.primaryColor};
  border-radius: 10px;
  z-index: 4;
`
const PregressBar2 = styled.div`
  background: rgba(160, 216, 175, 0.5);
  border: 1px solid rgba(26, 126, 53, 0.5);
  border-radius: 4px;
  z-index: 2;
  transform: skew(-20deg);
  border-collapse: collapse;
  margin-left: -25px;
`
const LabelText = styled.div`
  font-family: ${(props) => (props.theme as ThemeInterface).other.font.fontFamily};
  font-style: ${(props) => (props.theme as ThemeInterface).other.font.fontStyle};
  font-weight: 700;
  font-size: 1.25rem;
  line-height: 150%;
  color: ${(props) => (props.theme as ThemeInterface).other.monochromeColor[2]};
  margin-left: 30px;
  display: flex;
  align-items: center;
  height: 100%;
  position: absolute;
  z-index: 5;
`
interface ProgressBarProps {
  maxWidth?: string
  height?: string
  progress: number
  type: 1 | 2
  label?: string
}

const ProgressBar: React.FC<ProgressBarProps> = ({ height, maxWidth, progress, type, label }) => {
  const theme = useMantineTheme()
  if (type == 1)
    return (
      <Wrapper1 style={{ height: height, maxWidth: maxWidth, width: '100%' }}>
        <PregressBar1 style={{ width: `${progress}%`, height: height }} />
      </Wrapper1>
    )
  else
    return (
      <Wrapper2 style={{ height: height, maxWidth: maxWidth, width: '100%' }}>
        <LabelText>{label}</LabelText>
        {progress > 0 && <PregressBar2 style={{ width: `calc(${progress}% + 35px)`, height: `calc(${height} - 2px)` }} />}
      </Wrapper2>
    )
}
export default ProgressBar
