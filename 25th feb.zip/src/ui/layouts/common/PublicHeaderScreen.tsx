import { Container } from '@mantine/core'

interface HeaderTabsProps {
}

export function PublicHeaderScreen({}: HeaderTabsProps) {
  return (
    <div>
      <Container>
        
      </Container>
    </div>
  )
}
