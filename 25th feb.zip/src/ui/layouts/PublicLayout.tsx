import React, { ReactNode } from 'react'
import styled from '@emotion/styled'
import { Container } from '@mantine/core'
import { FooterScreen } from 'ui/layouts/common/FooterScreen'
import { PublicHeaderScreen } from 'ui/layouts/common/PublicHeaderScreen'
import MemoBGLogo from 'ui/icons/BGLogo'

const PublicLayoutWrapper = styled.div`
  /* overflow: hidden; */
`

const StyleFooterPositionWrapper = styled.div`
  position: sticky;
  bottom: auto;
  width: 100%;
`

const ContentContainerWrapper = styled.div`
  /* position: relative;
  max-width: 100%;
  flex: 1; */
`

const ContentContainer = styled(Container)`
  padding: 0;
  margin: 0;
`
const StyleBackground = styled(MemoBGLogo)`
  position: absolute;
  right: 0px;
  bottom: -210px;
  z-index: -1;
  width: auto;
  height: 900px;
  @media only screen and (max-height: 1366px) {
    height: 830px;
    bottom: -200px;
  }
  @media only screen and (max-height: 1200px) {
    height: 700px;
    bottom: -170px;
  }
  @media only screen and (max-height: 1000px) {
    height: 500px;
    bottom: -120px;
  }
`

interface PublicLayoutProps {
  children: ReactNode
  showTabs?: boolean
  showLoginButton?: boolean
  showDemoButton?: boolean
}
const PublicLayout: React.FC<PublicLayoutProps> = ({
  children
}) => {
  return (
    <PublicLayoutWrapper>
      <ContentContainer fluid>{children}</ContentContainer>
      {/* <PublicHeaderScreen />
      <ContentContainerWrapper>
        <ContentContainer fluid>{children}</ContentContainer>
        <StyleBackground />
      </ContentContainerWrapper>
      <StyleFooterPositionWrapper>
        <FooterScreen />
      </StyleFooterPositionWrapper> */}
    </PublicLayoutWrapper>
  )
}

export default PublicLayout
