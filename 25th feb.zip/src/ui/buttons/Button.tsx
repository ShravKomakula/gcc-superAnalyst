import React, { ReactNode } from 'react'
import { Button as MTButton, useMantineTheme } from '@mantine/core'

interface ButtonProps {
  width?: string
  height?: string
  children?: ReactNode
  buttonVariant: 'outline' | 'filled'
  color?: string
  fontSize?: string
  fontWeight?: number | string
  lineHeight?: string
  borderRadius?: string
  background?: string | null
  onClick?: () => void
  borderColor?: string
  margin?: string
  padding?: string
  disabled?: boolean
  maxWidth?: string
  btnType?: 'submit' | 'button'
}

const Button: React.FC<ButtonProps> = ({
  width = '100%',
  height = '50px',
  children,
  buttonVariant,
  fontSize = '16px',
  color,
  fontWeight,
  lineHeight = '19px',
  borderRadius = '50px',
  background,
  borderColor,
  disabled,
  margin = '0px',
  padding = '0px',
  maxWidth,
  btnType,
  ...props
}) => {
  const theme = useMantineTheme()

  let styles = {
    width: width,
    maxWidth: maxWidth ?? '100%',
    height: height,
    fontSize: fontSize,
    color: color,
    borderRadius: borderRadius,
    border: borderColor
      ? `1px solid ${borderColor} !important`
      : `1px solid ${theme?.other?.primaryColor}`,
    background: 'transparent',
    '&:hover': {
      background: 'transparent',
    },
    fontFamily: 'Inter',
    lineHeight: lineHeight,
    fontStyle: 'normal',
    cursor: 'pointer',
    padding: padding,
    margin: margin,
  }

  let filled = {
    color: color ?? theme?.other?.monochromeColor[6],
    border: 'none',
    background: background ?? theme?.other?.primaryColor,
    '&:hover': {
      background: background ?? theme?.other?.primaryColor,
    },
    fontWeight: fontWeight ?? 700,
  }

  let outline = {
    color: color ?? theme?.other?.primaryColor,
    fontWeight: fontWeight ?? 400,
    background: background ?? 'transparent',
    '&:hover': {
      background: background ?? 'transparent',
    },
  }

  switch (buttonVariant) {
    case 'filled':
      styles = {
        ...styles,
        ...filled,
      }
      break
    case 'outline':
      styles = {
        ...styles,
        ...outline,
      }
      break
  }

  return (
    <MTButton
      disabled={disabled}
      type={btnType ?? 'submit'}
      variant={buttonVariant}
      color={color}
      styles={(theme) => ({
        root: styles,
      })}
      {...props}>
      {children}
    </MTButton>
  )
}
export default Button
