import { Routes, Route, Navigate } from 'react-router-dom'
import { lazy, Suspense, useEffect } from 'react'
import Loader from './ui/feedback/Loader'
import { Route_URL } from 'utils/constants/RouteURL'
import isAuthenticate from 'utils/isAuthenticate'

const LoginScreen = lazy(() => import('screens/LoginScreen'))
const UnauthorizedScreen = lazy(() => import('screens/UnauthorizedScreen'))
const DashboardScreen = lazy(() => import('screens/DashboardScreen'))
const DashboardScreenBlink = lazy(() => import('screens/DashboardScreenBlink'))
const DashboardV2Screen = lazy(() => import('screens/DashboardV2Screen'))
const FeedbackScreen = lazy(() => import('screens/FeedbackScreen'))
const TriageDetailsScreen = lazy(() => import('screens/TriageDetailsScreen'))
const CorelationDetailsScreen = lazy(() => import('screens/CorelationDetailsScreen'))
const EventOverviewScreen = lazy(() => import('screens/EventOverviewScreen'))
const IncidentOverviewScreen = lazy(() => import('screens/IncidentInfoScreen'))
const CiOverviewScreen = lazy(() => import('screens/CiOverviewScreen'))

const PrivateRoute: React.FC<any> = ({ children }) => {
  if (isAuthenticate()) {
    return children
  }
  return <Navigate to={Route_URL.login} />
}
const PublicRoute: React.FC<any> = ({ children }) => {
  if (!isAuthenticate()) {
    return children
  }
  return <Navigate to={Route_URL.dashboard} />
}

function AppRouter() {
  return (
    <div className='App'>
      <Suspense
        fallback={
          <div
            style={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              height: '100vh',
            }}
          >
            <Loader variant='dots' />
          </div>
        }
      >
        <Routes>
          {/* Private Route */}
          <Route
            path='/dashboard'
            element={
              <PrivateRoute>
                {/* <DashboardScreen /> */}
                <DashboardV2Screen />
              </PrivateRoute>
            }
          />
          <Route
            path='/dashboard_v2'
            element={
              <PrivateRoute>
                <DashboardScreen />
              </PrivateRoute>
            }
          />
          <Route
            path='/gcc_admin'
            element={
              <PrivateRoute>
                <FeedbackScreen />
              </PrivateRoute>
            }
          />
        
          {/* Private Route */}
          <Route
            path='/dashboard_blink'
            element={
              <PrivateRoute>
                <DashboardScreenBlink />
              </PrivateRoute>
            }
          />
          <Route
            path='/dashboard/triage_details'
            element={
              <PrivateRoute>
                <TriageDetailsScreen />
              </PrivateRoute>
            }
          />
          <Route
            path='/dashboard/corelation'
            element={
              <PrivateRoute>
                <CorelationDetailsScreen />
              </PrivateRoute>
            }
          />
          <Route
            path='/dashboard/event_overview'
            element={
              <PrivateRoute>
                <EventOverviewScreen />
              </PrivateRoute>
            }
          />
          <Route
            path='/dashboard/incident_overview'
            element={
              <PrivateRoute>
                <IncidentOverviewScreen />
              </PrivateRoute>
            }
          />
          <Route
            path='/dashboard/ci_overview'
            element={
              <PrivateRoute>
                <CiOverviewScreen />
              </PrivateRoute>
            }
          />

          {/* Public Route */}
          <Route
            path='/'
            element={
              <PublicRoute>
                <LoginScreen />
              </PublicRoute>
            }
          />
          <Route
            path='/oauth-redirect'
            element={
              <PublicRoute>
                <LoginScreen />
              </PublicRoute>
            }
          />
          <Route
            path='/'
            element={
              <PublicRoute>
                <UnauthorizedScreen />
              </PublicRoute>
            }
          />
        </Routes>
      </Suspense>
    </div>
  )
}

export default AppRouter
