# # from fastapi import FastAPI, HTTPException
# # from pydantic import BaseModel
# # from typing import List, Optional
# # import psycopg2  # Ensure you have this library installed (pip install psycopg2)
# # from services.core_api.app.database.database import connect_to_postgres
# # app = FastAPI()
 
# # # Pydantic model for input validation
# # class IncidentRequest(BaseModel):
# #     incident_id: int
# #     brief_description: str
 
# # # Function to fetch incident details
# # def fetch_incident(incident_id: int, brief_description: str):
# #     query = """
# #     SELECT network_name
# #     FROM incidents
# #     WHERE incident_id = %s AND brief_description = %s;
# #     """
# #     conn = connect_to_postgres()  # Use your existing connection function
# #     cursor = conn.cursor()
# #     cursor.execute(query, (incident_id, brief_description))
# #     result = cursor.fetchone()
# #     cursor.close()
# #     conn.close()
# #     return result
 
# # # Function to fetch CI details based on network_name
# # def fetch_ci_info(network_name: str):
# #     query = """
# #     SELECT ci.network_name, ci.ci_id, ci.ci_description, ci.created_ts, ci.status
# #     FROM ci
# #     WHERE ci.network_name = %s;
# #     """
# #     conn = connect_to_postgres()  # Use your existing connection function
# #     cursor = conn.cursor()
# #     cursor.execute(query, (network_name,))
# #     result = cursor.fetchall()
# #     cursor.close()
# #     conn.close()
# #     return result
 
# # # Endpoint to get CI details based on incident_id and brief description
# # @app.post("/get-ci-info")
# # def get_ci_info(request: IncidentRequest):
# #     incident_id = request.incident_id
# #     brief_description = request.brief_description
# #     # Fetch the incident to get the network_name
# #     incident = fetch_incident(incident_id, brief_description)
# #     if not incident:
# #         raise HTTPException(status_code=404, detail="Incident not found.")
# #     # Extract the network_name from the incident data
# #     network_name = incident[0]
# #     # Fetch CI information for the matched network_name
# #     ci_info = fetch_ci_info(network_name)
# #     if not ci_info:
# #         raise HTTPException(status_code=404, detail="No CI information found for the given incident.")
# #     return ci_info


# # if __name__ == "__main__":
# #     import uvicorn
# #     uvicorn.run("test:app",reload=True ,host="127.0.0.1", port=8344)












# # from fastapi import FastAPI, HTTPException
# # from fastapi.middleware.cors import CORSMiddleware
# # from typing import List,Optional,Dict, List
# # from pydantic import BaseModel, Field
# # import boto3 
# # import psycopg2
# # import json
# # from botocore.exceptions import ClientError
# # import uvicorn 

# # # Pydantic Models for API Inputs
# # class Pagination(BaseModel):
# #     page: int = Field(1, ge=1, description="Page number for pagination")
# #     per_page: int = Field(10, ge=1, description="Number of items per page")

# # class SearchQuery(BaseModel):
# #     query: str = Field(..., description="Search term to look up in the database")

# # class TriageEvent(BaseModel):
# #     event_input_id: int = Field(..., description="Event ID to triage")
# # class TriageIncident(BaseModel):
# #     incident_input_id: str = Field(..., description="Incidents ID to triage")


# # app = FastAPI()

# # app.add_middleware(
# #     CORSMiddleware,
# #     allow_origins=["*"],
# #     allow_credentials=True,
# #     allow_methods=["*"],
# #     allow_headers=["*"],
# # )


# # def get_postgres_secrets():
# #     secret_name = 'dev/genai/postgres'
# #     region_name = 'us-east-1'
# #     session = boto3.session.Session()
# #     client = session.client(
# #         service_name='secretsmanager',
# #         region_name=region_name
# #     )
# #     try:
# #         get_secret_value_response = client.get_secret_value(
# #             SecretId=secret_name
# #         )
# #     except ClientError as e:
# #         raise e
# #     secret = get_secret_value_response['SecretString']
# #     return secret

# # def connect_to_postgres(db_params: Dict) -> psycopg2.extensions.connection:
# #     """Establish connection to PostgreSQL database"""
# #     result = get_postgres_secrets()
# #     result_dict = {}
# #     res = json.loads(result)
# #     result_dict.update(res)
    
# #     try:
# #         postgres_conn = psycopg2.connect(
# #             dbname=result_dict['dbname'],
# #             user=result_dict['username'],
# #             password=result_dict['password'],
# #             host=result_dict['host'],
# #             port=result_dict['port']
# #         )
# #         return postgres_conn
# #     except Exception as e:
# #         print(f"Error connecting to database: {e}")
# #         raise

# # # Helper Function for PostgreSQL Queries
# # def execute_query(query: str, params: tuple = None):
# #     """
# #     Execute a PostgreSQL query and return the result.
# #     """
# #     try:
# #         conn = connect_to_postgres({})
# #         with conn.cursor() as cursor:
# #             cursor.execute(query, params)
# #             if query.strip().upper().startswith("WITH"):
# #                 columns = [desc[0] for desc in cursor.description]
# #                 rows = cursor.fetchall()
# #                 return rows,columns
# #             conn.commit()
# #     except Exception as e:
# #         print(f"Error executing query: {e}")
# #         raise HTTPException(status_code=500, detail="Internal Server Error")
# #     finally:
# #         conn.close()

# # def fetch_query_results(query: str, params: tuple, columns: List[str]):
# #     """
# #     Execute a query and return the results as a list of dictionaries.
# #     """
# #     rows,columns = execute_query(query, params)
# #     return [dict(zip(columns, row)) for row in rows]



# # @app.post("/dashboard")
# # def get_dashboard(pagination: Pagination):
# #     """
# #     Paginated results for events with additional columns.
# #     """
# #     start = (pagination.page - 1) * pagination.per_page
    
# #     query = """WITH RankedEvents AS (
# #     SELECT
# #         event_id,
# #         created_ts,
# #         event_title,
# #         severity,
# #         event_status,
# #         ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY created_ts DESC) AS rn
# #     FROM
# #         dc1.events
# # )
# # SELECT
# #     event_id,  created_ts, event_title, severity, event_status
# # FROM
# #     RankedEvents
# # WHERE
# #     rn = 1
# # ORDER BY
# #     created_ts DESC
# # LIMIT %s OFFSET %s;
# # """
# #     columns = ["event_id",  "created_ts", "event_title", "severity", "event_status"]
# #     return fetch_query_results(query, (pagination.per_page, start), columns)






# from fastapi import FastAPI, HTTPException
# from fastapi.middleware.cors import CORSMiddleware
# from typing import List,Optional,Dict, List
# from pydantic import BaseModel, Field
# import boto3
# import psycopg2
# import json
# from botocore.exceptions import ClientError
# import uvicorn
 
# # Pydantic Models for API Inputs
# class Pagination(BaseModel):
#     page: int = Field(1, ge=1, description="Page number for pagination")
#     per_page: int = Field(10, ge=1, description="Number of items per page")
 
# class SearchQuery(BaseModel):
#     query: str = Field(..., description="Search term to look up in the database")
 
# class TriageEvent(BaseModel):
#     event_input_id: int = Field(..., description="Event ID to triage")
# class TriageIncident(BaseModel):
#     incident_input_id: str = Field(..., description="Incidents ID to triage")
 
 
# app = FastAPI()
 
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )
 
 
# def get_postgres_secrets():
#     secret_name = 'dev/genai/postgres'
#     region_name = 'us-east-1'
#     session = boto3.session.Session()
#     client = session.client(
#         service_name='secretsmanager',
#         region_name=region_name
#     )
#     try:
#         get_secret_value_response = client.get_secret_value(
#             SecretId=secret_name
#         )
#     except ClientError as e:
#         raise e
#     secret = get_secret_value_response['SecretString']
#     return secret
 
# def connect_to_postgres(db_params: Dict) -> psycopg2.extensions.connection:
#     """Establish connection to PostgreSQL database"""
#     result = get_postgres_secrets()
#     result_dict = {}
#     res = json.loads(result)
#     result_dict.update(res)
   
#     try:
#         postgres_conn = psycopg2.connect(
#             dbname=result_dict['dbname'],
#             user=result_dict['username'],
#             password=result_dict['password'],
#             host=result_dict['host'],
#             port=result_dict['port']
#         )
#         return postgres_conn
#     except Exception as e:
#         print(f"Error connecting to database: {e}")
#         raise
 
# # Helper Function for PostgreSQL Queries
# def execute_query(query: str, params: tuple = None):
#     """
#     Execute a PostgreSQL query and return the result.
#     """
#     try:
#         conn = connect_to_postgres({})
#         with conn.cursor() as cursor:
#             cursor.execute(query, params)
#             if query.strip().upper().startswith(("WITH","SELECT")):
#                 columns = [desc[0] for desc in cursor.description]
#                 rows = cursor.fetchall()
#                 return rows,columns
#             conn.commit()
#     except Exception as e:
#         print(f"Error executing query: {e}")
#         raise HTTPException(status_code=500, detail="Internal Server Error")
#     finally:
#         conn.close()
 
# def fetch_query_results(query: str, params: tuple, columns: List[str]):
#     """
#     Execute a query and return the results as a list of dictionaries.
#     """
#     rows,columns = execute_query(query, params)
#     return [dict(zip(columns, row)) for row in rows]
 
 
 
# @app.post("/dashboard")
# def get_dashboard(pagination: Pagination):
#     """
#     Paginated results for events with additional columns.
#     """
#     start = (pagination.page - 1) * pagination.per_page
   
#     query = """WITH RankedEvents AS (
#     SELECT
#         event_id,
#         created_ts,
#         event_title,
#         severity,
#         event_status,
#         ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY created_ts DESC) AS rn
#     FROM
#         dc1.events
# )
# SELECT
#     event_id,  created_ts, event_title, severity, event_status
# FROM
#     RankedEvents
# WHERE
#     rn = 1
# ORDER BY
#     created_ts DESC
# LIMIT %s OFFSET %s;
# """
#     columns = ["event_id",  "created_ts", "event_title", "severity", "event_status"]
#     return fetch_query_results(query, (pagination.per_page, start), columns)
 
# # 2. Incident Dashboard API
# @app.post("/dashboard_IC")
# def get_incident_dashboard(pagination: Pagination):
#     """
#     Paginated results for incidents.
#     """
#     start = (pagination.page - 1) * pagination.per_page
#     query = """
#         SELECT DISTINCT NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME
#         FROM dc1sm_ro.incidents
#         ORDER BY OPEN_TIME DESC
#         LIMIT %s OFFSET %s
#     """
#     columns = ["NUMBERPRGN", "BRIEF_DESCRIPTION", "NETWORK_NAME", "PROBLEM_STATUS", "OPEN_TIME"]
#     return fetch_query_results(query, (pagination.per_page, start), columns)
 
# # 3. Search Events API
# @app.post("/api/events", tags=["search data"])
# def search_events(search: SearchQuery):
#     """
#     Search events.
#     """
#     query = """
#         SELECT DISTINCT(event_id) event_id, config_item_id, created_ts, event_title
#         FROM dc1.events
#         WHERE event_title ILIKE %s OR config_item_id ILIKE %s
#     """
#     search_term = f"%{search.query}%"
#     columns = ["event_id", "config_item_id", "created_ts", "event_title"]
#     return fetch_query_results(query, (search_term, search_term), columns)
 
# # 4. Search Incidents API
# @app.post("/api/Incidents", tags=["search data"])
# def search_incidents(search: SearchQuery):
#     """
#     Search incidents.
#     """
#     query = """
#         SELECT DISTINCT NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME
#         FROM incidents
#         WHERE BRIEF_DESCRIPTION ILIKE %s OR NETWORK_NAME ILIKE %s
#     """
#     search_term = f"%{search.query}%"
#     columns = ["NUMBERPRGN", "BRIEF_DESCRIPTION", "NETWORK_NAME", "PROBLEM_STATUS", "OPEN_TIME"]
#     return fetch_query_results(query, (search_term, search_term), columns)
 
# # 5. Get Event by ID API
# @app.post("/get_event_byid")
# def get_event_by_id(event_input_id: TriageEvent):
#     """
#     Get event by ID.
#     """
#     query = "SELECT event_id, config_item_id, created_ts, event_title FROM dc1.events WHERE event_id = %s"
#     columns = ["event_id", "config_item_id", "created_ts", "event_title"]
#     result = fetch_query_results(query, (event_input_id.event_input_id,), columns)
#     if not result:
#         raise HTTPException(status_code=404, detail="Event not found")
#     return result[0]
 
# # 6. Get Incident by ID API
# @app.post("/get_Incident_byid")
# def get_incident_by_id(incident_input_id: TriageIncident):
#     """
#     Get incident by ID.
#     """
#     query = "SELECT NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME FROM dc1sm_ro.incidents WHERE NUMBERPRGN = %s"
#     columns = ["NUMBERPRGN", "BRIEF_DESCRIPTION", "NETWORK_NAME", "PROBLEM_STATUS", "OPEN_TIME"]
#     result = fetch_query_results(query, (incident_input_id.incident_input_id,), columns)
#     if not result:
#         raise HTTPException(status_code=404, detail="Incident not found")
#     return result[0]
 
 
 
# # Pydantic model for input validation
# class IncidentRequest(BaseModel):
#     numberprgn: str
 
 
# # Function to fetch incident details
# def fetch_incident(numberprgn: str):
#     query = """
#     SELECT network_name
#     FROM dc1sm_ro.incidents
#     WHERE numberprgn = %s;
#     """
#     conn = connect_to_postgres({})  # Use your existing connection function
#     cursor = conn.cursor()
#     cursor.execute(query, (numberprgn,))
#     result = cursor.fetchone()
#     cursor.close()
#     conn.close()
#     return result
 
# # # Function to fetch CI details based on network_name
# # def fetch_ci_info(network_name: str):
# #     query = """
# #     SELECT *
# #     FROM itsm_owner.cis
# #     WHERE network_name = %s;
# #     """
# #     conn = connect_to_postgres({})  # Use your existing connection function
# #     cursor = conn.cursor()
# #     cursor.execute(query, (network_name,))
# #     result = cursor.fetchall()
# #     columns = [desc[0] for desc in cursor.description]
# #     ci_info_list = [dict(zip(columns, row)) for row in result]
# #     cursor.close()
# #     conn.close()
# #     return ci_info_list
 
# # Endpoint to get CI details based on `numberprgn`
# @app.post("/get-ci-info")
# def get_ci_info(request: IncidentRequest):
#     numberprgn = request.numberprgn
#     # Fetch the incident to get the network_name
#     incident = fetch_incident(numberprgn)
#     if not incident:
#         raise HTTPException(status_code=404, detail="Incident not found.")
#     # Extract the network_name from the incident data
#     network_name = incident[0]
#     # Fetch CI information for the matched network_name
#     ci_info = fetch_ci_info(network_name)
#     if not ci_info:
#         raise HTTPException(status_code=404, detail="No CI information found for the given incident.")
#     return ci_info
 
 
 
 
# # Fetch CI Info
# def get_ci_info(network_name):
#     query = """
#     SELECT LOGICAL_NAME ,NETWORK_NAME,RELATIONSHIP_SUBTYPE ,PFZ_STATUS  ,PFZ_USAGE, TYPE  , SUBTYPE ,PFZ_ADDED_TIME,OPERATING_SYSTEM ,LOCATION,PFZ_ASSIGNMENT,CI_CONTACTS ,PFZ_ESC_ASSIGNMENT,SITE_CATEGORY,TIME_ZONE ,CORP_STRUCTURE ,ALIASES ,R_LOGICAL_NAME ,R_NETWORK_NAME ,DESCRIPTION
#     FROM itsm_owner.cis
#     WHERE NETWORK_NAME = %s;
#     """
#     conn = connect_to_postgres({})
#     cursor = conn.cursor()
#     cursor.execute(query, (network_name,))
#     ci_info = cursor.fetchall()
#     columns = [desc[0] for desc in cursor.description]
#     data = [dict(zip(columns, row)) for row in ci_info]
#     cursor.close()
#     conn.close()
#     return data
 
# # Unified function to fetch CI relationships or dependencies
# def get_ci_relationships_or_dependencies(network_name):
#     query = """
#     SELECT *
#     FROM itsm_owner.cis
#     WHERE network_name = %s;
#     """
#     conn = connect_to_postgres({})
#     cursor = conn.cursor()
#     cursor.execute(query, (network_name,))
#     ci = cursor.fetchall()
#     columns = [desc[0] for desc in cursor.description]
#     ci_data = [dict(zip(columns, row)) for row in ci]
   
#     if not ci_data:
#         return []
   
#     ci_type = ci_data[0]['type']
#     if ci_type == 'APPLICATION':
#         dependencies_query = """
#         SELECT LOGICAL_NAME, NETWORK_NAME, R_LOGICAL_NAME, R_NETWORK_NAME, PFZ_STATUS, DESCRIPTION
#         FROM itsm_owner.cis
#         WHERE (R_NETWORK_NAME = %s OR R_LOGICAL_NAME = %s)
#         AND TYPE != 'APPLICATION'
#         AND PFZ_STATUS = 'Active';
#         """
#         cursor.execute(dependencies_query, (network_name, network_name))
#     else:
#         downstream_query = """
#         SELECT LOGICAL_NAME, NETWORK_NAME, R_LOGICAL_NAME, R_NETWORK_NAME, PFZ_STATUS, DESCRIPTION
#         FROM itsm_owner.cis
#         WHERE network_name = %s
#         AND PFZ_STATUS = 'Active';
#         """
#         cursor.execute(downstream_query, (network_name,))
   
#     related_data = cursor.fetchall()
#     related_columns = [desc[0] for desc in cursor.description]
#     results = [dict(zip(related_columns, row)) for row in related_data]
#     cursor.close()
#     conn.close()
#     return results
 
# # Fetch upstream relationships
# def get_ci_upstream(network_name):
#     query = """
#     SELECT DISTINCT NETWORK_NAME
#     FROM itsm_owner.cis
#     WHERE R_NETWORK_NAME = %s AND PFZ_STATUS = 'Active' AND PFZ_USAGE = 'Production';
#     """
#     conn = connect_to_postgres({})
#     cursor = conn.cursor()
#     cursor.execute(query, (network_name,))
#     upstreams_network = [row[0] for row in cursor.fetchall()]
#     cursor.close()
#     conn.close()
   
#     try:
#         upstreams_network.remove(network_name)
#     except ValueError:
#         pass
   
#     upstream_data = []
#     for net_name in upstreams_network:
#         upstream_data.append(get_related_data(net_name, "dc1sm_ro.incidents", ["network_name", "description"], limit=70))
#     return [item for sublist in upstream_data for item in sublist]
 
# # Helper function for fetching related data
# def get_related_data(network_name, table_name, columns, limit=70):
#     query = f"""
#     SELECT {', '.join(columns)}
#     FROM {table_name}
#     WHERE network_name = %s
#     LIMIT %s;
#     """
#     conn = connect_to_postgres({})
#     cursor = conn.cursor()
#     cursor.execute(query, (network_name, limit))
#     results = cursor.fetchall()
#     columns = [desc[0] for desc in cursor.description]
#     data = [dict(zip(columns, row)) for row in results]
#     cursor.close()
#     conn.close()
#     return data
 
# # Main API Endpoint
# @app.post("/get-all-ci-data")
# def get_all_ci_data(request: IncidentRequest):
#     numberprgn = request.numberprgn
 
#     # Fetch incident details to get network_name
#     query = """
#     SELECT network_name
#     FROM dc1sm_ro.incidents
#     WHERE numberprgn = %s;
#     """
#     conn = connect_to_postgres({})
#     cursor = conn.cursor()
#     cursor.execute(query, (numberprgn,))
#     incident = cursor.fetchone()
#     cursor.close()
#     conn.close()
 
#     if not incident:
#         raise HTTPException(status_code=404, detail="Incident not found.")
 
#     network_name = incident[0]
 
#     # Fetch data
#     ci_info = get_ci_info(network_name)
#     relationships = get_ci_relationships_or_dependencies(network_name)
#     upstream = get_ci_upstream(network_name)
#     downstream = get_ci_relationships_or_dependencies(network_name)  # Assuming reuse for downstream
#     assignment_group = get_assignment_group(network_name)
#     location = get_location(network_name)
 
#     # Return all combined data
#     return {
#         "network_name": network_name,
#         "ci_info": ci_info,
#         "relationships_or_dependencies": relationships,
#         "upstream": upstream,
#         "downstream": downstream,
#         "assignment_group": assignment_group,
#         "location": location,
#     }
 
# # Fetch assignment group
# def get_assignment_group(network_name):
#     query = """
#     SELECT PFZ_ASSIGNMENT
#     FROM itsm_owner.cis
#     WHERE NETWORK_NAME = %s;
#     """
#     conn = connect_to_postgres({})
#     cursor = conn.cursor()
#     cursor.execute(query, (network_name,))
#     result = cursor.fetchone()
#     cursor.close()
#     conn.close()
#     return result[0] if result else None
 
# # Fetch location
# def get_location(network_name):
#     query = """
#     SELECT LOCATION
#     FROM itsm_owner.cis
#     WHERE NETWORK_NAME = %s;
#     """
#     conn = connect_to_postgres({})
#     cursor = conn.cursor()
#     cursor.execute(query, (network_name,))
#     result = cursor.fetchone()
#     cursor.close()
#     conn.close()
#     return result[0] if result else None
 
 
 
 
# if __name__ == "__main__":
#     uvicorn.run("refactoring_code:app", host="127.0.0.1",reload=True,port=8015)
   
   
   




# from fastapi import FastAPI, HTTPException
# from fastapi.middleware.cors import CORSMiddleware
# from typing import Optional
# from pydantic import BaseModel,Field
# # from utils.utils import execute_query, fetch_query_results
# import boto3
# from botocore.exceptions import ClientError
# from typing import Dict,List
# from psycopg2.extras import RealDictCursor
# import psycopg2
# import json

# class SearchQuery(BaseModel):
#     query: str = Field(..., description="Search term to look up in the database")

# class TriageEvent(BaseModel):
#     event_input_id: int = Field(..., description="Event ID to triage")

# class TriageIncident(BaseModel):
#     incident_input_id: str = Field(..., description="Incidents ID to triage")


# class IncidentRequest(BaseModel):
#     numberprgn: str

# # Helper to fetch secrets from AWS Secrets Manager
# def get_postgres_secrets():
#     secret_name = 'dev/genai/postgres'
#     region_name = 'us-east-1'
#     session = boto3.session.Session()
#     client = session.client(
#         service_name='secretsmanager',
#         region_name=region_name
#     )
#     try:
#         get_secret_value_response = client.get_secret_value(
#             SecretId=secret_name
#         )
#     except ClientError as e:
#         raise e
#     secret = get_secret_value_response['SecretString']
#     return secret

# # Establish a connection to PostgreSQL
# def connect_to_postgres(db_params: Dict) -> psycopg2.extensions.connection:
#     result = get_postgres_secrets()
#     result_dict = json.loads(result)

#     try:
#         postgres_conn = psycopg2.connect(
#             dbname=result_dict['dbname'],
#             user=result_dict['username'],
#             password=result_dict['password'],
#             host=result_dict['host'],
#             port=result_dict['port']
#         )
#         return postgres_conn
#     except Exception as e:
#         print(f"Error connecting to database: {e}")
#         raise

# def execute_query(query: str, params: tuple = None):
#     """
#     Execute a PostgreSQL query and return the result.
#     """
#     try:
#         conn = connect_to_postgres({})
#         with conn.cursor() as cursor:
#             cursor.execute(query, params)
#             if query.strip().upper().startswith(("WITH","SELECT")):
#                 columns = [desc[0] for desc in cursor.description]
#                 rows = cursor.fetchall()
#                 return rows,columns
#             conn.commit()
#     except Exception as e:
#         print(f"Error executing query: {e}")
#         raise HTTPException(status_code=500, detail="Internal Server Error")
#     finally:
#         conn.close()
# def fetch_query_results(query: str, params: tuple, columns: List[str]):
#     """
#     Execute a query and return the results as a list of dictionaries.
#     """
#     # rows = execute_query(query, params)
#     # return [dict(zip(columns, row)) for row in rows]
#     rows,columns = execute_query(query, params)
#     result = [dict(zip(columns, row)) for row in rows]
#     return result

# # Helper to execute paginated SQL queries
# def execute_paginated_query(query: str, params: Optional[tuple], page: int, page_size: int):
#     try:
#         offset = (page - 1) * page_size
#         paginated_query = f"{query} LIMIT %s OFFSET %s"
#         with connect_to_postgres({}) as conn:
#             with conn.cursor(cursor_factory=RealDictCursor) as cursor:
#                 cursor.execute(paginated_query, params + (page_size, offset))
#                 return cursor.fetchall()
#     except Exception as e:
#         print(f"Error executing query: {e}")
#         raise HTTPException(status_code=500, detail="Database query failed")


# # Define Pydantic schemas
# # class Pagination(BaseModel):
# #     page: int=1
# #     per_page: int=100
# class Pagination(BaseModel):
#     page: int = Field(1, ge=1, description="Page number for pagination")
#     per_page: int = Field(100, ge=1, description="Number of items per page")

# # Initialize API router
# dashboard_api = FastAPI()

# # Helper function to fetch total record count
# def get_total_count(query: str, params: Optional[tuple] = None):
#     count_query = f"SELECT COUNT(*) FROM ({query}) AS total"
#     rows, _ = execute_query(count_query, params)
#     return rows[0][0] if rows else 0


# # 1. Event Dashboard API
# @dashboard_api.post("/event_dashboard")
# def get_event_dashboard(pagination: Pagination):
#     try:
#         base_query = """
#             SELECT DISTINCT event_id, config_item_id, created_ts, event_title
#             FROM dc1.events
#         """

#         # Calculate total records
#         total_count = get_total_count(base_query)

#         # Paginate results
#         start = (pagination.page - 1) * pagination.per_page
#         paginated_query = base_query + "ORDER BY created_ts DESC LIMIT %s OFFSET %s"
#         columns = ["event_id", "config_item_id", "created_ts", "event_title"]
#         result = fetch_query_results(paginated_query, (pagination.per_page, start), columns)

#         # Calculate total records for the current page
#         total_records_per_page = len(result)

#         # Return response
#         return {
#             "message": "Successfully returned the data",
#             "data": result,
#             "page": pagination.page,
#             "per_page": pagination.per_page,
#             "total_records": total_count,
#             "total_pages": (total_count + pagination.per_page - 1) // pagination.per_page,
#             "records_on_page": total_records_per_page
#         }
#     except Exception as e:
#         return {
#             "status_code": 400,
#             "message": "Error fetching data",
#             "details": str(e)
#         }

# # 2. Incident Dashboard API
# @dashboard_api.post("/incident_dashboard_IN")
# def get_incident_dashboard(pagination: Pagination):
#     try:
#         base_query = """
#             SELECT DISTINCT NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME
#             FROM dc1sm_ro.incidents
#         """

#         # Calculate total records
#         total_count = get_total_count(base_query)

#         # Paginate results
#         start = (pagination.page - 1) * pagination.per_page
#         paginated_query = base_query + "ORDER BY OPEN_TIME DESC LIMIT %s OFFSET %s"
#         columns = ["NUMBERPRGN", "BRIEF_DESCRIPTION", "NETWORK_NAME", "PROBLEM_STATUS", "OPEN_TIME"]
#         result = fetch_query_results(paginated_query, (pagination.per_page, start), columns)

#         # Calculate total records for the current page
#         total_records_per_page = len(result)

#         # Return response
#         return {
#             "message": "Successfully returned the data",
#             "data": result,
#             "page": pagination.page,
#             "per_page": pagination.per_page,
#             "total_records": total_count,
#             "total_pages": (total_count + pagination.per_page - 1) // pagination.per_page,
#             "records_on_page": total_records_per_page
#         }
#     except Exception as e:
#         return {
#             "status_code": 400,
#             "message": "Error fetching data",
#             "details": str(e)
#         }

# # 1. Search Events API
# @dashboard_api.post("/api/events")
# def search_events(search: SearchQuery):
#     try:
#         """
#         Search events and calculate total records and pages.
#         """
#         base_query = """
#             SELECT DISTINCT event_id, config_item_id, created_ts, event_title
#             FROM dc1.events
#             WHERE event_title ILIKE %s OR config_item_id ILIKE %s
#         """
#         search_term = f"%{search.query}%"

#         # Fetch all matching records
#         columns = ["event_id", "config_item_id", "created_ts", "event_title"]
#         results = fetch_query_results(base_query, (search_term, search_term), columns)

#         # Calculate total records and pages (assuming a default page size of 10)
#         per_page = 10
#         total_count = len(results)
#         total_pages = (total_count + per_page - 1) // per_page

#         return {
#             "message": "Successfully returned the data",
#             "data": results,
#             "total_records": total_count,
#             "total_pages": total_pages
#         }
#     except Exception as e:
#         return {"status_code": "400", "Message": "Error fetching data", "details": str(e)}

# # 2. Search Incidents API
# @dashboard_api.post("/api/incidents")
# def search_incidents(search: SearchQuery):
#     try:
#         """
#         Search incidents and calculate total records and pages.
#         """
#         base_query = """
#             SELECT DISTINCT NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME
#             FROM dc1sm_ro.incidents
#             WHERE BRIEF_DESCRIPTION ILIKE %s OR NETWORK_NAME ILIKE %s
#         """
#         search_term = f"%{search.query}%"

#         # Fetch all matching records
#         columns = ["NUMBERPRGN", "BRIEF_DESCRIPTION", "NETWORK_NAME", "PROBLEM_STATUS", "OPEN_TIME"]
#         results = fetch_query_results(base_query, (search_term, search_term), columns)

#         # Calculate total records and pages (assuming a default page size of 10)
#         per_page = 10
#         total_count = len(results)
#         total_pages = (total_count + per_page - 1) // per_page

#         return {
#             "message": "Successfully returned the data",
#             "data": results,
#             "total_records": total_count,
#             "total_pages": total_pages
#         }
#     except Exception as e:
#         return {"status_code": "400", "Message": "Error fetching data", "details": str(e)}



# # 3. Get Event by ID API
# # 3. Get Event by ID API
# @dashboard_api.post("/get_event_byid")
# def get_event_by_id(event_input_id: TriageEvent):
#     try:
#         """
#         Get event by ID and calculate the total records.
#         """
#         query = "SELECT event_id, config_item_id, created_ts, event_title FROM dc1.events WHERE event_id = %s"
#         columns = ["event_id", "config_item_id", "created_ts", "event_title"]
#         result = fetch_query_results(query, (event_input_id.event_input_id,), columns)

#         total_count = len(result)  # Total records for the given event_id

#         if not result:
#             raise HTTPException(status_code=404, detail="Event not found")
        
#         return {
#             "message": "Successfully returned the data",
#             "data": result[0],  # Since event_id is unique, only return the first record
#             "total_records": total_count
#         }
#     except Exception as e:
#         return {"status_code": "400", "Message": "Error fetching data", "details": str(e)}

# # 4. Get Incident by ID API
# @dashboard_api.post("/get_incident_byid")
# def get_incident_by_id(incident_input_id: TriageIncident):
#     try:
#         """
#         Get incident by ID and calculate the total records.
#         """
#         query = "SELECT NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME FROM dc1sm_ro.incidents WHERE NUMBERPRGN = %s"
#         columns = ["NUMBERPRGN", "BRIEF_DESCRIPTION", "NETWORK_NAME", "PROBLEM_STATUS", "OPEN_TIME"]
#         result = fetch_query_results(query, (incident_input_id.incident_input_id,), columns)

#         total_count = len(result)  # Total records for the given incident_id

#         if not result:
#             raise HTTPException(status_code=404, detail="Incident not found")
        
#         return {
#             "message": "Successfully returned the data",
#             "data": result[0],  # Since incident_id is unique, only return the first record
#             "total_records": total_count
#         }
#     except Exception as e:
#         return {"status_code": "400", "Message": "Error fetching data", "details": str(e)}



from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List,Optional,Dict, List
from pydantic import BaseModel, Field
import boto3 
import psycopg2
import json
from botocore.exceptions import ClientError
import uvicorn 

# Pydantic Models for API Inputs
class Pagination(BaseModel):
    page: int = Field(1, ge=1, description="Page number for pagination")
    per_page: int = Field(10, ge=1, description="Number of items per page")

class SearchQuery(BaseModel):
    query: str = Field(..., description="Search term to look up in the database")

class TriageEvent(BaseModel):
    event_input_id: int = Field(..., description="Event ID to triage")
class TriageIncident(BaseModel):
    incident_input_id: str = Field(..., description="Incidents ID to triage")


app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_postgres_secrets():
    secret_name = 'dev/genai/postgres'
    region_name = 'us-east-1'
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        raise e
    secret = get_secret_value_response['SecretString']
    return secret

def connect_to_postgres(db_params: Dict) -> psycopg2.extensions.connection:
    """Establish connection to PostgreSQL database"""
    result = get_postgres_secrets()
    result_dict = {}
    res = json.loads(result)
    result_dict.update(res)
    
    try:
        postgres_conn = psycopg2.connect(
            dbname=result_dict['dbname'],
            user=result_dict['username'],
            password=result_dict['password'],
            host=result_dict['host'],
            port=result_dict['port']
        )
        return postgres_conn
    except Exception as e:
        print(f"Error connecting to database: {e}")
        raise

# Helper Function for PostgreSQL Queries
def execute_query(query: str, params: tuple = None):
    """
    Execute a PostgreSQL query and return the result.
    """
    try:
        conn = connect_to_postgres({})
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            if query.strip().upper().startswith(("WITH","SELECT")):
                columns = [desc[0] for desc in cursor.description]
                rows = cursor.fetchall()
                return rows,columns
            conn.commit()
    except Exception as e:
        print(f"Error executing query: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    finally:
        conn.close()

def fetch_query_results(query: str, params: tuple, columns: List[str]):
    """
    Execute a query and return the results as a list of dictionaries.
    """
    rows,columns = execute_query(query, params)
    return [dict(zip(columns, row)) for row in rows]



@app.post("/dashboard")
def get_dashboard(pagination: Pagination):
    """
    Paginated results for events with additional columns.
    """
    start = (pagination.page - 1) * pagination.per_page
    
    query = """WITH RankedEvents AS (
                        SELECT
                            event_id,
                            created_ts,
                            event_title,
                            severity,
                            event_status,
                            ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY created_ts DESC) AS rn
                        FROM
                            dc1.events
                    )
                    SELECT
                        event_id,  created_ts, event_title, severity, event_status
                    FROM
                        RankedEvents
                    WHERE
                        rn = 1
                    ORDER BY
                        created_ts DESC
                    LIMIT %s OFFSET %s;
                    """
    columns = ["event_id",  "created_ts", "event_title", "severity", "event_status"]
    return fetch_query_results(query, (pagination.per_page, start), columns)

# 2. Incident Dashboard API
@app.post("/dashboard_IC")
def get_incident_dashboard(pagination: Pagination):
    """
    Paginated results for incidents.
    """
    start = (pagination.page - 1) * pagination.per_page
    
    query = """WITH RankedIncidents AS (
                    SELECT 
                        NUMBERPRGN, 
                        BRIEF_DESCRIPTION, 
                        NETWORK_NAME, 
                        PROBLEM_STATUS, 
                        OPEN_TIME,
                        ROW_NUMBER() OVER (PARTITION BY NUMBERPRGN ORDER BY OPEN_TIME DESC) AS rn
                    FROM
                        dc1sm_ro.incidents
                )
                SELECT
                    NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME
                FROM
                    RankedIncidents
                WHERE
                    rn = 1
                ORDER BY
                    OPEN_TIME DESC
                LIMIT %s OFFSET %s;
                """
    columns = ["NUMBERPRGN", "BRIEF_DESCRIPTION", "NETWORK_NAME", "PROBLEM_STATUS", "OPEN_TIME"]
    return fetch_query_results(query, (pagination.per_page, start), columns)

# 3. Search Events API
@app.post("/api/events", tags=["search data"])
def search_events(search: SearchQuery):
    """
    Search events.
    """
    query = """
        SELECT DISTINCT(event_id) event_id, config_item_id, created_ts, event_title
        FROM dc1.events
        WHERE event_title ILIKE %s OR config_item_id ILIKE %s
    """
    search_term = f"%{search.query}%"
    columns = ["event_id", "config_item_id", "created_ts", "event_title"]
    return fetch_query_results(query, (search_term, search_term), columns)

# 4. Search Incidents API
@app.post("/api/Incidents", tags=["search data"])
def search_incidents(search: SearchQuery):
    """
    Search incidents.
    """
    query = """
        SELECT DISTINCT NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME
        FROM incidents
        WHERE BRIEF_DESCRIPTION ILIKE %s OR NETWORK_NAME ILIKE %s
    """
    search_term = f"%{search.query}%"
    columns = ["NUMBERPRGN", "BRIEF_DESCRIPTION", "NETWORK_NAME", "PROBLEM_STATUS", "OPEN_TIME"]
    return fetch_query_results(query, (search_term, search_term), columns)

# 5. Get Event by ID API
@app.post("/get_event_byid")
def get_event_by_id(event_input_id: TriageEvent):
    """
    Get event by ID.
    """
    query = """SELECT DISTINCT event_id, config_item_id, created_ts, event_title FROM dc1.events WHERE event_id = %s"""
    columns = ["event_id", "config_item_id", "created_ts", "event_title"]
    result = fetch_query_results(query, (event_input_id.event_input_id,), columns)
    if not result:
        raise HTTPException(status_code=404, detail="Event not found")
    return result[0]

# 6. Get Incident by ID API
@app.post("/get_Incident_byid")
def get_incident_by_id(incident_input_id: TriageIncident):
    """
    Get incident by ID.
    """
    query = """SELECT DISTINCT NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME FROM dc1sm_ro.incidents WHERE NUMBERPRGN = %s"""
    columns = ["NUMBERPRGN", "BRIEF_DESCRIPTION", "NETWORK_NAME", "PROBLEM_STATUS", "OPEN_TIME"]
    result = fetch_query_results(query, (incident_input_id.incident_input_id,), columns)
    if not result:
        raise HTTPException(status_code=404, detail="Incident not found")
    return result[0]


 
# Pydantic model for input validation
class IncidentRequest(BaseModel):
    numberprgn: str
 
 
# Function to fetch incident details
def fetch_incident(numberprgn: str):
    query = """
    SELECT network_name
    FROM dc1sm_ro.incidents
    WHERE numberprgn = %s;
    """
    conn = connect_to_postgres({})  # Use your existing connection function
    cursor = conn.cursor()
    cursor.execute(query, (numberprgn,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result
 
# Function to fetch CI details based on network_name
def fetch_ci_info(network_name: str):
    query = """
    SELECT DISTINCT LOGICAL_NAME ,NETWORK_NAME,RELATIONSHIP_SUBTYPE ,PFZ_STATUS  ,PFZ_USAGE, TYPE  , SUBTYPE ,PFZ_ADDED_TIME,OPERATING_SYSTEM ,LOCATION,PFZ_ASSIGNMENT,CI_CONTACTS ,PFZ_ESC_ASSIGNMENT,SITE_CATEGORY,TIME_ZONE ,CORP_STRUCTURE ,ALIASES ,R_LOGICAL_NAME ,R_NETWORK_NAME ,DESCRIPTION
    FROM itsm_owner.cis
    WHERE network_name = %s;
    """
    conn = connect_to_postgres({})  # Use your existing connection function
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    ci_info_list = [dict(zip(columns, row)) for row in result]
    cursor.close()
    conn.close()
    return ci_info_list
 
# Endpoint to get CI details based on `numberprgn`
@app.post("/get-ci-info")
def get_ci_info(request: IncidentRequest):
    numberprgn = request.numberprgn
    # Fetch the incident to get the network_name
    incident = fetch_incident(numberprgn)
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found.")
    # Extract the network_name from the incident data
    network_name = incident[0]
    # Fetch CI information for the matched network_name
    ci_info = fetch_ci_info(network_name)
    if not ci_info:
        raise HTTPException(status_code=404, detail="No CI information found for the given incident.")
    return ci_info




# Fetch CI Info
def get_ci_info(network_name):
    query = """
    SELECT DISTINCT LOGICAL_NAME ,NETWORK_NAME,RELATIONSHIP_SUBTYPE ,PFZ_STATUS  ,PFZ_USAGE, TYPE  , SUBTYPE ,PFZ_ADDED_TIME,OPERATING_SYSTEM ,LOCATION,PFZ_ASSIGNMENT,CI_CONTACTS ,PFZ_ESC_ASSIGNMENT,SITE_CATEGORY,TIME_ZONE ,CORP_STRUCTURE ,ALIASES ,R_LOGICAL_NAME ,R_NETWORK_NAME ,DESCRIPTION
    FROM itsm_owner.cis
    WHERE NETWORK_NAME = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    ci_info = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in ci_info]
    cursor.close()
    conn.close()
    return data

# Unified function to fetch CI relationships or dependencies
def get_ci_relationships_or_dependencies(network_name):
    query = """
    SELECT logical_name, network_name, relationship_subtype, pfz_status, pfz_usage, type, subtype, pfz_added_time, operating_system, location, pfz_assignment, ci_contacts, pfz_esc_assignment, site_category, time_zone, corp_structure, aliases, r_logical_name, r_network_name, description
    FROM itsm_owner.cis
    WHERE network_name = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    ci = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    ci_data = [dict(zip(columns, row)) for row in ci]
    
    if not ci_data:
        return []
    
    ci_type = ci_data[0]['type']
    if ci_type == 'APPLICATION':
        dependencies_query = """
        SELECT LOGICAL_NAME, NETWORK_NAME, R_LOGICAL_NAME, R_NETWORK_NAME, PFZ_STATUS, DESCRIPTION
        FROM itsm_owner.cis
        WHERE (R_NETWORK_NAME = %s OR R_LOGICAL_NAME = %s)
        AND TYPE != 'APPLICATION'
        AND PFZ_STATUS = 'Active';
        """
        cursor.execute(dependencies_query, (network_name, network_name))
    else:
        downstream_query = """
        SELECT LOGICAL_NAME, NETWORK_NAME, R_LOGICAL_NAME, R_NETWORK_NAME, PFZ_STATUS, DESCRIPTION
        FROM itsm_owner.cis
        WHERE network_name = %s
        AND PFZ_STATUS = 'Active';
        """
        cursor.execute(downstream_query, (network_name,))
    
    related_data = cursor.fetchall()
    related_columns = [desc[0] for desc in cursor.description]
    results = [dict(zip(related_columns, row)) for row in related_data]
    cursor.close()
    conn.close()
    return results

# Fetch upstream relationships
def get_ci_upstream(network_name):
    query = """
    SELECT DISTINCT NETWORK_NAME
    FROM itsm_owner.cis
    WHERE R_NETWORK_NAME = %s AND PFZ_STATUS = 'Active' AND PFZ_USAGE = 'Production';
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    upstreams_network = [row[0] for row in cursor.fetchall()]
    cursor.close()
    conn.close()
    
    try:
        upstreams_network.remove(network_name)
    except ValueError:
        pass
    
    upstream_data = []
    for net_name in upstreams_network:
        upstream_data.append(get_related_data(net_name, "dc1sm_ro.incidents", ["network_name", "description"], limit=70))
    return [item for sublist in upstream_data for item in sublist]

# Helper function for fetching related data
def get_related_data(network_name, table_name, columns, limit=70):
    query = f"""
    SELECT {', '.join(columns)}
    FROM {table_name}
    WHERE network_name = %s
    LIMIT %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name, limit))
    results = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in results]
    cursor.close()
    conn.close()
    return data

# Main API Endpoint
@app.post("/get-all-ci-data")
def get_all_ci_data(request: IncidentRequest):
    numberprgn = request.numberprgn

    # Fetch incident details to get network_name
    query = """
    SELECT network_name
    FROM dc1sm_ro.incidents
    WHERE numberprgn = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (numberprgn,))
    incident = cursor.fetchone()
    cursor.close()
    conn.close()

    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found.")

    network_name = incident[0]

    # Fetch data
    ci_info = get_ci_info(network_name)
    relationships = get_ci_relationships_or_dependencies(network_name)
    upstream = get_ci_upstream(network_name)
    downstream = get_ci_relationships_or_dependencies(network_name)  # Assuming reuse for downstream
    assignment_group = get_assignment_group(network_name)
    location = get_location(network_name)
    problems_tasks = get_problem_tasks(network_name)
    problems = get_problems(network_name)
    print(problems_tasks)

    # Return all combined data
    return {
        "network_name": network_name,
        "ci_info": ci_info,
        "relationships_or_dependencies": relationships,
        "upstream": upstream,
        "downstream": downstream,
        "assignment_group": assignment_group,
        "location": location,
        "problems_tasks": problems_tasks,
        "problems":problems
    }

# Fetch assignment group
def get_incident_assignment_group(network_name):
    query = """
    SELECT PFZ_ASSIGNMENT
    FROM itsm_owner.cis
    WHERE NETWORK_NAME = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchall()
    result = result[0][0]
    query=  f""" WITH RankedIncidents AS (
                SELECT
                    numberprgn,status, assignment,brief_description,location,open_time,
                    ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
                FROM
                    dc1sm_ro.incidents
                WHERE 
                    ASSIGNMENT = '{result}'
                )
                SELECT
                    numberprgn,status, assignment,brief_description,location,open_time,
                FROM
                    RankedIncidents
                WHERE
                    rn = 1 
                LIMIT 50;"""
    cursor.execute(query, (result,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in rows]
    cursor.close()
    conn.close()
    return data

def get_rfc_assignment_group(network_name):
    query = """
    SELECT PFZ_ASSIGNMENT
    FROM itsm_owner.cis
    WHERE NETWORK_NAME = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchall()
    result = result[0][0]
    query=  f""" WITH RankedIncidents AS (
                SELECT
                    numberprgn,status, assign_dept,brief_description,location,open_time,
                    ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
                FROM
                    dc1sm_ro.rfcs
                WHERE 
                    ASSIGN_DEPT = '{result}'
                )
                SELECT
                    numberprgn,status, assign_dept,brief_description,location
                FROM
                    RankedIncidents
                WHERE
                    rn = 1 
                LIMIT 50;"""
    cursor.execute(query, (result,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in rows]
    cursor.close()
    conn.close()
    return data

# Fetch location
def get_incident_location(network_name):
    query = """
    SELECT LOCATION
    FROM itsm_owner.cis
    WHERE NETWORK_NAME = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchall()
    result = result[0][0]
    print(result)
    
    query=  f""" WITH RankedIncidents AS (
                SELECT
                    numberprgn,status, brief_description,location,open_time,
                    ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
                FROM
                    dc1sm_ro.incidents
                WHERE 
                    LOCATION = '{result}'
                )
                SELECT
                    numberprgn,status, brief_description,location
                FROM
                    RankedIncidents
                WHERE
                    rn = 1 
                LIMIT 50;"""
    cursor.execute(query, (result,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in rows]
    cursor.close()
    conn.close()
    return data


def get_rfc_location(network_name):
    query = """
    SELECT LOCATION
    FROM itsm_owner.cis
    WHERE NETWORK_NAME = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchall()
    result = result[0][0]
    print(result)
    
    query=  f""" WITH RankedIncidents AS (
                SELECT
                    numberprgn,status, brief_description,location,open_time,
                    ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
                FROM
                    dc1sm_ro.rfcs
                WHERE 
                    LOCATION = '{result}'
                )
                SELECT
                    numberprgn,status, brief_description,location,assign_dept
                FROM
                    RankedIncidents
                WHERE
                    rn = 1 
                LIMIT 50;"""
    cursor.execute(query, (result,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in rows]
    cursor.close()
    conn.close()
    return data


def get_problem_tasks(network_name):
    query = """
    SELECT DISTINCT LOGICAL_NAME
    FROM itsm_owner.cis
    WHERE network_name = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchall()
    logical_name = result[0][0]
    print(logical_name)
    prob_tasks_query = f"""
    SELECT id,parent problem,assignment,assignee name,status,logical name,open time,brief description
    FROM dc1sm_ro.problems_tasks
    WHERE logical_name = '{logical_name}';
    """
    cursor.execute(prob_tasks_query, (logical_name,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    tasks_data = [dict(zip(columns, row)) for row in rows]
    cursor.close()
    conn.close()
    return tasks_data


def get_problems(network_name):
    query = """
    SELECT DISTINCT LOGICAL_NAME
    FROM itsm_owner.cis
    WHERE network_name = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchall()
    logical_name = result[0][0]
    print(logical_name)
    prob_tasks_query = f"""
    SELECT id,category,assignment,status,logical name,open time,description,brief description
    FROM dc1sm_ro.problems
    WHERE logical_name = '{logical_name}';
    """
    cursor.execute(prob_tasks_query, (logical_name,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    tasks_data = [dict(zip(columns, row)) for row in rows]
    cursor.close()
    conn.close()
    return tasks_data



def get_ci_based_events(network_name):
    query = """
    SELECT network_name
    FROM dc1sm_ro.incidents
    WHERE numberprgn = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchall()
    result = result[0][0]
    query=  """WITH RankedEvents AS (
                    SELECT
                        event_id,
                        created_ts,
                        event_title,
                        severity,
                        event_status,
                        ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY created_ts DESC) AS rn
                    FROM
                        dc1.events
                        
                    WHERE 
                        NETWORK_NAME = '{result}'
                )
                SELECT
                    event_id,  created_ts, event_title, severity, event_status
                FROM
                    RankedEvents
                WHERE
                    rn = 1
                ORDER BY
                    created_ts DESC;
                """
    cursor.execute(query, (result,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in rows]
    cursor.close()
    conn.close()
    return data

def get_ci_based_incidents(network_name):
    query = """
    SELECT network_name
    FROM dc1sm_ro.incidents
    WHERE numberprgn = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchall()
    result = result[0][0]
    query=  f""" WITH RankedIncidents AS (
                SELECT
                    numberprgn,status, assignment,brief_description,location,open_time,
                    ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
                FROM
                    dc1sm_ro.incidents
                WHERE 
                    NETWORK_NAME = '{result}'
                )
                SELECT
                    numberprgn,status, assignment,brief_description,location,open_time
                FROM
                    RankedIncidents
                WHERE
                    rn = 1
                ORDER BY
                    open_time DESC;"""

    cursor.execute(query, (result,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in rows]
    cursor.close()
    conn.close()
    return data

def get_ci_based_rfcs(network_name):
    query = """
    SELECT network_name
    FROM dc1sm_ro.incidents
    WHERE numberprgn = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchall()
    result = result[0][0]
    query=  f""" WITH RankedIncidents AS (
                SELECT
                    numberprgn,status,network_name, assign_dept,brief_description,location,open_time,
                    ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
                FROM
                    dc1sm_ro.rfcs
                WHERE 
                    NETWORK_NAME = '{result}'
                )
                SELECT
                    numberprgn,status,network_name, assign_dept,brief_description,location,open_time
                FROM
                    RankedIncidents
                WHERE
                    rn = 1 
                ORDER BY
                    open_time DESC;"""
                
    cursor.execute(query, (result,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in rows]
    cursor.close()
    conn.close()
    return data

 
# Fetch assignment group
def get_assignment_group(network_name):
    query = """
    SELECT PFZ_ASSIGNMENT
    FROM itsm_owner.cis
    WHERE NETWORK_NAME = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result[0] if result else None
 
# Fetch location
def get_location(network_name):
    query = """
    SELECT LOCATION
    FROM itsm_owner.cis
    WHERE NETWORK_NAME = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result[0] if result else None



if __name__ == "__main__":
    import uvicorn
    uvicorn.run("test:app",reload=True ,host="127.0.0.1", port=8014)