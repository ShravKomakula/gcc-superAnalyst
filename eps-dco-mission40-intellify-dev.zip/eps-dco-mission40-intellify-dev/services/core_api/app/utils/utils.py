from fastapi import HTTPException
from database.database import connect_to_postgres
from typing import List,Optional
from psycopg2.extras import RealDictCursor
from datetime import datetime, timedelta
import traceback


# # -------------- page_router -------------


# Helper to execute paginated SQL queries
def execute_paginated_query(query: str, params: Optional[tuple], page: int, page_size: int):
    try:
        offset = (page - 1) * page_size
        paginated_query = f"{query} LIMIT %s OFFSET %s"
        with connect_to_postgres({}) as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(paginated_query, params + (page_size, offset))
                return cursor.fetchall()
    except Exception as e:
        print(f"Error executing query: {e}")
        raise HTTPException(status_code=500, detail="Database query failed")
    
# # Helper function to fetch total record count
# def get_total_count(query: str, params: Optional[tuple] = None):
#     count_query = f"SELECT COUNT(*) FROM ({query}) AS total"
#     rows, _ = execute_query(count_query, params)
#     return rows[0][0] if rows else 0





# Helper Function for PostgreSQL Queries
def execute_query(query: str, params: tuple = None):
    """
    Execute a PostgreSQL query and return the result.
    """
    try:
        conn = connect_to_postgres({})
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            if query.strip().upper().startswith(("WITH","SELECT")):
                columns = [desc[0] for desc in cursor.description]
                rows = cursor.fetchall()
                return rows,columns
            conn.commit()
    except Exception as e:
        print(f"Error executing query: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    finally:
        conn.close()

def fetch_query_results(query: str, params: tuple, columns: List[str]):
    """
    Execute a query and return the results as a list of dictionaries.
    """
    rows,columns = execute_query(query, params)
    return [dict(zip(columns, row)) for row in rows]


# Helper function to fetch total record count
def get_total_count(query: str, params: Optional[tuple] = None):
    count_query = f"SELECT COUNT(*) FROM ({query}) AS total"
    rows, _ = execute_query(count_query, params)
    return rows[0][0] if rows else 0




def get_days_hours(incident_filter, latest_open_time):
    print("************************** functions in side get_days_hours ")
    try:
        if incident_filter is not None:
            # Convert latest_open_time to datetime if it's a string
            if isinstance(latest_open_time, str):
                latest_open_time = datetime.strptime(latest_open_time, "%Y-%m-%d %H:%M:%S")  # Adjust format if needed

            start_date = incident_filter.start_date
            end_date = incident_filter.end_date
            
            print("latest_open_time:", latest_open_time)
            print("start date",start_date)
            print("end date",end_date)
            

            # Ensure start_date and end_date are datetime objects
            if isinstance(start_date, str):
                start_date = datetime.strptime(start_date, "%Y-%m-%d %H:%M:%S")
            if isinstance(end_date, str):
                end_date = datetime.strptime(end_date, "%Y-%m-%d %H:%M:%S")

            # time_difference = end_date - start_date
            # days = time_difference.days
            # hours = time_difference.seconds // 3600  # Convert seconds to hours
            
            # print("incident_filter:", incident_filter)
            # print("Start date:", start_date)
            # print("End date:", end_date)
            # print(f"Duration: {days} days and {hours} hours")

       
            # if days <= 10:
            #     start_time = latest_open_time - timedelta(days=days, hours=hours)
            #     end_time = latest_open_time + timedelta(days=days, hours=hours)
            # else:
            #     start_time = latest_open_time - timedelta(days=days, hours=hours)
            #     end_time = latest_open_time + timedelta(days=10, hours=0)
                
            return start_date, end_date

    except Exception as e:
        print("Error occurred in get_days_hours_daterange function!")
        print("Error message:", str(e))
        print("Traceback details:")
        traceback.print_exc()  # Print full traceback to see the exact line of the error

        return None, None  # Return None in case of an error
