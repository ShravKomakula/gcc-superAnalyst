from database.database import connect_to_postgres
from datetime import datetime, timedelta
from ..utils import get_days_hours

def get_rfc_location(network_name, rfc_filter,open_time):
    try:
        # Fetch the latest location
        query = """
        SELECT LOCATION
        FROM itsm_owner.cis
        WHERE NETWORK_NAME = %s;
        """
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        cursor.execute(query, (network_name,))
        result = cursor.fetchall()
        
        if not result:
            raise Exception(f"No location found for network_name: {network_name}")
        
        result = result[0][0]  # Extract location
        
        result = f"{result}"
        print("result",result)
        latest_open_time=open_time
        
        
        # # Get the latest RFC's open_time
        ''' if open_time == "None":
            query = f"""
            SELECT open_time
            FROM dc1sm_ro.rfcs
            WHERE LOCATION = %s
            ORDER BY open_time DESC
            LIMIT 1;
            """
            cursor.execute(query, (result,))
            latest_open_time = cursor.fetchone()
            latest_open_time = latest_open_time[0]  # Extract the open_time
            
            
            if not latest_open_time:
                raise Exception(f"No RFC records found for location: {result}")'''
            
        
        
        print(f"Latest open_time: {latest_open_time}")

        # Calculate the time window for filtering RFCs based on user input
        # rfc_cutoff_time = latest_open_time - timedelta(days=rfc_filter) if rfc_filter else None
        rfc_cutoff_time_before,rfc_cutoff_time_after=get_days_hours(rfc_filter,latest_open_time)


        # Build the RFC query with additional date filter
        query = f"""
        WITH RankedRfcs AS (
            SELECT
                numberprgn,
                status,
                brief_description,
                location,
                open_time,
                network_name,
                ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
            FROM
                dc1sm_ro.rfcs
            WHERE
                LOCATION = '{result}'
            {f"AND open_time >= '{rfc_cutoff_time_before}' AND open_time <= '{rfc_cutoff_time_after}'" if rfc_cutoff_time_before else ''}        )
        SELECT
            numberprgn,
            status,
            brief_description,
            location,
            open_time,
            network_name
        FROM
            RankedRfcs
        WHERE
            rn = 1
        ORDER BY
            open_time DESC;  
        """
        cursor.execute(query)
        rows = cursor.fetchall()
        print("rows", rows)
        rfcs_data={}
        if rows == []:
            #raise Exception(f"No RFC records found for location: {result}")
            pass
        else:
            columns = [desc[0] for desc in cursor.description]
            rfcs_data = [dict(zip(columns, row)) for row in rows]
            print("rfcs_data",rfcs_data)

        cursor.close()
        conn.close()

        return rfcs_data

    except Exception as e:
        cursor.close()
        conn.close()
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }