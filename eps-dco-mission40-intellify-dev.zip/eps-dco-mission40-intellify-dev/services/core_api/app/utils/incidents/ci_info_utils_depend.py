from fastapi import HTTPException
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.ci_based_incidents import get_ci_based_incidents
from datetime import timedelta

from utils.utils import get_days_hours
# Function to fetch incident details
def fetch_incident(numberprgn: str):
    query = """
    SELECT network_name
    FROM dc1sm_ro.incidents
    WHERE numberprgn = %s;
    """
    conn = connect_to_postgres({})  # Use your existing connection function
    cursor = conn.cursor()
    cursor.execute(query, (numberprgn,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result

def fetch_ci_info(network_name: str):
    query = """
    SELECT DISTINCT LOGICAL_NAME ,NETWORK_NAME,RELATIONSHIP_SUBTYPE ,PFZ_STATUS  ,PFZ_USAGE, TYPE  , SUBTYPE ,PFZ_ADDED_TIME,OPERATING_SYSTEM ,LOCATION,PFZ_ASSIGNMENT,CI_CONTACTS ,PFZ_ESC_ASSIGNMENT,SITE_CATEGORY,TIME_ZONE ,CORP_STRUCTURE ,ALIASES ,R_LOGICAL_NAME ,R_NETWORK_NAME ,DESCRIPTION
    FROM itsm_owner.cis
    WHERE network_name = %s;
    """
    conn = connect_to_postgres({})  # Use your existing connection function
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    ci_info_list = [dict(zip(columns, row)) for row in result]
    cursor.close()
    conn.close()
    return ci_info_list[0]

# Fetch CI Info
def get_ci_info(network_name):
    query = """
    SELECT DISTINCT LOGICAL_NAME ,NETWORK_NAME,RELATIONSHIP_SUBTYPE ,PFZ_STATUS  ,PFZ_USAGE, TYPE  , SUBTYPE ,PFZ_ADDED_TIME,OPERATING_SYSTEM ,LOCATION,PFZ_ASSIGNMENT,CI_CONTACTS ,PFZ_ESC_ASSIGNMENT,SITE_CATEGORY,TIME_ZONE ,CORP_STRUCTURE ,ALIASES ,R_LOGICAL_NAME ,R_NETWORK_NAME ,DESCRIPTION
    FROM itsm_owner.cis
    WHERE NETWORK_NAME = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    ci_info = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in ci_info]
    cursor.close()
    conn.close()
    return data[0]

 # Fetch upstream relationships
def get_ci_upstream(network_name):
    query = """
    SELECT  DISTINCT NETWORK_NAME
    FROM itsm_owner.cis
    WHERE R_NETWORK_NAME = %s AND PFZ_STATUS = 'Active' AND PFZ_USAGE = 'Production';
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    related_data = cursor.fetchall()
    #print("related_data      :",related_data)
    related_columns = [desc[0] for desc in cursor.description]
    upstream_results = [dict(zip(related_columns, row)) for row in related_data]
    cursor.close()
    conn.close()
    
    return upstream_results

def downstreams(network_name):
    downstream_query = """
        SELECT DISTINCT NETWORK_NAME
        FROM itsm_owner.cis
        WHERE NETWORK_NAME = %s AND PFZ_STATUS = 'Active' AND PFZ_USAGE = 'Production';
        """
    #print("downstream_query is ok:", downstream_query,network_name)
    conn = connect_to_postgres({})
    #print("connection is ok")
    cursor = conn.cursor()
    cursor.execute(downstream_query, (network_name,))
    related_data = cursor.fetchall()
    #print("downstream related_data :",related_data)
    related_columns = [desc[0] for desc in cursor.description]
    downstream_results = [dict(zip(related_columns, row)) for row in related_data]
    cursor.close()
    conn.close()
    return downstream_results
    
def get_related_data(network_name, table_name, columns, limit=70):
    query = f"""
    SELECT {', '.join(columns)}
    FROM {table_name}
    WHERE network_name = %s
    LIMIT %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name, limit))
    related_results = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in related_results]
    cursor.close()
    conn.close()
    return data



def get_ci_filter_based_incidents(network_name, hosted_networks,incident_filter):
    conn = connect_to_postgres({})
    cursor = conn.cursor()

    # Get the latest incident's open_time for the provided network_name
    query = """
    SELECT open_time
    FROM dc1sm_ro.incidents
    WHERE NETWORK_NAME = %s
    ORDER BY open_time DESC
    LIMIT 1;
    """
    cursor.execute(query, (network_name,))
    latest_open_time_result = cursor.fetchone()

    if not latest_open_time_result:
        raise HTTPException(status_code=404, detail="No incidents found for the provided network_name.")

    latest_open_time = latest_open_time_result[0]
    incident_cutoff_time_before,incident_cutoff_time_after=get_days_hours(incident_filter,latest_open_time)

    # Calculate the incident cutoff time based on the incident_filter
    # incident_cutoff_time = latest_open_time - timedelta(days=incident_filter) if incident_filter else None

    # Build the query with the cutoff time filter
    query = f"""
    WITH RankedIncidents AS (
        SELECT
            numberprgn, status, assignment, brief_description, location, open_time,network_name,
            ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
        FROM
            dc1sm_ro.incidents
        WHERE
            NETWORK_NAME IN %s
            {f"AND open_time >= '{incident_cutoff_time_before}'  AND open_time <= '{incident_cutoff_time_after}'" if incident_cutoff_time_after else ''}
            
    )
    SELECT
        numberprgn, status, assignment, brief_description, location, open_time, network_name
    FROM
        RankedIncidents
    WHERE
        rn = 1
    ORDER BY
        open_time DESC
    LIMIT 10;
    """
    cursor.execute(query, (tuple(hosted_networks),))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    incidents_data = [dict(zip(columns, row)) for row in rows]

    cursor.close()
    conn.close()

    return incidents_data


def get_ci_filter_based_rfcs(network_name,hosted_networks, rfc_filter=None):
    conn = connect_to_postgres({})
    cursor = conn.cursor()

    # Calculate the RFC cutoff time if a filter is provided
    rfc_cutoff_time = None
    if rfc_filter:
        latest_query = """
        SELECT open_time
        FROM dc1sm_ro.rfcs
        WHERE NETWORK_NAME = %s
        ORDER BY open_time DESC
        LIMIT 1;
        """
        cursor.execute(latest_query, (network_name,))
        latest_open_time_result = cursor.fetchone()

        if latest_open_time_result:
            latest_open_time = latest_open_time_result[0]
            incident_cutoff_time_before,incident_cutoff_time_after=get_days_hours(rfc_filter,latest_open_time)
            

    # Build the query with the cutoff time filter
    query = f"""
    WITH RankedRFCs AS (
        SELECT
            numberprgn, status, network_name, assign_dept, brief_description, location, open_time,
            ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
        FROM
            dc1sm_ro.rfcs
        WHERE 
            NETWORK_NAME IN %s
            {f"AND open_time >= '{incident_cutoff_time_before}'  AND open_time <= '{incident_cutoff_time_after}'" if incident_cutoff_time_after else ''}
    )
    SELECT
        numberprgn, status, network_name, assign_dept, brief_description, location, open_time
    FROM
        RankedRFCs
    WHERE
        rn = 1
    ORDER BY
        open_time DESC;
    """
    cursor.execute(query, (tuple(hosted_networks),))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in rows]
    
    cursor.close()
    conn.close()
    return data

def get_ci_relationships_or_dependencies(network_name,incident_filter,rfc_filter):
    query = """
    SELECT DISTINCT logical_name, network_name, pfz_application_name, relationship_subtype, pfz_status, pfz_usage, type, subtype, pfz_added_time, operating_system, location, pfz_assignment, ci_contacts, pfz_esc_assignment, site_category, time_zone, corp_structure, aliases, r_logical_name, r_network_name, description
    FROM itsm_owner.cis
    WHERE network_name = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    ci = cursor.fetchall()
    #print("ciiiiiiiiiiiiiiiiiiiii  :",  ci)
    columns = [desc[0] for desc in cursor.description]
    ci_data = [dict(zip(columns, row)) for row in ci]
   
    if not ci_data:
        return []
   
    infra_results = []  # Initialize with an empty list

    ci_type = ci_data[0]['type']
    ci_application = ci_data[0]['pfz_application_name']
    if ci_type == 'APPLICATION':
        dependencies_query = """
        SELECT DISTINCT NETWORK_NAME
        FROM itsm_owner.cis
        WHERE (R_NETWORK_NAME = %s OR R_LOGICAL_NAME = %s)
        AND TYPE != 'APPLICATION'
        AND PFZ_STATUS = 'Active';
        """
        cursor.execute(dependencies_query, (network_name, network_name))
   
        related_data = cursor.fetchall()
        #print("related_data        :  ",related_data)
        #related_columns = [desc[0] for desc in cursor.description]
        infra_networks = [row[0] for row in related_data]
        downstreams_incidents = get_ci_filter_based_incidents(network_name,infra_networks, incident_filter)
        downstreams_rfcs = get_ci_filter_based_rfcs(network_name,infra_networks, rfc_filter)
        hosted_networks_query = """SELECT DISTINCT NETWORK_NAME FROM itsm_owner.cis WHERE PFZ_APPLICATION_NAME=%s"""
        cursor.execute(hosted_networks_query, (ci_application, ))
        hosted_networks_data = cursor.fetchall()
        #print("hosted_networks_data             :",hosted_networks_data)
        #hosted_network_columns = [desc[0] for desc in cursor.description]
        hosted_networks = [row[0] for row in hosted_networks_data]
        upstream_incidents = get_ci_filter_based_incidents(network_name,hosted_networks, incident_filter)
        upstream_rfcs = get_ci_filter_based_rfcs(network_name,hosted_networks, rfc_filter)
        
    else:
        upstreams = get_ci_upstream(network_name)
        upstreams_networks = [row["network_name"] for row in upstreams]
        downstreams_results = downstreams(network_name)
        downstreams_networks = [row["network_name"] for row in downstreams_results]
        upstream_incidents = get_ci_filter_based_incidents(network_name,upstreams_networks, incident_filter)
        upstream_rfcs = get_ci_filter_based_rfcs(network_name,upstreams_networks, rfc_filter)
        downstreams_incidents = get_ci_filter_based_incidents(network_name,downstreams_networks, incident_filter)
        downstreams_rfcs = get_ci_filter_based_rfcs(network_name,downstreams_networks, rfc_filter)
        
        
   
    cursor.close()
    conn.close()
    return upstream_incidents,upstream_rfcs,downstreams_incidents,downstreams_rfcs

