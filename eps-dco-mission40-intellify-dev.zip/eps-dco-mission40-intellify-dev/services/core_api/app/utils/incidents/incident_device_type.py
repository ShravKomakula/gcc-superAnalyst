from database.database import connect_to_postgres,get_postgres_secrets

from datetime import timedelta
from ..utils import get_days_hours

def get_incident_device_type(product_type, incident_filter=None):
    # Fetch the latest assignment for the given network_name
    # query = """
    # SELECT PFZ_ASSIGNMENT
    # FROM itsm_owner.cis
    # WHERE NETWORK_NAME = %s;
    # """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    # cursor.execute(query, (network_name,))
    # result = cursor.fetchall()
    # if not result:
    #     cursor.close()
    #     conn.close()
    #     raise Exception(f"No assignment found for network_name: {network_name}")
    
    # result = result[0][0]

    # Build the query for filtering based on incident_filter (number of days)
    # Get the latest incident's open_time
    query = f"""
    SELECT open_time
    FROM dc1sm_ro.incidents
    WHERE PRODUCT_TYPE = %s
    ORDER BY open_time DESC
    LIMIT 1;
    """
    cursor.execute(query, (product_type,))
    latest_open_time = cursor.fetchone()
    if not latest_open_time:
        cursor.close()
        conn.close()
        raise Exception(f"No incident records found for assignment:{product_type} ")
    
    latest_open_time = latest_open_time[0]  # Extract the open_time

    # Calculate the cutoff time for filtering incidents
    if incident_filter:
        cutoff_time_before,cutoff_time_after=get_days_hours(incident_filter,latest_open_time)
        # cutoff_time = latest_open_time - timedelta(days=incident_filter)
        incident_filter_condition = f"AND open_time >= '{cutoff_time_before}'  AND open_time <= '{cutoff_time_after}'"
    else:
        incident_filter_condition = ""

    # Get the incidents with the applied filter
    query = f"""
    WITH RankedIncidents AS (
        SELECT
            numberprgn,
            product_type,
            status,
            assignment,
            brief_description,
            location,
            open_time,
            network_name,
            ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
        FROM
            dc1sm_ro.incidents
        WHERE
            PRODUCT_TYPE = %s
            {incident_filter_condition}
    )
    SELECT
        numberprgn,
        product_type,
        status,
        assignment,
        brief_description,
        location,
        open_time,
        network_name
    FROM
        RankedIncidents
    WHERE
        rn = 1
    ORDER BY
        open_time DESC
    LIMIT 70;
    """
    cursor.execute(query, (product_type,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in rows]

    cursor.close()
    conn.close()

    return data