from database.database import connect_to_postgres,get_postgres_secrets

from datetime import timedelta
from ..utils import get_days_hours

def get_rfc_device_type(rfc_type, rfc_filter=None,open_time="None"):
    # Fetch the latest assignment for the given network_name
    # query = """
    # SELECT PFZ_ASSIGNMENT
    # FROM itsm_owner.cis
    # WHERE NETWORK_NAME = %s;
    # """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    # cursor.execute(query, (network_name,))
    # result = cursor.fetchall()
    # if not result:
    #     cursor.close()
    #     conn.close()
    #     raise Exception(f"No assignment found for network_name: {network_name}")
    
    # result = result[0][0]

    # Build the query for filtering based on incident_filter (number of days)
    # Get the latest incident's open_time
    latest_open_time=open_time
    if open_time == "None":
        #print("rfc device type  Noneee line number 28")
        query = f"""
        SELECT open_time
        FROM dc1sm_ro.rfcs
        WHERE TYPE = %s
        ORDER BY open_time DESC
        LIMIT 1;
        """
        cursor.execute(query, (rfc_type,))
        latest_open_time = cursor.fetchone()
        if not latest_open_time:
            cursor.close()
            conn.close()
            raise Exception(f"No RFC records found for assignment: {rfc_type}")

        latest_open_time = latest_open_time[0]  # Extract the open_time
    print(" latest_open_time rfc device type  line number 43 ",latest_open_time)
    # Calculate the cutoff time for filtering RFCs
    if rfc_filter:
        cutoff_time_before,cutoff_time_after=get_days_hours(rfc_filter,latest_open_time)

        # cutoff_time = latest_open_time - timedelta(days=rfc_filter)
        rfc_filter_condition = f"AND open_time >= '{cutoff_time_before}' AND open_time <= '{cutoff_time_after}'"
    else:
        rfc_filter_condition = ""
    print(" rfc_filter_condition rfc device type  line number 52 ",rfc_filter_condition)

    # Get the RFCs with the applied filter
    query = f"""
    WITH RankedRFCs AS (
        SELECT
            numberprgn,
            type,
            status,
            assign_dept,
            brief_description,
            location,
            open_time,
            network_name,
            ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
        FROM
            dc1sm_ro.rfcs
        WHERE
            TYPE = %s
            {rfc_filter_condition}
    )
    SELECT
        numberprgn,
        type,
        status,
        brief_description,
        location,
        assign_dept,
        network_name
    FROM
        RankedRFCs
    WHERE
        rn = 1
    ORDER BY
        open_time DESC
    LIMIT 70;
    """
    cursor.execute(query, (rfc_type,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in rows]
    print(" data rfc device type  line number 91 ",data)
    

    cursor.close()
    conn.close()

    return data