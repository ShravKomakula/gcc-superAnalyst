from database.database import connect_to_postgres,get_postgres_secrets
import pandas as pd

# Function to fetch incident details
def fetch_incident(numberprgn: str):
    query = """
    SELECT network_name
    FROM dc1sm_ro.incidents
    WHERE numberprgn = %s;
    """
    conn = connect_to_postgres({})  # Use your existing connection function
    cursor = conn.cursor()
    cursor.execute(query, (numberprgn,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result

# def fetch_ci_info(network_name: str):
#     query = """
#     SELECT DISTINCT LOGICAL_NAME ,NETWORK_NAME,ISTATUS  ,PFZ_USAGE, TYPE  , SUBTYPE ,PFZ_ADDED_TIME,OPERATING_SYSTEM ,LOCATION,PRIMARY_CONTACT,PFZ_ASSIGNMENT,PRIMARY_CONTACT,CI_CONTACTS ,PFZ_ESC_ASSIGNMENT,SITE_CATEGORY,TIME_ZONE ,CORP_STRUCTURE ,ALIASES ,R_LOGICAL_NAME ,R_NETWORK_NAME ,DESCRIPTION
#     FROM itsm_owner.cis
#     WHERE network_name = %s;
#     """
#     conn = connect_to_postgres({})  # Use your existing connection function
#     cursor = conn.cursor()
#     cursor.execute(query, (network_name,))
#     result = cursor.fetchall()
#     columns = [desc[0] for desc in cursor.description]
#     ci_info_list = [dict(zip(columns, row)) for row in result]
#     cursor.close()
#     conn.close()
#     return ci_info_list[0]

# Fetch CI Info
def get_ci_info(network_name):
    query = """
    SELECT DISTINCT LOGICAL_NAME ,NETWORK_NAME,ISTATUS  ,PFZ_USAGE, TYPE  , SUBTYPE ,PFZ_ADDED_TIME,OPERATING_SYSTEM ,LOCATION,PRIMARY_CONTACT, PFZ_ASSIGNMENT,CI_CONTACTS ,PFZ_ESC_ASSIGNMENT,SITE_CATEGORY,TIME_ZONE ,CORP_STRUCTURE ,ALIASES ,R_LOGICAL_NAME ,R_NETWORK_NAME ,DESCRIPTION
    FROM itsm_owner.cis
    WHERE NETWORK_NAME = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    ci_info = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in ci_info]
    cursor.close()
    conn.close()
    return data[0]

def fetch_ci_info(network_name):

    print("FETCH FUN IN UTILS CI NAME_______\n\n",network_name)

    query = """
    SELECT DISTINCT LOGICAL_NAME ,NETWORK_NAME,ISTATUS  ,PFZ_USAGE, TYPE  , SUBTYPE ,PFZ_ADDED_TIME,
    OPERATING_SYSTEM ,LOCATION,PRIMARY_CONTACT, PFZ_ASSIGNMENT,CI_CONTACTS ,PFZ_ESC_ASSIGNMENT,SITE_CATEGORY,
    TIME_ZONE ,CORP_STRUCTURE ,ALIASES ,R_LOGICAL_NAME ,R_NETWORK_NAME ,DESCRIPTION
    FROM itsm_owner.cis
    WHERE NETWORK_NAME = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    ci_info = cursor.fetchall()
    print("\nCURSOR fetch DATA FROM DB---\n", ci_info)
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in ci_info]
    df = pd.DataFrame(data,columns=columns)
    print("\nCURSOR fetch DATA FROM DB after zipping---\n", df)
    df['primary_ci_contact']= df['ci_contacts'][0]
    print("data from p contact",len(df))
    if len(df)>1:
        data = df.loc[1]
    else:
        data=df.loc[0]
    cursor.close()
    conn.close()
    return data

 # Fetch upstream relationships
def get_ci_upstream(network_name):
    query = """
    SELECT  DISTINCT LOGICAL_NAME, NETWORK_NAME, R_LOGICAL_NAME, R_NETWORK_NAME, PFZ_STATUS, DESCRIPTION
    FROM itsm_owner.cis
    WHERE R_NETWORK_NAME = %s AND PFZ_STATUS = 'Active' AND PFZ_USAGE = 'Production';
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    related_data = cursor.fetchall()
    related_columns = [desc[0] for desc in cursor.description]
    upstream_results = [dict(zip(related_columns, row)) for row in related_data]
    cursor.close()
    conn.close()
    
    return upstream_results

def downstreams(network_name):
    downstream_query = """
        SELECT DISTINCT LOGICAL_NAME, NETWORK_NAME, R_LOGICAL_NAME, R_NETWORK_NAME, PFZ_STATUS, DESCRIPTION
        FROM itsm_owner.cis
        WHERE NETWORK_NAME = %s AND PFZ_STATUS = 'Active' AND PFZ_USAGE = 'Production';
        """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(downstream_query, (network_name,))
    related_data = cursor.fetchall()
    related_columns = [desc[0] for desc in cursor.description]
    downstream_results = [dict(zip(related_columns, row)) for row in related_data]
    cursor.close()
    conn.close()
    return downstream_results
    
def get_related_data(network_name, table_name, columns, limit=70):
    query = f"""
    SELECT {', '.join(columns)}
    FROM {table_name}
    WHERE network_name = %s
    LIMIT %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name, limit))
    related_results = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in related_results]
    cursor.close()
    conn.close()
    return data

def get_ci_relationships_or_dependencies(network_name):
    query = """
    SELECT DISTINCT logical_name, network_name, relationship_subtype, pfz_status, pfz_usage, type, subtype, pfz_added_time, operating_system, location, pfz_assignment, ci_contacts, pfz_esc_assignment, site_category, time_zone, corp_structure, aliases, r_logical_name, r_network_name, description
    FROM itsm_owner.cis
    WHERE network_name = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    ci = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    ci_data = [dict(zip(columns, row)) for row in ci]
   
    if not ci_data:
        return []
   
    infra_results = []  # Initialize with an empty list

    ci_type = ci_data[0]['type']
    if ci_type == 'APPLICATION':
        dependencies_query = """
        SELECT DISTINCT LOGICAL_NAME, NETWORK_NAME, R_LOGICAL_NAME, R_NETWORK_NAME, PFZ_STATUS, DESCRIPTION
        FROM itsm_owner.cis
        WHERE (R_NETWORK_NAME = %s OR R_LOGICAL_NAME = %s)
        AND TYPE != 'APPLICATION'
        AND PFZ_STATUS = 'Active';
        """
        cursor.execute(dependencies_query, (network_name, network_name))
   
        related_data = cursor.fetchall()
        related_columns = [desc[0] for desc in cursor.description]
        infra_results = [dict(zip(related_columns, row)) for row in related_data]
   
    cursor.close()
    conn.close()
    return infra_results
