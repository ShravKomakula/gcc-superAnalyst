# from fastapi import Depends
import httpx

# Define a dependency for the httpx.AsyncClient
async def get_http_client():
    async with httpx.AsyncClient() as client:
        yield client
