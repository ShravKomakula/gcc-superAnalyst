from fastapi import APIRouter, HTTPException, BackgroundTasks
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
import logging
from routers.ingst.schemas import IngestionRequest
from routers.ingst.utils import get_status, auto_token, INGEST_URL, PINGFEDERATE_URL, CLIENT_ID, CLIENT_SECRET, choose_index
import requests
from datetime import datetime, timedelta
import boto3
from botocore.exceptions import ClientError
import json
import os
from tqdm import tqdm
import pandas as pd
import numpy as np
from concurrent.futures import ThreadPoolExecutor
from threading import Lock, current_thread
import asyncio

# Create a new router
ingest_router = APIRouter()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create the scheduler
scheduler = AsyncIOScheduler()
scheduler.start()

token = None
token_gen_time = None

from typing import List
from routers.ingst.vox import IASOpenaiEmbeddings
import os
from dotenv import load_dotenv

from routers.universal.vox import IASOpenaiEmbeddings

if os.getenv("opensearch_secret") is None:
    load_dotenv()

def get_secret():

    secret_name = os.getenv("opensearch_secret")
    region_name = "us-east-1"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        # For a list of exceptions thrown, see
        raise e

    secret = get_secret_value_response['SecretString']
    #a = get_secret_value_response['SecretString']['OpenAI']
    return secret


# Initialize the embedding model
# model = SentenceTransformer('all-MiniLM-L6-v2')  # You can use other models as well
model = IASOpenaiEmbeddings(engine="text-embedding-ada-002")

# OpenSearch Configuration
access_json = json.loads(get_secret())
opensearch_host = access_json['opensearch_host']
headers = {"Content-Type": "application/json"}
username = access_json['username']
password = access_json['password']
auth = (username, password)

async def auto_token():
    global token, token_gen_time
    current_time = datetime.now()
    if not token or (current_time - token_gen_time > timedelta(minutes=25)):
        try:
            payload = f"client_id={CLIENT_ID}&client_secret={CLIENT_SECRET}"
            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
            }
            response = requests.post(PINGFEDERATE_URL, headers=headers, data=payload)
            response.raise_for_status()
            token_data = response.json()
            token = token_data["access_token"]
            token_gen_time = current_time
            logger.info("Token refreshed successfully.")
        except requests.exceptions.RequestException as e:
            logger.error("Failed to refresh token: %s", e)
            raise HTTPException(status_code=500, detail="Token refresh failed.")
    return token


def list_files_in_folder(bucket_name, folder_name):
    """
    List all files in a folder, including nested subfolders, within an S3 bucket.
    The output will show file paths relative to the specified folder_name.
    """
    s3_client = boto3.client('s3')
    paginator = s3_client.get_paginator('list_objects_v2')
    file_names = []

    # Use paginator to handle large numbers of objects
    for page in paginator.paginate(Bucket=bucket_name, Prefix=folder_name):
        for obj in page.get('Contents', []):
            # Remove the folder_name prefix to get relative paths
            relative_path = obj['Key'].replace(folder_name, '', 1)
            if relative_path:  # Exclude empty results (e.g., the folder itself)
                file_names.append(relative_path)
    
    return file_names

def generate_presigned_url(bucket_name, folder_name, file_name, expiration=3600):
    """Generate a presigned URL for accessing an S3 object."""
    s3_client = boto3.Session(region_name='us-east-1').client('s3')
    object_key = f"{folder_name}{file_name}"
    presigned_url = s3_client.generate_presigned_url(
        'get_object',
        Params={'Bucket': bucket_name, 'Key': object_key},
        ExpiresIn=expiration
    )
    return presigned_url


# def load_csv_from_s3(presigned_url):
#     """Load a CSV file from a presigned S3 URL into a DataFrame."""
#     print(f"Loading CSV from presigned URL: {presigned_url}")
#     data = pd.read_csv(presigned_url)
#     print(data.head(10))
#     return data

def load_csv_from_s3(presigned_url):
    try:
        response = requests.get(presigned_url)
        if response.status_code == 200:
            data = pd.read_csv(presigned_url)
            print(data.head(10))
            return data
        else:
            print(f"Failed to download file. HTTP Status Code: {response.status_code}")
            return []
    except Exception as e:
        print(f"An error occurred: {e}")
        return []


def chunk_text(text: str, chunk_size: int = 50) -> List[str]:
    words = text.split()
    return [' '.join(words[i:i + chunk_size]) for i in range(0, len(words), chunk_size)]


def initialise_index(index_name, index):
    index_settings = choose_index(index)

    print(index_settings)

    # Check if the index exists
    response = requests.head(f"{opensearch_host}/{index_name}", auth=auth)

    if response.status_code == 404:  # Index does not exist
        # Create the index
        response = requests.put(
            f"{opensearch_host}/{index_name}",
            headers=headers,
            data=json.dumps(index_settings),
            auth=auth
        )
        print("Index creation response:", response.json())
    else:
        print(f"Index '{index_name}' already exists.")

# Step 3: Generate Embeddings and Prepare Data
def process_and_ingest_file(bucket_name, folder_name, file_name, index_name, index):
    print(f"Processing file: {file_name}")
    presigned_url = generate_presigned_url(bucket_name, folder_name, file_name)
    data = load_csv_from_s3(presigned_url)

    chunked_data = []
    batch_size = 1000  # Process data in batches to handle large datasets
    print("---data")
    print(type(data))
    print(data.shape)

    if not data.empty:
        # for start_idx in tqdm(range(0, len(data), batch_size), desc="Processing Batches"):
        for start_idx in range(0, len(data), batch_size):
            print(f"Processing batch {start_idx // batch_size + 1}...")
            batch = data.iloc[start_idx:start_idx + batch_size]
            for _, row in batch.iterrows():
                if index == "cis": 
                    row_cleaned = row.apply(lambda x: 0.0 if (pd.isna(x) or (isinstance(x, float) and np.isnan(x))) else x)
                    chunked_data.append({
                        "id": f"{row_cleaned['LOGICAL_NAME']}",
                        "title": row_cleaned['LOGICAL_NAME'],
                        "network_name": row_cleaned['NETWORK_NAME'], 
                        "r_logical_name": row_cleaned['R_LOGICAL_NAME'],
                        "r_network_name": row_cleaned['R_NETWORK_NAME'], 
                        "pfz_application_name": row_cleaned['PFZ_APPLICATION_NAME'],
                        "description": row_cleaned['DESCRIPTION'],
                        "location": row_cleaned['LOCATION'],
                        "embedding": model.embed_query(json.dumps(row_cleaned.tolist()))
                    })

                elif index == "rfcs":
                    row_cleaned = row.apply(lambda x: 0.0 if (pd.isna(x) or (isinstance(x, float) and np.isnan(x))) else x)
                    chunked_data.append({
                        "id": f"{row_cleaned['NUMBERPRGN']}",
                        "title": row_cleaned['NUMBERPRGN'],
                        "brief_description": row_cleaned['BRIEF_DESCRIPTION'],
                        "embedding": model.embed_query(json.dumps(row_cleaned.tolist()))
                    })

                elif index == "problems":
                    row_cleaned = row.apply(lambda x: 0.0 if (pd.isna(x) or (isinstance(x, float) and np.isnan(x))) else x)
                    chunked_data.append({
                        "id": f"{row_cleaned['ID']}",
                        "title": row_cleaned['ID'],
                        "brief_description": row_cleaned['BRIEF_DESCRIPTION'],
                        "embedding": model.embed_query(json.dumps(row_cleaned.tolist()))
                    })

                elif index == "problems_tasks":
                    row_cleaned = row.apply(lambda x: 0.0 if (pd.isna(x) or (isinstance(x, float) and np.isnan(x))) else x)
                    chunked_data.append({
                        "id": f"{row_cleaned['ID']}",
                        "title": row_cleaned['ID'],
                        "brief_description": row_cleaned['BRIEF_DESCRIPTION'],
                        "parent_problem":row_cleaned['PARENT_PROBLEM'],
                        "embedding": model.embed_query(json.dumps(row_cleaned.tolist()))
                    })

                elif index == "incidnt":
                    print("incidents is ingesting")
                    row_cleaned = row.apply(lambda x: 0.0 if (pd.isna(x) or (isinstance(x, float) and np.isnan(x))) else x)
                    chunked_data.append({
                        "id": f"{row_cleaned['NUMBERPRGN']}",
                        "title": row_cleaned['NUMBERPRGN'],
                        "brief_description": row_cleaned['BRIEF_DESCRIPTION'],
                        "network_name":row_cleaned['NETWORK_NAME'],
                        "location": row_cleaned['LOCATION'],
                        "logical_name": row_cleaned['LOGICAL_NAME'],
                        "embedding": model.embed_query(json.dumps(row_cleaned.tolist()))
                    })

                elif index == "events": 
                    row_cleaned = row.apply(lambda x: 0.0 if (pd.isna(x) or (isinstance(x, float) and np.isnan(x))) else x)
                    chunked_data.append({
                        "id": f"{row_cleaned['EVENT_ID']}",
                        "title": row_cleaned['EVENT_ID'],
                        "event_title": row_cleaned['EVENT_TITLE'], 
                        "config_item_id": row_cleaned['CONFIG_ITEM_ID'],
                        "description": row_cleaned['DESCRIPTION'], 
                        "location": row_cleaned['LOCATION'],
                        "embedding": model.embed_query(json.dumps(row_cleaned.tolist()))
                    })
                else:
                    print("Nothing is there to select to ingest.")

            print(f"Ingesting batch {start_idx // batch_size + 1} into OpenSearch...")

            # Step 4: Insert Chunked Data into OpenSearch in Batches
            # for item in tqdm(chunked_data, desc="Inserting Documents"):
            for item in chunked_data:  
                response = requests.post(
                    f"{opensearch_host}/{index_name}/_doc",
                    headers=headers,
                    data=json.dumps(item),
                    auth=auth
                )
                print(f"Insertion status code {response.status_code}")
                if response.status_code != 201:
                    print(f"Failed to insert document {item['id']}: {response.json()}")
                    break

            chunked_data = []  # Clear the batch to save memory

def get_index_name(filename):
    """
    Return a string based on the filename.
    If the filename contains specific substrings, return 'embeddings_<substring>'.
    """
    substrings = ["incident", "rfcs", "cis", "problems_tasks", "problems", "events"]
    for substring in substrings:
        if substring in filename.lower():  # Check case-insensitive match
            if substring == "incident":
                substring = "incidnt"
            return f"epsone_{substring}" , substring
    return "unknown" , "unknown" 

def ingest_file_sync(bucket_name, folder_name, file_name, indexes, indexes_lock, processed_files, processed_lock):
    thread_name = current_thread().name  # Get the current thread's name
    print(f"Thread {thread_name} is processing file: {file_name}")
    index_name, index = get_index_name(file_name)

    with processed_lock: 
        if file_name in processed_files:
            print(f"File {file_name} already processed. Skipping.")
            return {"status": "Skipped", "file_name": file_name}

        processed_files.add(file_name)  

    if index_name == "unknown":
        return {"status": "Failued",
                    "message": "Index name creation failed"}
    with indexes_lock:
        if index_name not in indexes:
            initialise_index(index_name, index)
            indexes.append(index_name)
    print("-----indexes-------")
    print(indexes, index_name)
    process_and_ingest_file(bucket_name,folder_name, file_name, index_name, index)
    s3_client = boto3.Session(region_name='us-east-1').client('s3')
    object_key = f"{folder_name}{file_name}"
    print(object_key)
    s3_client.delete_object(Bucket=bucket_name, Key=object_key)
    return {"status": "Success", "file_name": file_name}


async def ingest_documents_task(request):
    try:
        indexes = []
        processed_files = set() 
        processed_lock = Lock()
        indexes_lock = Lock() 
        file_names = list_files_in_folder(request.bucket_name, request.folder_name)

        # filtered_file_names = [
        #      file_name for file_name in file_names 
        #      if 'incidents/' in file_name]
        
        # file_names = filtered_file_names

        print(file_names)

        max_workers = min(24, os.cpu_count() * 2)

        # Find matching files in the list of files
        # matching_files = [file for file in file_names if file in target_files]

        # Process the matching files
        if file_names:
            print("Processing the following files:", file_names)

            # Use ThreadPoolExecutor for parallel processing
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                results = list(executor.map(
                    lambda file_name: ingest_file_sync(request.bucket_name, request.folder_name, file_name, indexes, indexes_lock, processed_files, processed_lock),
                    file_names
                ))

            print("Ingestion results:", "results")

        else:
            print("No matching files found to process.")

        logger.info("Ingestion complete")
        return {"status": "success"}

    except Exception as e:
        logger.error("An error occurred during ingestion: %s", e)
        raise HTTPException(
            status_code=500, 
            detail="Internal Server Error during ingestion"
        )
    


@ingest_router.post("/api/trigger-ingestion")
async def trigger_ingestion(request: IngestionRequest, background_tasks: BackgroundTasks):
    """
    Trigger the document ingestion task and schedule it every 15 minutes.
    """
    # Schedule the task to run immediately
    background_tasks.add_task(ingest_documents_task, request)

    if request.schedule.lower() == "true":
        print("Started scheduler")
        def run_async_task():
            asyncio.run(ingest_documents_task(request))

        scheduler.add_job(
            run_async_task,  # Call the wrapper function
            trigger=IntervalTrigger(minutes=15),
            id="ingest_documents_job",
            replace_existing=True
        )
        # Schedule it every 15 minutes
    #     scheduler.add_job(
    #         ingest_documents_task, 
    #         trigger=IntervalTrigger(minutes=15),
    #         id="ingest_documents_job",
    #         replace_existing=True,
    #         args=[request]  # Pass arguments properly
    # )
    return {"status": "scheduled", "message": "Ingestion task will run every 15 minutes."}
