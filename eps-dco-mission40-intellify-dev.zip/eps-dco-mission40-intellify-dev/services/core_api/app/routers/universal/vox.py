import backoff
import os
from dotenv import load_dotenv
import logging
from typing import Any, List, Mapping, Optional
#from pandas_summary import DataFrameSummary
from langchain.callbacks.manager import CallbackManagerForLLMRun
from langchain.llms.base import LLM
import httpx
import requests
import json
from langchain.embeddings.base import Embeddings
#from .pingfederate import generate_token

logger = logging.getLogger()
logger.setLevel(logging.INFO)

client = httpx.Client(timeout=120)

import boto3
from botocore.exceptions import ClientError
import requests, json
from datetime  import datetime


if os.getenv("vox_secret_name") is None:
    load_dotenv()

def get_secret():

    secret_name = os.getenv("vox_secret_name")
    region_name = "us-east-1"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        # For a list of exceptions thrown, see
        raise e

    secret = get_secret_value_response['SecretString']
    #a = get_secret_value_response['SecretString']['OpenAI']
    return secret

access_json = json.loads(get_secret())
print(access_json)
mulesoft_url = access_json['OpenAI_URL']
client_id = access_json['Client_ID']
client_secret = access_json['Client_Secret']
verification_url = access_json['verification_url']

# Raises Generic Openai Exception
class GenericException(Exception):
    pass

def generate_token():
    '''
    Generates the Bearer token needed for OpenAI API authentication. Returns the Bearer token as a string.
    '''
    try:
        url = f"{verification_url}"
        payload = f"client_id={client_id}&client_secret={client_secret}"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        response = requests.request("POST", url, headers=headers, data=payload)
        token = response.json()["access_token"]
        token_gen_time = datetime.now()
        return "Bearer " + token
 
    except Exception as e:
        return {
            "status": "error",
            "data": e,
            "message": e.orig.args if hasattr(e, "orig") else f"{e}",
        }


@backoff.on_exception(backoff.expo, GenericException, max_tries=20, max_time=60)
def ias_openai_embeddings(token: str, raw_text, engine: str):
    try:
        #url = os.getenv("IAS_EMBEDDINGS_URL")
        url = mulesoft_url + '/embeddings'


        payload = {"input": raw_text, "engine": engine}
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": token
        }
        logger.info("Calling IAS Embeddings API")
        response = client.post(url, headers=headers, json=payload)
        logger.info("Response from IAS Embeddings API")
        if response.status_code != 200:
            logger.error(
                f"Error calling IAS Embeddings API: {response.status_code}, {response.json()}"
            )
            raise Exception(
                f"Error calling IAS Embeddings API: {response.status_code}, {response.json()}"
            )

        embeddings = json.loads(response.json()["result"])
        logger.info("Embeddings created from IAS Embeddings API")
        return embeddings
    except Exception as e:
        logger.error(f"Exception calling IAS Embeddings API: {str(e)}")
        raise GenericException()



class IASOpenaiEmbeddings(Embeddings):
    """Wrapper for IAS secured OpenAI embedding API"""

    engine = str

    def __init__(self, engine):
        self.engine = engine

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embeddings search docs."""
        # NOTE: to keep things simple, we assume the list may contain texts longer
        #       than the maximum context and use length-safe embedding function.

        token = generate_token()
        response = ias_openai_embeddings(token, texts, self.engine)

        # Extract the embeddings
        embeddings: list[list[float]] = [data["embedding"] for data in response]
        return embeddings

    def embed_query(self, text: str) -> List[float]:
        """Embeddings  query text."""
        token = generate_token()
        response = ias_openai_embeddings(token, text, self.engine)

        # Extract the embeddings and total tokens
        embeddings: list[list[float]] = [data["embedding"] for data in response]
        return embeddings[0]



'''
embeddings = IASOpenaiEmbeddings(engine="text-embedding-ada-002")
result1 = embeddings.embed_query(text="Hi,I feeling sleep")
result2 = embeddings.embed_query(text="'addin 担当チームの皆様よろしくお願いいたします'")
print(result2)
result3 = embeddings.embed_query(text="Hi,I feeling drowzy")

import numpy as np

def cosine_sim(vec1,vec2):
    dot_product = np.dot(vec1,vec2)
    norm_vec1 = np.linalg.norm(vec1)
    norm_vec2 = np.linalg.norm(vec2)
    return dot_product/(norm_vec1*norm_vec2)


print("similarity between sleep and happy ",cosine_sim(result1,result2))
print("similarity between sleep and drowzy ",cosine_sim(result1,result3))
'''
