from fastapi import APIRouter,HTTPException
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse

import pandas as pd 
# import jaydebeapi
import os  
import re
import json
import boto3 
from botocore.exceptions import ClientError
from io import StringIO
from typing import Dict
from concurrent.futures import ThreadPoolExecutor
from database.database import connect_to_postgres

from routers.universal.search_open import knn_search


search_router = APIRouter()


def event_search(query, index_events, event_output_columns, limit, start_idx, page, advance_search=False, start_date=None, end_date=None):
    events_fields = [ "title",  "event_title", "config_item_id",  "description", "location"]
    # ['event_id','created_ts','event_title','severity','event_status']
    _events = knn_search(query, index_events, events_fields, 250)
    print("_events")
    print(_events)
    if _events != []:
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        events_list_ids = list(_events)
        placeholders = ', '.join(['%s'] * len(events_list_ids))

        # Base count query
        count_query = f"""
            SELECT COUNT(*) AS total_count
            FROM (
                SELECT event_id
                FROM dc1.events
                WHERE event_id IN ({','.join(['%s'] * len(events_list_ids))})
        """

        count_params = events_list_ids.copy()

        # Apply created_ts filter if adv_search is enabled
        if adv_search and start_date and end_date:
            count_query += " AND created_ts BETWEEN %s AND %s"
            count_params.extend([start_date, end_date])

        count_query += """
                GROUP BY event_id, event_title, created_ts, severity, event_status, description
            ) AS subquery;
        """

        cursor.execute(count_query, tuple(count_params))
        evt_total = cursor.fetchone()[0]

        # Base data query
        query_event = f"""
            SELECT event_id, event_title, created_ts, severity, event_status, description,
                CASE
                    WHEN COUNT(location) > 1 THEN 'Multiple'
                    ELSE MAX(location)
                END AS location,
                MAX(created_ts) AS created_ts
            FROM dc1.events
            WHERE event_id IN ({','.join(['%s'] * len(events_list_ids))})
        """

        query_params = events_list_ids.copy()

        # Apply created_ts filter if adv_search is enabled
        if adv_search and start_date and end_date:
            query_event += " AND created_ts BETWEEN %s AND %s"
            query_params.extend([start_date, end_date])

        query_event += """
            GROUP BY event_id, created_ts, event_title, severity, event_status, description
            ORDER BY MAX(created_ts) DESC
            LIMIT %s OFFSET %s;
        """

        query_params.extend([limit, start_idx])

        cursor.execute(query_event, tuple(query_params))
        event_rows = cursor.fetchall()
        event_column_names = [desc[0] for desc in cursor.description]
        evt_results = pd.DataFrame(event_rows,columns=event_column_names)
        evt_total_pages = int((evt_total + limit - 1) // limit)
        event_res = {
                "total_matches": evt_total,
                "current_page": int(page),
                "total_pages": evt_total_pages,
                "data": prepare_for_json(evt_results, event_output_columns)
            }
        cursor.close()
        conn.close()
    else:
        evt_total = 0
        event_res = {
                "total_matches": 0,
                "current_page": int(page),
                "total_pages": 0,
                "data": []
            }
    return evt_total, event_res

def incident_search(query, index_incidents, incident_output_columns, limit, start_idx, page, advance_search=False, start_date=None, end_date=None):
    incidenst_fields = ["title", "brief_description", "network_name", "location", "logical_name"]
    
    # [ 'numberprgn', 'brief_description', 'network_name', 'open_time', 'problem_status' ]
    _incidents = knn_search(query, index_incidents, incidenst_fields, 250)
    print("_incidents")
    print(_incidents)
    if _incidents != []:
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        incident_list_ids = list(_incidents)
        placeholders = ', '.join(['%s'] * len(incident_list_ids))

        # Base count query
        count_query = f"""
            WITH RankedIncidents AS (
                SELECT 
                    NUMBERPRGN,
                    BRIEF_DESCRIPTION,
                    NETWORK_NAME,
                    PROBLEM_STATUS,
                    LOCATION,
                    LOGICAL_NAME,
                    OPEN_TIME,
                    SYSMODTIME,
                    ROW_NUMBER() OVER (
                        PARTITION BY NUMBERPRGN
                        ORDER BY SYSMODTIME DESC
                    ) AS rn
                FROM dc1sm_ro.incidents
                WHERE NUMBERPRGN IN ({','.join(['%s'] * len(incident_list_ids))})
        """

        count_params = incident_list_ids.copy()

        # Apply time filter if adv_search is enabled
        if adv_search and start_date and end_date:
            count_query += " AND OPEN_TIME BETWEEN %s AND %s"
            count_params.extend([start_date, end_date])

        count_query += """
            )
            SELECT COUNT(*) AS total_count
            FROM RankedIncidents
            WHERE rn = 1;
        """

        cursor.execute(count_query, tuple(count_params))
        inc_total = cursor.fetchone()[0]
        
        # Base data query
        query_event = f"""
            WITH RankedIncidents AS (
                SELECT 
                    NUMBERPRGN,
                    BRIEF_DESCRIPTION,
                    NETWORK_NAME,
                    PROBLEM_STATUS,
                    LOCATION,
                    LOGICAL_NAME,
                    OPEN_TIME,
                    SYSMODTIME,
                    ROW_NUMBER() OVER (
                        PARTITION BY NUMBERPRGN
                        ORDER BY SYSMODTIME DESC
                    ) AS rn
                FROM dc1sm_ro.incidents
                WHERE NUMBERPRGN IN ({','.join(['%s'] * len(incident_list_ids))})
            """

        query_params = incident_list_ids.copy()

        # Apply OPEN_TIME filter if adv_search is enabled
        if adv_search and start_date and end_date:
            query_event += " AND OPEN_TIME BETWEEN %s AND %s"
            query_params.extend([start_date, end_date])

        query_event += """
            )
            SELECT 
                NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, 
                LOCATION, LOGICAL_NAME, SYSMODTIME, OPEN_TIME
            FROM RankedIncidents
            WHERE rn = 1
            ORDER BY OPEN_TIME DESC 
            LIMIT %s OFFSET %s;
        """

        query_params.extend([limit, start_idx])

        cursor.execute(query_event, tuple(query_params))
        incident_rows = cursor.fetchall()
        incident_column_names = [desc[0] for desc in cursor.description]
        print("incident_column_names")
        print(incident_column_names)
        inc_results = pd.DataFrame(incident_rows,columns=incident_column_names)
        print(inc_results.head(5))
        inc_total_pages = int((inc_total + limit - 1) // limit)

        incident_res = {
                "total_matches": inc_total,
                "current_page": int(page),
                "total_pages": inc_total_pages,
                "data": prepare_for_json(inc_results, incident_output_columns)
            }
        cursor.close()
        conn.close()
    else:
        inc_total = 0
        incident_res = {
                "total_matches": 0,
                "current_page": int(page),
                "total_pages": 0,
                "data": []
            }
        
    return inc_total, incident_res

def ci_search(query, index_cis, ci_output_columns, limit, start_idx, page, advance_search=False, start_date=None, end_date=None):
    ci_fields = ["title",  "network_name", "r_logical_name", "r_network_name", "pfz_application_name", "description", "location"] 
    # ['logical_name','network_name','r_logical_name','r_network_name','pfz_application_name','description']  
    _ci = knn_search(query, index_cis, ci_fields, 250)
    print(_ci)
    if _ci != []:
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        ci_list_ids = list(_ci)

        placeholders = ', '.join(['%s'] * len(ci_list_ids))

        # Base count query
        count_query = f"""
            SELECT COUNT(DISTINCT logical_name)
            FROM itsm_owner.cis
            WHERE logical_name IN ({','.join(['%s'] * len(ci_list_ids))})
        """

        count_params = ci_list_ids.copy()

        # Add date filter if adv_search is enabled
        if advance_search and start_date and end_date:
            count_query += " AND pfz_added_time BETWEEN %s AND %s"
            count_params.extend([start_date, end_date])

        cursor.execute(count_query, tuple(count_params))
        ci_total = cursor.fetchone()[0]

        # Base data query
        query_event = f"""
            SELECT DISTINCT logical_name, network_name, r_logical_name, 
                            r_network_name, pfz_application_name, description, 
                            pfz_added_time, location
            FROM itsm_owner.cis
            WHERE logical_name IN ({','.join(['%s'] * len(ci_list_ids))})
        """

        query_params = ci_list_ids.copy()

        # Add date filter if adv_search is enabled
        if advance_search and start_date and end_date:
            query_event += " AND pfz_added_time BETWEEN %s AND %s"
            query_params.extend([start_date, end_date])

        query_event += " ORDER BY pfz_added_time DESC LIMIT %s OFFSET %s"
        query_params.extend([limit, start_idx])

        cursor.execute(query_event, tuple(query_params))
        ci_rows = cursor.fetchall()
        ci_column_names = [desc[0] for desc in cursor.description]
        ci_results = pd.DataFrame(ci_rows,columns=ci_column_names)
        ci_total_pages = int((ci_total + limit - 1) // limit)

        ci_res = {
                "total_matches": ci_total,
                "current_page": int(page),
                "total_pages": ci_total_pages,
                "data": prepare_for_json(ci_results, ci_output_columns)
            }
        
        cursor.close()
        conn.close()
    else:
        ci_total = 0
        ci_res = {
                "total_matches": 0,
                "current_page": int(page),
                "total_pages": 0,
                "data": []
            }
        
    return ci_total, ci_res

def adv_search(location, assignment, c_type, start_date, end_date, incident_output_columns, limit, start_idx, page):
    conn = connect_to_postgres({})
    cursor = conn.cursor()

    location = f"%{location.lower()}%" if location else "%"
    assignment = f"%{assignment.lower()}%" if assignment else "%"
    c_type = f"%{c_type.lower()}%" if c_type else "%"

    # SQL Query
    base_query = """
            SELECT
                i.numberprgn,
                i.brief_description,
                i.description,
                i.location,
                i.status,
                i.open_time,
                i.priority,
                i.assignment,
                c.type AS ci_type,
                i.network_name,  
                i.problem_status, 
                i.logical_name  
            FROM
                dc1sm_ro.incidents i
            JOIN
                itsm_owner.cis c ON i.logical_name::TEXT = c.logical_name::TEXT
            WHERE 1=1
                    """

    count_query = "SELECT COUNT(*) FROM dc1sm_ro.incidents i JOIN itsm_owner.cis c ON i.logical_name::TEXT = c.logical_name::TEXT WHERE 1=1"

    # Parameters list
    params = []

    # **Dynamically Add Filters Based on Provided Parameters**
    if assignment:
        base_query += " AND LOWER(i.assignment) LIKE LOWER(%s)"
        count_query += " AND LOWER(i.assignment) LIKE LOWER(%s)"
        params.append(f"%{assignment.lower()}%")

    if c_type:
        base_query += " AND LOWER(c.type) LIKE LOWER(%s)"
        count_query += " AND LOWER(c.type) LIKE LOWER(%s)"
        params.append(f"%{c_type.lower()}%")

    if location:
        base_query += " AND LOWER(i.location) LIKE LOWER(%s)"
        count_query += " AND LOWER(i.location) LIKE LOWER(%s)"
        params.append(f"%{location.lower()}%")

    if start_date and end_date:
        base_query += " AND i.open_time BETWEEN %s AND %s"
        count_query += " AND i.open_time BETWEEN %s AND %s"
        params.extend([start_date, end_date])
    elif start_date:
        base_query += " AND i.open_time >= %s"
        count_query += " AND i.open_time >= %s"
        params.append(start_date)
    elif end_date:
        base_query += " AND i.open_time <= %s"
        count_query += " AND i.open_time <= %s"
        params.append(end_date)


        
    cursor.execute(count_query, tuple(params))
    adv_inc_total = cursor.fetchone()[0]

    # Add pagination
    base_query += " LIMIT %s OFFSET %s"
    params.extend([limit, start_idx])

    print("----1---")

    print(base_query)

    cursor.execute(base_query, tuple(params))
    print("----1---")
    
    
    adv_incident_rows = cursor.fetchall()
    adv_incident_column_names = [desc[0] for desc in cursor.description]
    df_adv_incidents = pd.DataFrame(adv_incident_rows, columns=adv_incident_column_names)

    adv_total_pages = int((adv_inc_total + limit - 1) // limit)

    print("df_adv_incidents")
    print(df_adv_incidents)

    # Close connection
    cursor.close()
    conn.close()

    adv_res = {
    "total_matches": adv_inc_total,
    "current_page": int(page),
    "total_pages": adv_total_pages,
    "data": prepare_for_json(df_adv_incidents, incident_output_columns)}

    return  adv_inc_total, adv_res

def prepare_for_json(df, output_columns):
    df = df[output_columns].astype(str)
    df.columns=[col.lower() for col in df.columns]
    return df.to_dict(orient="records")

def get_secret():

    secret_name =os.getenv('opensearch_index',"") 
    region_name = "us-east-1"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        # For a list of exceptions thrown, see
        raise e

    secret = get_secret_value_response['SecretString']
    return secret


@search_router.get(path="/api/UniversalSearch")
def universal_search(
    query: str = Query(..., description="Universal search across Incidents, Events, and CI records"),
    limit: int = Query(default=10, description="Maximum number of results per type", ge=1),
    page: int = Query(default=1, description="Page number", ge=1),
    query_type: str = Query(default=None, description="Filter results by type: event_list, incident_list, ci_list or advance_list"),
    advance_search: bool = Query(default=False, description="Enable advanced search"),
    location: str = Query(default=None, description="Specify the location"),
    assignment: str = Query(default=None, description="Specify the assignment"),
    c_type: str = Query(default=None, description="Specify the type of CI or event"),
    start_date: str = Query(default=None, description="Start date for open_time filter (YYYY-MM-DD)"),
    end_date: str = Query(default=None, description="End date for open_time filter (YYYY-MM-DD)")
):
    
    data=json.loads(get_secret())
    index_events = data['index_events']
    index_incidents = data["index_incidents"]
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",data)
    index_cis =  data["index_cis"]
    # Define search columns for each type
    EVENT_OUTPUT_COLUMNS = ['event_id','created_ts','event_title','severity','event_status', 'description', 'location']  
    INCIDENT_OUTPUT_COLUMNS = [ 'numberprgn', 'brief_description', 'network_name', 'open_time', 'problem_status', 'location', 'logical_name' ] 
    CI_OUTPUT_COLUMNS = ['logical_name','network_name','r_logical_name','r_network_name','pfz_application_name','description', 'location']  
   
    if not query:
        raise HTTPException(status_code=400, detail="No search query provided")

    
    try:
        def determine_search_type(search_query):
            upper_query = search_query.upper() 

            print("upper_query")
            print(upper_query)

            if re.match(r'^IM\d+$', upper_query):  
                return 'incident', upper_query
            elif re.match(r'^(CI|SC)\d+$', upper_query):  
                return 'ci', upper_query
            elif search_query[0].isdigit():
                return 'event', search_query  
            else:
                return 'universal', search_query 
        
        search_type, query = determine_search_type(query)
        start_idx = (page - 1) * limit
        
        search_metadata = {
            "search_query": query,
            "search_type": search_type,
            "pagination": {
                "current_page": int(page),
                "items_per_page": int(limit),
                "start_index": int(start_idx)
            }
        }

        # Handle exact matches
        if search_type == 'incident':
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(
                """WITH RankedIncidents AS (
                SELECT
                    NUMBERPRGN,
                    BRIEF_DESCRIPTION,
                    NETWORK_NAME,
                    PROBLEM_STATUS,
                    LOCATION,
                    LOGICAL_NAME,
                    OPEN_TIME,
                    ROW_NUMBER() OVER (PARTITION BY NUMBERPRGN ORDER BY UPDATE_TIME DESC) AS rn
                FROM
                        dc1sm_ro.incidents
                where numberprgn=%s
                )
                SELECT
                    NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, LOCATION, LOGICAL_NAME, OPEN_TIME
                FROM
                    RankedIncidents
                WHERE
                    rn = 1;""",
                (query,))

            incident_rows = cursor.fetchall()
            incident_column_names = [desc[0] for desc in cursor.description]
            df_incidents = pd.DataFrame(incident_rows,columns=incident_column_names)
            # if filtered_df.empty:
            #     raise HTTPException(status_code=404, detail="Incident not found")
            result = {
                "incident_list": {
                    "total_matches": 1,
                    "current_page": int(page),
                    "total_pages": 1,
                    "data": prepare_for_json(df_incidents, INCIDENT_OUTPUT_COLUMNS)
                }
            }
            cursor.close()
            conn.close()
            
        elif search_type == 'event':
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(
            """SELECT distinct event_id, event_title, created_ts, severity, event_status, severity, event_status, description, location
            FROM dc1.events
            WHERE event_id = %s ORDER BY created_ts DESC""",
            (query,))
            event_rows = cursor.fetchall()
            event_column_names = [desc[0] for desc in cursor.description]
            filtered_df = pd.DataFrame(event_rows,columns=event_column_names)
            #     raise HTTPException(status_code=404, detail="Event not found")
            result = {
                "event_list": {
                    "total_matches": 1,
                    "current_page": int(page),
                    "total_pages": 1,
                    "data": prepare_for_json(filtered_df[:1], EVENT_OUTPUT_COLUMNS)
                }
            }
            cursor.close()
            conn.close()

        elif search_type == 'ci':
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(
            """SELECT distinct logical_name,network_name,r_logical_name,r_network_name,pfz_application_name,description, pfz_added_time, location 
                FROM itsm_owner.cis
                WHERE logical_name  = %s ORDER BY pfz_added_time DESC""",
            (query,))
            ci_rows = cursor.fetchall()
            ci_column_names = [desc[0] for desc in cursor.description]
            filtered_df = pd.DataFrame(ci_rows,columns=ci_column_names)
            # if filtered_df.empty:
            #     raise HTTPException(status_code=404, detail="Event not found")
            result = {
                "ci_list": {
                    "total_matches": 1,
                    "current_page": int(page),
                    "total_pages": 1,
                    "data": prepare_for_json(filtered_df[:1], CI_OUTPUT_COLUMNS)
                }
            }

            # incident_list_ids = list(query)
            # placeholders = ', '.join(['%s'] * len(incident_list_ids))

            count_query = f"""
                        WITH RankedIncidents AS (
                        SELECT
                            NUMBERPRGN,
                            BRIEF_DESCRIPTION,
                            NETWORK_NAME,
                            PROBLEM_STATUS,
                            LOCATION,
                            LOGICAL_NAME,
                            OPEN_TIME,
                            SYSMODTIME,
                            ROW_NUMBER() OVER (
                                PARTITION BY NUMBERPRGN 
                                ORDER BY SYSMODTIME DESC
                            ) AS rn
                        FROM
                            dc1sm_ro.incidents
                        WHERE
                            logical_name = '{query}'
                    )
                    SELECT 
                        COUNT(*) AS record_count
                    FROM 
                        RankedIncidents
                    WHERE 
                        rn = 1;"""
            cursor.execute(count_query)
            inc_total = cursor.fetchone()[0]
            print("inc_total")
            print(inc_total)
            cursor.execute(
                """WITH RankedIncidents AS (
                    SELECT
                        NUMBERPRGN,
                        BRIEF_DESCRIPTION,
                        NETWORK_NAME,
                        PROBLEM_STATUS,
                        LOCATION,
                        LOGICAL_NAME,
                        OPEN_TIME,
                        SYSMODTIME,
                        ROW_NUMBER() OVER (
                            PARTITION BY NUMBERPRGN
                            ORDER BY SYSMODTIME DESC 
                        ) AS rn
                    FROM
                        dc1sm_ro.incidents
                    WHERE
                        logical_name = %s
                )
                SELECT 
                    NUMBERPRGN, 
                    BRIEF_DESCRIPTION, 
                    NETWORK_NAME, 
                    PROBLEM_STATUS, 
                    LOCATION, 
                    LOGICAL_NAME,
                    SYSMODTIME,
                    OPEN_TIME
                FROM
                    RankedIncidents
                WHERE
                    rn = 1 
                ORDER BY
                    SYSMODTIME DESC
                    LIMIT %s OFFSET %s;""",
                (query, limit, start_idx, ))
            
            incident_rows = cursor.fetchall()
            incident_column_names = [desc[0] for desc in cursor.description]
            df_incidents = pd.DataFrame(incident_rows,columns=incident_column_names)
            # if filtered_df.empty:
            #     raise HTTPException(status_code=404, detail="Incident not found")
            # if df_incidents != []
            result["incident_list"] = {
                    "total_matches": inc_total,
                    "current_page": int(page),
                    "total_pages": 1,
                    "data": prepare_for_json(df_incidents, INCIDENT_OUTPUT_COLUMNS)
                }
            cursor.close()
            conn.close()
            # _incidents_fields = [ "logical_name"]
            # # ['event_id','created_ts','event_title','severity','event_status']
            # inc_total, incident_res = incident_search(query, _incidents_fields, index_incidents, INCIDENT_OUTPUT_COLUMNS, conn, limit, start_idx, page, 10)
            # result["incident_list"] = incident_res
            
        else:  # Free text search
            print("query_type")
            print(query_type)

            if query_type == "":
                executor = ThreadPoolExecutor()

                # Schedule the tasks
                run_event = executor.submit(event_search, query, index_events, EVENT_OUTPUT_COLUMNS, limit, start_idx, page, advance_search, start_date, end_date)
                run_incident = executor.submit(incident_search,query, index_incidents, INCIDENT_OUTPUT_COLUMNS, limit, start_idx, page, advance_search, start_date, end_date)
                run_ci = executor.submit(ci_search,query, index_cis, CI_OUTPUT_COLUMNS, limit, start_idx, page, advance_search, start_date, end_date)

                if advance_search == True:
                    run_adv =  executor.submit(adv_search, location, assignment, c_type, start_date, end_date, INCIDENT_OUTPUT_COLUMNS, limit, start_idx, page)
                    

                # Wait for the results
                evt_total, event_res = run_event.result()
                inc_total, incident_res = run_incident.result()
                ci_total, ci_res = run_ci.result()
                if advance_search == True:
                    adv_total, adv_res = run_adv.result()

                # Shutdown the executor when done
                executor.shutdown()

                result = {
                    "event_list": event_res,
                    "incident_list":incident_res,
                    "ci_list": ci_res
                }

                if advance_search == True:
                    result["adv_list"] = adv_res

                
                
                
                total_matches = ci_total + inc_total + evt_total

            elif  query_type == "event_list":
                total_matches, event_res = event_search(query, index_events, EVENT_OUTPUT_COLUMNS, limit, start_idx, page, advance_search, start_date, end_date)
                result = {
                    "event_list": event_res
                }
            elif  query_type == "incident_list":
                total_matches, incident_res = incident_search(query, index_incidents, INCIDENT_OUTPUT_COLUMNS, limit, start_idx, page, advance_search, start_date, end_date)
                result = {
                    "incident_list": incident_res
                }
            elif  query_type == "ci_list":
                total_matches, ci_res = ci_search(query, index_cis, CI_OUTPUT_COLUMNS, limit, start_idx, page, advance_search, start_date, end_date)
                result = {
                    "ci_list": ci_res
                }
            elif  query_type == "advance_list":
                total_matches, adv_res =  adv_search(location, assignment, c_type, start_date, end_date, INCIDENT_OUTPUT_COLUMNS, limit, start_idx, page)
                result = {
                    "adv_list": adv_res
                }

                

            # if total_matches == 0:
            #     raise HTTPException(status_code=404, detail="No records found")
        
        response_data = {
            "metadata": search_metadata,
            "result": result,
            "total_matches": 1 if search_type in ['incident', 'event', 'ci'] else int(total_matches)
        }
        
        return JSONResponse(content=response_data)
    
    except ValueError as ve:
        error_response = {
            "status_code": 400,
            "message": "Invalid event ID format",
            "error": "Event ID must be a valid integer",
            "search_query": query,
            "detected_type": search_type
        }
        return JSONResponse(content=error_response, status_code=400)
    except HTTPException:
        raise
    except Exception as e:
        error_response = {
            "status_code": 400,
            "message": "Failed to return the filtered data",
            "error": repr(e),
            "search_query": query,
            "detected_type": search_type
        }
        return JSONResponse(content=error_response, status_code=400)
