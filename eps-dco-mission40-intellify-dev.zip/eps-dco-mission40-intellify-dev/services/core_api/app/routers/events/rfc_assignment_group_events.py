from fastapi import APIRouter,HTTPException
import boto3
from botocore.exceptions import ClientError
from typing import List,Dict
import psycopg2
import json
from pydantic import BaseModel
from schemas.schemas import EventFilterRequest,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.rfc_assignment_group import get_rfc_assignment_group

rfc_assignment_group_events = APIRouter()

@rfc_assignment_group_events.post("/get_rfc_assignment_group_data_events")
async def get_rfc_assignment_group_data_events(request: IncidentFilterRequest):
    try:
        event_id = int(request.numberprgn)
        rfc_filter = request.rfc_filter  # Get the rfc_filter value from the request


        # Fetch event details to get network_name
        query = """
        SELECT network_name,created_ts
        FROM dc1.events
        WHERE event_id = %s;
        """
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        cursor.execute(query, (event_id,))
        event = cursor.fetchone()
        cursor.close()
        conn.close()

        if not event:
            raise HTTPException(status_code=404, detail="Event not found.")

        network_name = event[0]
        open_time=event[1]

        # Fetch RFC assignment group data using the network_name and rfc_filter
        rfc_assignment_group_data = get_rfc_assignment_group(network_name, rfc_filter,open_time)
        rfc_assignment_group_data = [row for row in rfc_assignment_group_data if row['numberprgn'] != event_id]

        result = {
            "rfc_assignment_group": rfc_assignment_group_data,
        }

        # Return all combined data
        return {
            "message": "Successfully returned the  data",
            "data": result,
        }

    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }