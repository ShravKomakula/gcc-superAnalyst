
from fastapi import APIRouter,HTTPException
import boto3
from botocore.exceptions import ClientError
from typing import List,Dict,Optional
import psycopg2
import json
from pydantic import BaseModel
from schemas.schemas import EventFilterRequest,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.rfc_location import get_rfc_location



rfc_location_events = APIRouter()

@rfc_location_events.post("/get_all_rfc_location_events")
async def get_all_rfc_location_events(request: IncidentFilterRequest):
    try:
        print("request.numberprgn",type(request.numberprgn))
        event_id = int(request.numberprgn)
        print("event_id",event_id)
        rfc_filter = request.rfc_filter  # Get the rfc_filter value from the request


        # Fetch event details to get network_name
        query = """
        SELECT network_name,created_ts
        FROM dc1.events
        WHERE event_id = %s;
        """
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        cursor.execute(query, (event_id,))
        event = cursor.fetchone()
        cursor.close()
        conn.close()

        if not event:
            raise HTTPException(status_code=404, detail="Event not found.")

        network_name = event[0]
        open_time=event[1]
        print("************************************",network_name)
        print("8888888888888888888888888888888888888888888",open_time)

        # Fetch RFC location data using the network_name and rfc_filter
        rfc_location_data = get_rfc_location(network_name, rfc_filter,open_time)
        rfc_location_data = [row for row in rfc_location_data if row['numberprgn'] != event_id]

        result = {
            "rfc_location": rfc_location_data,
        }

        # Return all combined data
        return {
            "message": "Successfully returned the  data",
            "data": result,
        }

    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }