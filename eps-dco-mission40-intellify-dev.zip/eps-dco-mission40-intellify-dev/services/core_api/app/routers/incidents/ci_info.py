from fastapi import APIRouter, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List,Optional,Dict, List
from pydantic import BaseModel, Field
import boto3 
import psycopg2
import json
from botocore.exceptions import ClientError
import uvicorn 
from schemas.schemas import TestingIncident,IncidentRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.ci_info_utils import fetch_ci_info,get_ci_info,get_ci_relationships_or_dependencies,get_ci_upstream,get_related_data,fetch_incident,downstreams


ci_info =APIRouter()


# Endpoint to get CI details based on `numberprgn`
@ci_info.post("/get-ci-info")
async def get_ci_info(request: IncidentRequest):
    try:
        numberprgn = request.numberprgn
        # Fetch the incident to get the network_name
        incident = fetch_incident(numberprgn)
        if not incident:
            raise HTTPException(status_code=404, detail="Incident not found.")
        # Extract the network_name from the incident data
        network_name = incident[0]
        # Fetch CI information for the matched network_name
        ci_info = fetch_ci_info(network_name)
        primary_ci_contact = ci_info.get('ci_contacts', '').split(',')[0] if ci_info.get('ci_contacts') else None
        items = list(ci_info.items())
        items.insert(11, ('primary_ci_contact', primary_ci_contact))
        ci_info = dict(items)
        print("CI INFO::::::::::::::::::::________________________\n\n", ci_info)
        upstream = get_ci_upstream(network_name)
        infrastructure_dependencies = get_ci_relationships_or_dependencies(network_name)  # Assuming reuse for downstream
        downstream = downstreams(network_name)

        if not ci_info:
            raise HTTPException(status_code=404, detail="No CI information found for the given incident.")
        result = {"ci_info": ci_info,
            "upstream": upstream,
            "downstream": downstream,
            "infrastructure_dependencies":infrastructure_dependencies}
        return {"message": "Successfully returned the data",
                "data":result}
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }



@ci_info.post("/get_ci_info_ci")
async def get_ci_info_ci(request: IncidentRequest):
    try:
        # numberprgn = request.numberprgn
        # # Fetch the incident to get the network_name
        # incident = fetch_incident(numberprgn)
        # if not incident:
        #     raise HTTPException(status_code=404, detail="Incident not found.")
        # # Extract the network_name from the incident data
        network_name = request.numberprgn

        if not network_name:
            raise HTTPException(status_code=404, detail="Network name not found.")
        
        # Fetch CI information for the matched network_name
        ci_info = fetch_ci_info(network_name)
        primary_ci_contact = ci_info.get('ci_contacts', '').split(',')[0] if ci_info.get('ci_contacts') else None
        items = list(ci_info.items())
        items.insert(11, ('primary_ci_contact', primary_ci_contact))
        ci_info = dict(items)
        upstream = get_ci_upstream(network_name)
        infrastructure_dependencies = get_ci_relationships_or_dependencies(network_name)  # Assuming reuse for downstream
        downstream = downstreams(network_name)

        print("CI INFO AT LINE >>>  77 ::\n",ci_info)

        if not ci_info :
            raise HTTPException(status_code=404, detail="No CI information found for the given incident.")
        result = {"ci_info": ci_info,
            "upstream": upstream,
            "downstream": downstream,
            "infrastructure_dependencies":infrastructure_dependencies}
        return {"message": "Successfully returned the data",
                "data":result}
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }