from fastapi import APIRouter, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List,Optional,Dict, List
from pydantic import BaseModel, Field
import boto3 
import psycopg2
import json
from botocore.exceptions import ClientError
import uvicorn 
from schemas.schemas import TestingIncident,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.rfc_device_type import get_rfc_device_type



rfc_device_type = APIRouter()

@rfc_device_type.post("/get_all_rfc_device_type")
async def get_all_rfc_device_type_data(request: IncidentFilterRequest):
    try:
        numberprgn = request.numberprgn
        incident_filter = request.incident_filter  # Get the incident filter from the request
        rfc_filter = request.rfc_filter  # Get the RFC filter from the request

        # Fetch incident details to get network_name
        query = """
        SELECT product_type,open_time
        FROM dc1sm_ro.incidents
        WHERE numberprgn = %s;
        """
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        cursor.execute(query, (numberprgn,))
        incident = cursor.fetchone()
        cursor.close()
        conn.close()

        if not incident:
            raise HTTPException(status_code=404, detail="rfc not found.")

        rfc_type = incident[0]
        open_time=incident[1]
        
        print("open_time **********************************",open_time)

        # Fetch incident assignment group data with the incident filter applied
        rfc_device_type_data = get_rfc_device_type(rfc_type, rfc_filter,open_time)
        
        print("rfc_device_type_data",rfc_device_type_data)
        rfc_device_type_data = [row for row in rfc_device_type_data if row['numberprgn'] != numberprgn]

        result = {
            "rfc_device_type": rfc_device_type_data,
        }

        # Return all combined data
        return {
            "message": "Successfully returned the  data",
            "data": result,
        }
    
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }