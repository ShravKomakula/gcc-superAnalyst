from fastapi import APIRouter, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List,Optional,Dict, List
from pydantic import BaseModel, Field
import boto3 
import psycopg2
import json
from botocore.exceptions import ClientError
import uvicorn 
from schemas.schemas import TestingIncident,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.ci_info_utils_depend import fetch_ci_info,get_ci_info,get_ci_relationships_or_dependencies,get_ci_upstream,get_related_data,fetch_incident,downstreams


#ci_info =APIRouter()


# Endpoint to get CI details based on `numberprgn`
#@ci_info.post("/get-ci-info")
async def get_up_downstream(request: IncidentFilterRequest):
    try:
        numberprgn = request.numberprgn
        incident_filter = request.incident_filter
        rfc_filter = request.rfc_filter
        # Fetch the incident to get the network_name
        incident = fetch_incident(numberprgn)
        if not incident:
            raise HTTPException(status_code=404, detail="Incident not found.")
        # Extract the network_name from the incident data
        network_name = incident[0]
        # Fetch CI information for the matched network_name
        ci_info = fetch_ci_info(network_name)
        #print(ci_info)
        #upstream = get_ci_upstream(network_name)
        upstream_incidents,upstream_rfcs,downstreams_incidents,downstreams_rfcs = get_ci_relationships_or_dependencies(network_name,incident_filter,rfc_filter)  # Assuming reuse for downstream
        #downstream = downstreams(network_name)

        if not ci_info:
            raise HTTPException(status_code=404, detail="No CI information found for the given incident.")
        result = {"ci_info": ci_info,
            "upstream_incidents": upstream_incidents,
            "upstream_rfcs": upstream_rfcs,
            "downstreams_incidents":downstreams_incidents,
            "downstreams_rfcs":downstreams_rfcs}
        return {"message": "Successfully returned the data",
                "data":result}
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }



async def get_up_downstream_ci(request: IncidentFilterRequest):
    try:
        # numberprgn = request.numberprgn
        # incident_filter = request.incident_filter
        # rfc_filter = request.rfc_filter
        # # Fetch the incident to get the network_name
        # incident = fetch_incident(numberprgn)
        # if not incident:
        #     raise HTTPException(status_code=404, detail="Incident not found.")
        # # Extract the network_name from the incident data
        # network_name = incident[0]
        # # Fetch CI information for the matched network_name
        network_name=request.numberprgn
        ci_info = fetch_ci_info(network_name)
        #print(ci_info)
        #upstream = get_ci_upstream(network_name)
        upstream_incidents,upstream_rfcs,downstreams_incidents,downstreams_rfcs = get_ci_relationships_or_dependencies(network_name,incident_filter,rfc_filter)  # Assuming reuse for downstream
        #downstream = downstreams(network_name)

        if not ci_info:
            raise HTTPException(status_code=404, detail="No CI information found for the given incident.")
        result = {"ci_info": ci_info,
            "upstream_incidents": upstream_incidents,
            "upstream_rfcs": upstream_rfcs,
            "downstreams_incidents":downstreams_incidents,
            "downstreams_rfcs":downstreams_rfcs}
        return {"message": "Successfully returned the data",
                "data":result}
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }

