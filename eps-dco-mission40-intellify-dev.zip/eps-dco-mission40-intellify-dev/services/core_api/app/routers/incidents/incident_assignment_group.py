import traceback
from fastapi import APIRouter, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List,Optional,Dict, List
from pydantic import BaseModel, Field
import boto3 
import psycopg2
import json
from botocore.exceptions import ClientError
import uvicorn 
from schemas.schemas import TestingIncident,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.incident_assignment_group import get_incident_assignment_group



incident_assignment_group = APIRouter()

@incident_assignment_group.post("/get_all_incident_asignment_group_data")
async def get_all_incident_assignment_group_data(request: IncidentFilterRequest):
    numberprgn = request.numberprgn
    incident_filter = request.incident_filter
    rfc_filter = request.rfc_filter
    is_im = numberprgn.startswith("IM")
    print("numberprgn",numberprgn)
      
    if is_im:
        try:
            # Fetch incident details to get network_name
            query = """
            SELECT assignment,open_time,network_name
            FROM dc1sm_ro.incidents
            WHERE numberprgn = %s;
            """
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(query, (numberprgn,))
            incident = cursor.fetchone()
            cursor.close()
            conn.close()

            if not incident:
                raise HTTPException(status_code=404, detail="Incident not found.")

            assignment = incident[0]
            open_time=incident[1]
            network_name=incident[2]
            print("assignment ",assignment)

            # Fetch incident assignment group data with the incident filter applied
            incident_assignment_group_data = get_incident_assignment_group(assignment, incident_filter,open_time)
            incident_assignment_group_data = [row for row in incident_assignment_group_data if row['numberprgn'] != numberprgn]
            

            result = {
                "incident_assignment_group": incident_assignment_group_data,
            }

            # Return all combined data
            return {
                "message": "Successfully returned the  data",
                "data": result,
            }
        
        except Exception as e:
            error_trace = traceback.format_exc()  # Captures full stack trace
            print("Error Traceback:", error_trace)  # Prints full traceback to the console
            
            return {
                "status_code": 400,
                "message": "Error fetching data",
                "details": str(e),
                "traceback": error_trace  # Optional: Return traceback in response
            }

    else:
        try:
            event_id = int(request.numberprgn)
            incident_filter = request.incident_filter  # Get the incident_filter value from the request

            # Fetch incident details to get network_name
            query = """
            SELECT network_name,created_ts
            FROM dc1.events
            WHERE event_id = %s;
            """
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(query, (event_id,))
            incident = cursor.fetchone()
            cursor.close()
            conn.close()

            if not incident:
                raise HTTPException(status_code=404, detail="Incident not found.")

            network_name = incident[0]
            open_time = incident[1]

            # Fetch incident assignment group data using the network_name and incident_filter
            incident_assignment_group_data = get_incident_assignment_group(network_name, incident_filter,open_time)
            incident_assignment_group_data = [row for row in incident_assignment_group_data if row['numberprgn'] != event_id]

            result = {
                "incident_assignment_group": incident_assignment_group_data,
            }

            # Return all combined data
            return {
                "message": "Successfully returned the  data",
                "data": result,
            }

        except Exception as e:
            return {
                "status_code": 400,
                "message": "Error fetching data",
                "details": str(e)
            }



@incident_assignment_group.post("/incident_assignment_group_ci")
async def incident_assignment_group_ci(request: IncidentFilterRequest):
    try:
        numberprgn = request.numberprgn
        incident_filter = request.incident_filter  # Get the incident filter from the request
        rfc_filter = request.rfc_filter  # Get the RFC filter from the request
        

        # Fetch incident details to get network_name
        query = """
        SELECT assignment,open_time
        FROM dc1sm_ro.incidents
        WHERE numberprgn = %s;
        """
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        cursor.execute(query, (numberprgn,))
        incident = cursor.fetchone()
        cursor.close()
        conn.close()

        if not incident:
            raise HTTPException(status_code=404, detail="Incident not found.")

        assignment = incident[0]
        open_time=incident[1]

        # Fetch incident assignment group data with the incident filter applied
        incident_assignment_group_data = get_incident_assignment_group(assignment, incident_filter,open_time)

        result = {
            "incident_assignment_group": incident_assignment_group_data,
        }

        # Return all combined data
        return {
            "message": "Successfully returned the  data",
            "data": result,
        }
    
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }
