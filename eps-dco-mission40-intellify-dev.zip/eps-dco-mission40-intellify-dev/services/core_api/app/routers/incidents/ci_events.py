from fastapi import APIRouter,HTTPException
import boto3
from botocore.exceptions import ClientError
from typing import List,Dict
import psycopg2
import json
from pydantic import BaseModel
from schemas.schemas import TestingIncident,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.utils import get_days_hours
from utils.incidents.ci_based_incidents import get_ci_based_incidents




ci_events_inident=APIRouter()



@ci_events_inident.post("/get_ci_events")
async def get_all_events(request: IncidentFilterRequest):
    try:
        numberprgn = request.numberprgn
        incident_filter = request.incident_filter
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        # Fetch incident details to get network_name
        query = """
        SELECT logical_name,open_time
        FROM dc1sm_ro.incidents
        WHERE numberprgn = %s;
        """
        cursor.execute(query, (numberprgn,))
        incident = cursor.fetchone()
        
        print("incident",incident)


        if not incident:
            raise HTTPException(status_code=404, detail="Incident not found.")

        logical_name = incident[0]
        open_time = incident[1]
        
        print("open_time",open_time)
        
        if open_time:
            incident_cutoff_time_before,incident_cutoff_time_after=get_days_hours(incident_filter,open_time)
            print("incident_cutoff_time",incident_cutoff_time_before)
      
        event_query = f"""
            WITH Rankedevents AS (
                SELECT
                    event_id,event_title,created_ts,severity,event_status,
                    ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY created_ts DESC) AS rn
                FROM
                    dc1.events
                WHERE 
                    config_item_id = %s
                    {f"AND created_ts >= '{incident_cutoff_time_before}'  AND created_ts <= '{incident_cutoff_time_after}'" if incident_cutoff_time_before else ''}
            )
            SELECT
                event_id,event_title,created_ts,severity,event_status
            FROM
                Rankedevents
            WHERE
                rn = 1
            ORDER BY
                created_ts DESC;
            """
        cursor.execute(event_query, (logical_name,))
        events=cursor.fetchall()
        cursor.close()
        conn.close()
        result = {
            "events":events
        }
        return {
            "message": "Successfully returned the  data",
            "data": result,
        }

    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }


