from fastapi import APIRouter,HTTPException
import boto3
from botocore.exceptions import ClientError
from typing import List,Dict,Optional
import psycopg2
import json
from pydantic import BaseModel
from schemas.schemas import TestingIncident,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.rfc_assignment_group import get_rfc_assignment_group
from datetime import timedelta

rfc_assignment_group = APIRouter()

@rfc_assignment_group.post("/get_rfc_assignment_group_data")
async def get_rfc_assignment_group_data(request: IncidentFilterRequest):
    numberprgn = request.numberprgn
    incident_filter = request.incident_filter
    rfc_filter = request.rfc_filter
    is_im = numberprgn.startswith("IM")
      
    if is_im:
        try:
        
            # Fetch incident details to get network_name
            query = """
            SELECT network_name,open_time
            FROM dc1sm_ro.incidents
            WHERE numberprgn = %s;
            """
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(query, (numberprgn,))
            incident = cursor.fetchone()
            cursor.close()
            conn.close()

            if not incident:
                raise HTTPException(status_code=404, detail="Incident not found.")

            network_name = incident[0]
            open_time=incident[1]

            # Fetch RFC assignment group data with the rfc_filter applied
            rfc_assignment_group_data = get_rfc_assignment_group(network_name, rfc_filter,open_time)
            rfc_assignment_group_data = [row for row in rfc_assignment_group_data if row['numberprgn'] != numberprgn]
            

            result = {
                "rfc_assignment_group": rfc_assignment_group_data,
            }

            # Return all combined data
            return {
                "message": "Successfully returned the  data",
                "data": result,
            }

        except Exception as e:
            return {
                "status_code": 400,
                "message": "Error fetching data",
                "details": str(e)
            }
    else:
        try:
            event_id = int(request.numberprgn)
            rfc_filter = request.rfc_filter  # Get the rfc_filter value from the request


            # Fetch event details to get network_name
            query = """
            SELECT network_name,created_ts
            FROM dc1.events
            WHERE event_id = %s;
            """
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(query, (event_id,))
            event = cursor.fetchone()
            cursor.close()
            conn.close()

            if not event:
                raise HTTPException(status_code=404, detail="Event not found.")

            network_name = event[0]
            open_time=event[1]

            # Fetch RFC assignment group data using the network_name and rfc_filter
            rfc_assignment_group_data = get_rfc_assignment_group(network_name, rfc_filter,open_time)
            rfc_assignment_group_data = [row for row in rfc_assignment_group_data if row['numberprgn'] != event_id]

            result = {
                "rfc_assignment_group": rfc_assignment_group_data,
            }

            # Return all combined data
            return {
                "message": "Successfully returned the  data",
                "data": result,
            }

        except Exception as e:
            return {
                "status_code": 400,
                "message": "Error fetching data",
                "details": str(e)
            }



from datetime import datetime
@rfc_assignment_group.post("/rfc_assignment_group_ci")
async def rfc_assignment_group_ci(request: IncidentFilterRequest):
    try:
        network_name = request.numberprgn
        rfc_filter = request.rfc_filter  # Get the rfc_filter from the request
        open_time = datetime.now()


        # Fetch incident details to get network_name
        # query = """
        # SELECT distinct assignment,open_time
        # FROM dc1sm_ro.incidents
        # WHERE numberprgn = %s;
        # """
        # conn = connect_to_postgres({})
        # cursor = conn.cursor()
        # cursor.execute(query, (numberprgn,))
        # incident = cursor.fetchone()
        # cursor.close()
        # conn.close()

        # if not incident:
        #     raise HTTPException(status_code=404, detail="Incident not found.")

        # assignment = incident[0]
        # open_time=incident[1]

        # Fetch RFC assignment group data with the rfc_filter applied
        rfc_assignment_group_data = get_rfc_assignment_group(network_name, rfc_filter,open_time)

        result = {
            "rfc_assignment_group": rfc_assignment_group_data,
        }

        # Return all combined data
        return {
            "message": "Successfully returned the  data",
            "data": result,
        }

    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }