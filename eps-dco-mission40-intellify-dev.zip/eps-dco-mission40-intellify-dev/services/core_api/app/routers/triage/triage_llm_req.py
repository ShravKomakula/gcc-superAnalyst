import ast
import asyncio
import time,json
from schemas.schemas import IncidentFilterRequest,summaryApi,VoxData
from fastapi import APIRouter, HTTPException

from routers.incidents.incident_assignment_group import *
from routers.incidents.rfc_assignment_group import *
from routers.incidents.ci_events_prob_pt_apis import *
from routers.incidents.ci_based_incidents import *
from routers.incidents.ci_based_rfcs import *
from routers.incidents.get_incident_location import *
from routers.incidents.rfc_location import *
from routers.incidents.rfc_device_type import *
from routers.incidents.ci_info import get_ci_info as ci_information
from routers.incidents.ci_info_depend import get_up_downstream
from routers.incidents.incident_device_type import *
from utils.incidents.ci_based_incidents import *
from utils.prompts import *
from routers.events.ci_based_events import *
from routers.events.ci_based_rfcs_events import *
from routers.events.ci_events_prob_pt_apis_events import *
from routers.events.event_assignment_group import *
from routers.events.rfc_assignment_group_events import *
from routers.events.rfc_location_events import *
from routers.events.ci_info_events import *
from routers.events.get_events_location import *
from  routers.feedback.feedback import token_monitor
triage_llm_req = APIRouter()

@triage_llm_req.post("/llm_new_vox_location_api")
async def llm_new_vox_location_api(request: IncidentFilterRequest):
    start_time = time.time()  # Start timing the function
    
    try:
        numberprgn = request.numberprgn
        title = request.title
        is_im = numberprgn.startswith("IM")
        
        # Step 1: Fetch incident and RFC locations
        fetch_start = time.time()
        if is_im:
            incident_location = await get_all_incident_location(request)
            if 'status_code' in incident_location:
                incident_location=[]
            else:
                incident_location = incident_location['data']['incident_location'][:50]
            print("no of location records",incident_location)
            rfc_location = await get_all_rfc_location(request)
            if 'status_code' in rfc_location:
                rfc_location=[]
            else:
                rfc_location = rfc_location['data']['rfc_location'][:50]
            print("no of rfc_location",rfc_location)
        else:
            incident_location = await get_all_incident_location_events(request)
            if 'status_code' in incident_location:
                incident_location=[]
            else:
                incident_location = incident_location['data']['incident_location'][:50]

            rfc_location = await get_all_rfc_location_events(request)
            if 'status_code' in rfc_location:
                rfc_location=[]
            else:
                rfc_location = rfc_location['data']['rfc_location'][:50]
            print("no of rfc_location",rfc_location)

        fetch_end = time.time()
        
        
        # Step 2: Prepare the issue_location string
        issue_location = str({
            "issue": title,
            "data": {
                "Incidents_by_location": incident_location,
                "RFCs_by_location": rfc_location
            }
        })
        
        # Step 3: Call the LLM for correlation
        print("before llm call")
        llm_start = time.time()
        result_correlation = await asyncio.gather(
            llm_new_vox_location(issue=issue_location)
        )
        llm_end = time.time()
        
        # Step 4: Parse LLM response and construct output
        parse_start = time.time()
        vox_location_response = {}
        print("result_correlation",result_correlation)
        try:
            vox_location_response = ast.literal_eval(result_correlation[0][0])
        except (SyntaxError, ValueError) as e:
            print(f"Vox Location Error: {e}")
        
        response_data = {
            "title": title,
            "vox_location": list(vox_location_response.values()),
            "total_tokens": sum(item[1] for item in result_correlation),  # Token sum
        }
        parse_end = time.time()
        
        # Calculate and print timing details
        end_time = time.time()
        print(f"Step 1 (Fetch Data): {fetch_end - fetch_start:.4f}s")
        print(f"Step 2 (LLM Processing): {llm_end - llm_start:.4f}s")
        print(f"Step 3 (Parse Response): {parse_end - parse_start:.4f}s")
        print(f"Total Runtime: {end_time - start_time:.4f}s")
        
        return {
            "message": "Successfully returned the llm_new_vox_location_api data",
            "data": response_data,
            "execution_time": f"{end_time - start_time:.4f} seconds"
        }
    except Exception as e:
        print(f"Unexpected Error: {e}")
        raise HTTPException(status_code=500, detail="An unexpected error occurred. Please try again later.")       

@triage_llm_req.post("/llm_new_vox_app_server_api")
async def llm_new_vox_app_server_api(request: IncidentFilterRequest):
    start_time = time.time()  # Start timing the function

    try:
        numberprgn = request.numberprgn
        title = request.title
        is_im = numberprgn.startswith("IM")
        
        # Step 1: Fetch CI-based incidents and RFCs
        fetch_start = time.time()
        if is_im:
            ci_based_incident = await get_all_ci_based_incidents(request)
            if 'status_code' in ci_based_incident:
                ci_based_incident=[]
            else:
                ci_based_incident = ci_based_incident['data']['ci_based_incidents'][:50]
            ci_based_rfcs = await get_all_ci_based_rfcs(request)
            
            if 'status_code' in ci_based_rfcs:
                ci_based_rfcs=[]
            else:
                ci_based_rfcs = ci_based_rfcs['data']['ci_based_rfcs'][:50]
            print("no of ci_based_rfcs",ci_based_rfcs)
        else:
            ci_based_incident = await get_all_ci_based_incidents(request)
            if 'status_code' in ci_based_incident:
                ci_based_incident=[]
            else:
                ci_based_incident = ci_based_incident['data']['ci_based_incidents'][:50]
            ci_based_rfcs = await get_all_ci_based_rfcs_events(request)
            if 'status_code' in ci_based_rfcs:
                ci_based_rfcs=[]
            else:
                ci_based_rfcs = ci_based_rfcs['data']['ci_based_rfcs_events'][:50]
            print("no of ci_based_rfcs",ci_based_rfcs)
        fetch_end = time.time()
        

        # Step 2: Prepare the issue_app_server string
        issue_app_server = str({
            "issue": title,
            "data": {
                "Same_network_Incidents": ci_based_incident,
                "Same_network_RFCs": ci_based_rfcs
            }
        })
        
        # Step 3: Call the LLM for correlation
        llm_start = time.time()
        result_correlation = await asyncio.gather(
            llm_new_vox_app_server(issue=issue_app_server)
        )
        llm_end = time.time()
        
        # Step 4: Parse LLM response and construct output
        parse_start = time.time()
        vox_app_server_response = {}
        try:
            vox_app_server_response = ast.literal_eval(result_correlation[0][0])
        except (SyntaxError, ValueError) as e:
            print(f"Vox App Server Error: {e}")
        
        response_data = {
            "title": title,
            "vox_app_server": list(vox_app_server_response.values()),
            "total_tokens": sum(item[1] for item in result_correlation),  # Token sum
        }
        parse_end = time.time()
        
        # Calculate and log execution times
        end_time = time.time()
        print(f"Step 1 (Fetch Data): {fetch_end - fetch_start:.4f}s")
        print(f"Step 2 (LLM Processing): {llm_end - llm_start:.4f}s")
        print(f"Step 3 (Parse Response): {parse_end - parse_start:.4f}s")
        print(f"Total Runtime: {end_time - start_time:.4f}s")
        
        return {
            "message": "Successfully returned the llm_new_vox_app_server_api data",
            "data": response_data,
            "execution_time": f"{end_time - start_time:.4f} seconds"
        }

    except Exception as e:
        print(f"Unexpected Error: {e}")
        raise HTTPException(status_code=500, detail="An unexpected error occurred. Please try again later.")
   
   
@triage_llm_req.post("/llm_new_vox_assign_group_api")
async def llm_new_vox_assign_group_api(request: IncidentFilterRequest):
    start_time = time.time()  # Start timing the function

    try:
        numberprgn = request.numberprgn
        title = request.title
        is_im = numberprgn.startswith("IM")
        
        # Step 1: Fetch assignment group data
        fetch_start = time.time()
        if is_im:
            rfc_assignment_group = await get_rfc_assignment_group_data(request)
            if 'status_code' in rfc_assignment_group:
                rfc_assignment_group=[]
            else:
                rfc_assignment_group = rfc_assignment_group['data']['rfc_assignment_group'][:50]
            print("no of rfc_assignment_group",rfc_assignment_group)
            incident_assignment_group = await get_all_incident_assignment_group_data(request)
            if 'status_code' in incident_assignment_group:
                incident_assignment_group=[]
            else:
                incident_assignment_group = incident_assignment_group['data']['incident_assignment_group'][:50]
        else:
            rfc_assignment_group = await get_rfc_assignment_group_data_events(request)
            if 'status_code' in rfc_assignment_group:
                rfc_assignment_group=[]
            else:
                rfc_assignment_group = rfc_assignment_group['data']['rfc_assignment_group'][:50]
            print("-----------------------------------no of rfc_assignment_group",rfc_assignment_group)
            incident_assignment_group = await get_all_event_assignment_group_data(request)
            if 'status_code' in incident_assignment_group:
                incident_assignment_group=[]
            else:
                incident_assignment_group = incident_assignment_group['data']['incident_assignment_group'][:50]
            print("-----------------------------------no of incident_assignment_group",incident_assignment_group)
        fetch_end = time.time()

        # Step 2: Prepare the issue_assign_group string
        issue_assign_group = str({
            "issue": title,
            "data": {
                "Incidents_by_Assign_Group": incident_assignment_group,
                "RFCs_by_Assign_Group": rfc_assignment_group
            }
        })
        
        # Step 3: Call the LLM for correlation
        llm_start = time.time()
        result_correlation = await asyncio.gather(
            llm_new_vox_assign_group(issue=issue_assign_group),
        )
        llm_end = time.time()
        
        # Step 4: Parse LLM response and construct output
        parse_start = time.time()
        vox_assign_group_response = {}
        print("vox_assign_group_response",result_correlation[0][0])
        try:
            vox_assign_group_response = ast.literal_eval(result_correlation[0][0])
        except (SyntaxError, ValueError) as e:
            print(f"Vox Assign Group Error: {e}")
        
        response_data = {
            "title": title,
            "vox_assign_group": list(vox_assign_group_response.values()),
            "total_tokens": sum(item[1] for item in result_correlation),  # Token sum
        }
        parse_end = time.time()
        
        # Calculate and log execution times
        end_time = time.time()
        print(f"Step 1 (Fetch Data): {fetch_end - fetch_start:.4f}s")
        print(f"Step 2 (LLM Processing): {llm_end - llm_start:.4f}s")
        print(f"Step 3 (Parse Response): {parse_end - parse_start:.4f}s")
        print(f"Total Runtime: {end_time - start_time:.4f}s")
        
        return {
            "message": "Successfully returned the llm_new_vox_assign_group_api data",
            "data": response_data,
            "execution_time": f"{end_time - start_time:.4f} seconds"
        }

    except Exception as e:
        print(f"Unexpected Error: {e}")
        raise HTTPException(status_code=500, detail="An unexpected error occurred. Please try again later.")


@triage_llm_req.post("/llm_new_vox_device_type_api")
async def llm_new_vox_device_type_api(request: IncidentFilterRequest):
    start_time = time.time()  # Start timing the function

    try:
        numberprgn = request.numberprgn
        title = request.title
        is_im = numberprgn.startswith("IM")
        
        # Step 1: Fetch device type data
        fetch_start = time.time()
        if is_im:
            device_type_incident = await get_all_incident_device_type_data(request)
            print("********************* device_type_incident ******************",device_type_incident)
            if 'status_code' in device_type_incident:
                device_type_incident=[]
            elif len(device_type_incident['data']['incidents_data']) > 50 :
                device_type_incident = device_type_incident['data']['incidents_data'][:50]
            else:
                device_type_incident=device_type_incident['data']['incidents_data']
            print("no of device_type_incident",device_type_incident)
            device_type_rfc = await get_all_rfc_device_type_data(request)
            if 'status_code' in device_type_rfc:
                device_type_rfc=[]
            elif len( device_type_rfc['data']['rfc_device_type']) > 50 :
                device_type_rfc = device_type_rfc['data']['rfc_device_type'][:50]
            else:
                device_type_rfc = device_type_rfc['data']['rfc_device_type']
            print("no of device_type_rfc",device_type_rfc)
            
        else:
            device_type_incident = {}
            device_type_rfc = {}
        fetch_end = time.time()
        if 'status_code' in device_type_rfc:
            device_type_rfc={}
        if 'status_code' in device_type_incident:
            device_type_incident={}
        # Step 2: Prepare the issue_device_type string
        issue_device_type = str({
            "issue": title,
            "data": {
                "Incidents_by_Device_Type": device_type_incident,
                "RFCs_by_Device_Type": device_type_rfc
            }
        })

        # Step 3: Call the LLM for correlation
        llm_start = time.time()
        result_correlation = await asyncio.gather(
            llm_new_vox_device_type(issue=issue_device_type)
        )
        llm_end = time.time()

        # Step 4: Parse LLM response and construct output
        parse_start = time.time()
        vox_device_type_response = {}
        try:
            vox_device_type_response = ast.literal_eval(result_correlation[0][0])
        except (SyntaxError, ValueError) as e:
            print(f"Vox Device Type Error: {e}")
        
        response_data = {
            "title": title,
            "triage_llm": "",
            "vox_device_type": list(vox_device_type_response.values()),
            "total_tokens": sum(item[1] for item in result_correlation),  # Token sum
        }
        parse_end = time.time()

        # Log execution times
        end_time = time.time()
        print(f"Step 1 (Fetch Data): {fetch_end - fetch_start:.4f}s")
        print(f"Step 2 (LLM Processing): {llm_end - llm_start:.4f}s")
        print(f"Step 3 (Parse Response): {parse_end - parse_start:.4f}s")
        print(f"Total Runtime: {end_time - start_time:.4f}s")

        return {
            "message": "Successfully returned the llm_new_vox_device_type_api data",
            "data": response_data,
            "execution_time": f"{end_time - start_time:.4f} seconds"
        }

    except Exception as e:
        print(f"Unexpected Error: {e}")
        raise HTTPException(status_code=500, detail="An unexpected error occurred. Please try again later.")
         


@triage_llm_req.post("/llm_new_vox_up_downstream_api")
async def llm_new_vox_up_downstream_api(request: IncidentFilterRequest):
    start_time = time.time()  # Start tracking runtime

    try:
        numberprgn = request.numberprgn
        title = request.title
        is_im = numberprgn.startswith("IM")

        # Step 1: Fetch upstream and downstream data
        fetch_start = time.time()
        if is_im:
            ci_info_up_downstream = await get_up_downstream(request)
            print("ci_info_up_downstream",ci_info_up_downstream)
            ci_info_up_downstream_data = ci_info_up_downstream.get("data", {})
            ci_info = ci_info_up_downstream_data.get("ci_info", "NA")
            print("ci_info ci_info \n\n\n\n",ci_info)
            ci_name=ci_info.get("logical_name","NA")
            upstream_incidents = ci_info_up_downstream_data.get("upstream_incidents", "NA")
            for incident in upstream_incidents:
                incident["CI_NAME"] = ci_name
            
            upstream_rfcs = ci_info_up_downstream_data.get("upstream_rfcs", "NA")
            for incident in upstream_rfcs:
                incident["CI_NAME"] = ci_name
            print("111111")
            downstreams_incidents = ci_info_up_downstream_data.get("downstreams_incidents", "NA")
            for incident in downstreams_incidents:
                incident["CI_NAME"] = ci_name
            print("2222222222")
            downstreams_rfcs = ci_info_up_downstream_data.get("downstreams_rfcs", "NA")
            for incident in downstreams_rfcs:
                incident["CI_NAME"] = ci_name
            print("3333333333333333")
            
        else:
            ci_info = "NA"
            upstream_incidents = {}
            upstream_rfcs = {}
            downstreams_incidents = {}
            downstreams_rfcs = {}
        fetch_end = time.time()

        # Step 2: Prepare the issue_up_downstream string
        issue_up_downstream = str({
            "title": title,
            "data": {
                "upstream": {"Incidents": upstream_incidents, "RFCs": upstream_rfcs},
                "downstream": {"Incidents": downstreams_incidents, "RFCs": downstreams_rfcs}
            }
        })
        print("issue_up_downstream",issue_up_downstream)
        # Step 3: Call the LLM for correlation
        llm_start = time.time()
        result_correlation = await asyncio.gather(
            llm_new_vox_up_downstream(issue=issue_up_downstream)
        )
        llm_end = time.time()

        # Step 4: Parse LLM response
        parse_start = time.time()
        vox_up_downstream_response = []
        try:
            raw_response = ast.literal_eval(result_correlation[0][0])
            vox_up_downstream_response = [
                list(raw_response.values())[0],
                list(list(raw_response.values())[1].values())[0],
                list(list(raw_response.values())[1].values())[1],
                list(list(raw_response.values())[2].values())[0],
                list(list(raw_response.values())[2].values())[1],
            ]
        except (SyntaxError, ValueError, IndexError, KeyError) as e:
            print(f"Vox Up_Downstream Parsing Error: {e}")
        parse_end = time.time()

        # Step 5: Construct the API response
        response_data = {
            "title": title,
            "vox_up_downstream": vox_up_downstream_response,
            "total_tokens": sum(item[1] for item in result_correlation),  # Token sum
        }

        # Log execution times
        end_time = time.time()
        print(f"Step 1 (Fetch Data): {fetch_end - fetch_start:.4f}s")
        print(f"Step 2 (LLM Processing): {llm_end - llm_start:.4f}s")
        print(f"Step 3 (Parse Response): {parse_end - parse_start:.4f}s")
        print(f"Total Runtime: {end_time - start_time:.4f}s")

        return {
            "message": "Successfully returned the llm_new_vox_up_downstream_api data",
            "data": response_data,
            "execution_time": f"{end_time - start_time:.4f} seconds"
        }

    except Exception as e:
        print(f"Unexpected Error: {e}")
        raise HTTPException(status_code=500, detail="An unexpected error occurred. Please try again later.")

 


@triage_llm_req.post("/llm_new_vox_Events_api")
async def llm_new_vox_Events_api(request: IncidentFilterRequest):
    start_time = time.time()  # Record the start time

    try:
        numberprgn = request.numberprgn
        title = request.title
        is_im = numberprgn.startswith("IM")

        # Step 1: Fetch events data
        if is_im:
            ci_based_events = await get_all_others_data_events(request)
            print("ci_based_events ->>>>>>>>>>>>>>>>>>>>",ci_based_events)
            ci_based_events_data = ci_based_events.get("data", {})
            print("\n\n ci_based_events_data ->>>>>>>>>>>>>>>>>>>>",ci_based_events_data)
            
            ci_events = ci_based_events_data.get("ci_based_events", "NA")
            print("\n\n ci_events ->>>>>>>>>>>>>>>>>>>>",ci_events)
            
        else:
            ci_based_events = await get_all_others_data_events(request)
            ci_based_events_data = ci_based_events.get("data", {})
            ci_events = ci_based_events_data.get("ci_based_events", "NA")

        # Step 2: Prepare issue_events payload
        issue_events = str({
            "issue": title,
            "data": {"Events": ci_events}
        })
        
        print("**************** issue_events ",issue_events)

        # Step 3: Call LLM for correlation
        result_correlation = await asyncio.gather(
            llm_new_vox_Events(issue=issue_events)
        )

        # Step 4: Parse LLM response
        vox_events_response = {}
        try:
            raw_response = ast.literal_eval(result_correlation[0][0])
            vox_events_response = list(raw_response.values())
        except (SyntaxError, ValueError) as e:
            print(f"Vox Event Parsing Error: {e}")
            vox_events_response = []

        # Step 5: Construct response data
        total_time = time.time() - start_time  # Calculate total execution time
        response_data = {
            "title": title,
            "vox_events": vox_events_response,
            "total_tokens": sum(item[1] for item in result_correlation),  # Token sum
            "execution_time_seconds": round(total_time, 2),  # Total time in seconds
        }

        return {
            "message": "Successfully returned the llm_new_vox_Events_api data",
            "data": response_data
        }

    except Exception as e:
        print(f"Unexpected Error: {e}")
        raise HTTPException(status_code=500, detail="An unexpected error occurred. Please try again later.")
 

@triage_llm_req.post("/get_summary_data")
async def get_summary_data(request: VoxData):
    try:
        # Step 1: Start total execution timer
        total_start_time = time.time()

        # Step 2: Initialize and clean up inputs
        start_step_2 = time.time()
        vox_location = request.vox_location if len(request.vox_location) > 2 else []
        vox_events = request.vox_events if len(request.vox_events) > 1 else []
        vox_app_server = request.vox_app_server if len(request.vox_app_server) > 2 else []
        vox_assign_group = request.vox_assign_group if len(request.vox_assign_group) > 2 else []
        vox_up_downstream = request.vox_up_downstream if len(request.vox_up_downstream) > 4 else []
        vox_device_type = request.vox_device_type if len(request.vox_device_type) > 2 else []
        step_2_time = time.time() - start_step_2

        # Step 3: Construct the issue payload
        start_step_3 = time.time()
        issue = str({
            "issue": request.title,
            "data": {
                "vox_location": vox_location,
                "vox_events": vox_events,
                "vox_configuration_item": vox_app_server,
                "vox_assign_group": vox_assign_group,
                "vox_application_&_infrastructure": vox_up_downstream,
                "vox_device_type": vox_device_type,
            },
        })
        step_3_time = time.time() - start_step_3

        # Step 4: Gather results from async functions
        start_step_4 = time.time()
        result_summary = await asyncio.gather(
            llm_new_vox_prc_response(issue=issue),
            llm_new_vox_rca_response(issue=issue),
            llm_new_vox_summary(issue=issue),
        )
        step_4_time = time.time() - start_step_4

        # Step 5: Parse and process responses
        start_step_5 = time.time()
        vox_prc_response_sorted, vox_rca_response_, vox_sum_response = [], [], []

        try:
            vox_prc_response_sorted = sorted(
                ast.literal_eval(result_summary[0][0]),
                key=lambda x: x["likelihood"],
                reverse=True
            )
        except (SyntaxError, ValueError) as e:
            print(f"Vox PRC Error: {e}")

        try:
            vox_rca_response_ = result_summary[1][0].get("content", [])
        except (AttributeError, KeyError) as e:
            print(f"Vox RCA Error: {e}")

        try:
            vox_sum_response = result_summary[2][0].get("content", [])
        except (AttributeError, KeyError) as e:
            print(f"Vox Summary Error: {e}")

        step_5_time = time.time() - start_step_5
        incident_filter=request.incident_filter
        rfc_filter=request.rfc_filter
        token_request = {
            "id": request.numberprgn,
            "title": request.title,
            "incident_start_datetime":incident_filter.start_date,
            "incident_end_datetime":incident_filter.end_date,
            "rfc_start_datetime":rfc_filter.start_date,
            "rfc_end_datetime":rfc_filter.end_date,
            "token_count":sum(item[1] for item in result_summary) + request.total_tokens
        }
        print("token_request",token_request)
        token_save = await token_monitor(token_request)
        print("token_save",token_save)

        # Step 6: Construct the response
        start_step_6 = time.time()
        response_summary = {
            "vox_summary": vox_sum_response,
            "llm_rca": vox_rca_response_,
            "llm_prc": vox_prc_response_sorted,
            "total_tokens": sum(item[1] for item in result_summary) + request.total_tokens,  # Combined token sum
        }
        step_6_time = time.time() - start_step_6

        # Calculate total execution time
        total_execution_time = time.time() - total_start_time

        # Step 7: Return the response with execution times
        return {
            "message": "Successfully returned the data",
            "data": response_summary,
            "execution_times": {
                "input_cleanup_time": round(step_2_time, 2),
                "payload_construction_time": round(step_3_time, 2),
                "async_gather_time": round(step_4_time, 2),
                "response_processing_time": round(step_5_time, 2),
                "response_construction_time": round(step_6_time, 2),
                "total_execution_time": round(total_execution_time, 2),
            },
        }

    except Exception as e:
        print(f"Unexpected Error: {e}")
        raise HTTPException(status_code=500, detail="An unexpected error occurred. Please try again later.")
