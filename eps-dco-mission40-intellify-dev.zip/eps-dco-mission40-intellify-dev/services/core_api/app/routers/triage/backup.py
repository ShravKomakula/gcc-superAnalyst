
import ast
import asyncio
import time
from schemas.schemas import IncidentFilterRequest
from fastapi import APIRouter,HTTPException

from routers.incidents.incident_assignment_group import *
from routers.incidents.rfc_assignment_group import *
from routers.incidents.ci_events_prob_pt_apis import *
from routers.incidents.ci_based_incidents import *
from routers.incidents.ci_based_rfcs import *
from routers.incidents.get_incident_location import *
from routers.incidents.rfc_location import *
from utils.incidents.ci_based_incidents import *
from utils.prompts import *
from routers.events.ci_based_events import *
from routers.events.ci_based_rfcs_events import *
from routers.events.ci_events_prob_pt_apis_events import *
from routers.events.event_assignment_group import *
from routers.events.rfc_assignment_group_events import *
from routers.events.rfc_location_events import *
from routers.events.ci_info_events import *
from routers.events.get_events_location import *






triage_llm_req = APIRouter()


@triage_llm_req.post("/get_all_triage_llm")
async def triage_llm(request: IncidentFilterRequest):
    numberprgn = request.numberprgn
    incident_filter = request.incident_filter
    rfc_filter = request.rfc_filter
    title = request.title
    if numberprgn.startswith("IM"):
        incident_location=get_all_incident_location(request)
        rfc_location=get_all_rfc_location(request)
        rfc_assignment_group= get_rfc_assignment_group_data_events(request)
        incident_assignment_group=get_all_incident_assignment_group_data(request)
        ci_based_incident=get_all_ci_based_incidents(request)
        ci_based_rfcs=get_all_ci_based_rfcs(request)
        prab_pt_data=get_all_others_data(request)
        data=prab_pt_data.get('data')
        problems_tasks=data.get('problems_tasks',"NA")
        problems=data.get('problems',"NA")
        # Incident_type 
        #rfc_type
        #depenscie anf=d host server or upstrem and down stream
    else:
        incident_location=get_all_incident_location_events(request)
        rfc_location = get_all_rfc_location_events(request)
        rfc_assignment_group = get_rfc_assignment_group_data_events(request)
        incident_assignment_group=get_all_incident_assignment_group_data(request)
        ci_based_incident = get_all_ci_based_incidents(request)
        ci_based_rfcs = get_all_ci_based_rfcs_events(request)
        get_all_others_data_events=get_all_others_data_events(request)
        info_event=get_ci_info_events(request)
        event_assignment_group_data = get_all_event_assignment_group_data(request)
    
    
    # if ci.iloc[0]['TYPE'] == 'APPLICATION':

    # issue_device_type = str({"issue":title,"Incidents_by_type":incidents_by_type,"Rfcs_by_type":rfcs_by_type})

    #     issue_up_downstream = str({"issue":title,"upstream_data":hosted_data,"downstream_data":depend_app})

   
    # print("issue_location",issue_location)
    # issue_events = str({"issue":"title",
    #                     "data":{"Same_network_Events": get_erelated_data(network_name, filtered_events, ["event_id", "description", "created_time", "responsible_service_area", "event_title", "config_item_id", "network_name"]) + e_list}
    #                     })
    
    issue_location = str({"issue":title,
                    "data":{"Incidents_by_location": incident_location,
                            "RFCs_by_location":rfc_location,
            }})

    issue_app_server=str({"issue":title,
                            "data":{"Same_network_Incidents": ci_based_incident,
            "Same_network_RFCs":ci_based_rfcs}
            })

    issue_assign_group = str({"issue":title,
                                "data":{"Incidents_by_Assign_Group":rfc_assignment_group,
            "RFCs_by_Assign_Group": incident_assignment_group,
        }
                                })
        
    start = time.time()
    result_correlation = await asyncio.gather(llm_new_vox_location(issue=issue_location),
                    llm_new_vox_app_server(issue=issue_app_server),llm_new_vox_assign_group(issue=issue_assign_group),
                    # llm_new_vox_Events(issue=issue_events),
                    # llm_new_vox_up_downstream(issue=issue_up_downstream),llm_new_vox_device_type(issue=issue_device_type)
                    )
    end = time.time()
    print("--------------------------------------------execution time for correlation :",end-start)
    print("result_correlation",result_correlation)
    # correlation_token = result_correlation[0][1]+result_correlation[1][1]+result_correlation[2][1]+result_correlation[3][1]+result_correlation[4][1]+result_correlation[5][1]
    # print("correlation_token  :  ",correlation_token)
    # print("result_correlation: ",type(result_correlation))
        
    try:
        vox_location_response = ast.literal_eval(result_correlation[0][0]) #ast.literal_eval(vox_location(issue=issue_location))
        print("--------------------vox_location_response---------------------",vox_location_response)
    except Exception as e:
        print("exception for vox_location_response data : ", e)
        vox_location_response = {}
    #     try:    
    #         vox_Events_response= ast.literal_eval(result_correlation[1][0]) #ast.literal_eval(vox_Events(issue=issue_events))
    #         print("--------------------vox_Events_response---------------------",vox_Events_response)
    #     except Exception as e:
    #         print("exception for vox_Events_response data : ", e)
    #         vox_Events_response = {}
    try:
        vox_app_server_response= ast.literal_eval(result_correlation[2][0]) #ast.literal_eval(vox_app_server(issue=issue_app_server))
        print("--------------------vox_app_server_response---------------------",vox_app_server_response)
    except Exception as e:
        print("exception for vox_app_server_response data : ", e)
        vox_app_server_response = {}
    try:
        vox_assign_group_response= ast.literal_eval(result_correlation[3][0]) #ast.literal_eval(vox_assign_group(issue=issue_assign_group))
        print("--------------------vox_assign_group_response---------------------",vox_assign_group_response)
    except Exception as e:
        print("exception for vox_assign_group_response data : ", e)
        vox_assign_group_response = {} 
    #     try:
    #         vox_device_type_response = ast.literal_eval(result_correlation[5][0]) #ast.literal_eval(vox_up_downstream(issue=issue_up_downstream))
    #         print("--------------------vox_device_type_response---------------------",vox_device_type_response)
    #     except Exception as e:
    #         print("exception for vox_device_type_response data : ", e)
    #         vox_device_type_response = {}
    #     try:
    #         vox_up_downstream_response = ast.literal_eval(result_correlation[4][0]) #ast.literal_eval(vox_device_type(issue=issue_device_type))
    #         vox_up_downstream_response = [
    #                         list(vox_up_downstream_response.values())[0],
    #                         list(list(vox_up_downstream_response.values())[1].values())[0],
    #                         list(list(vox_up_downstream_response.values())[1].values())[1],
    #                         list(list(vox_up_downstream_response.values())[2].values())[0],
    #                         list(list(vox_up_downstream_response.values())[2].values())[1],

    #                     ]
    #         print("--------------------vox_up_downstream_response---------------------",vox_up_downstream_response)
    #     except Exception as e:
    #         print("exception for up_downstream data : ", e)
    #         vox_up_downstream_response = []
            
    #     #print("vox_device_type_response : ",vox_device_type_response)
    issue = str({"issue":title,
                            "data":{"vox_location": vox_location_response,
                            # "vox_events": vox_Events_response,
                            "vox_app_server": vox_app_server_response,
                            "vox_assign_group": vox_assign_group_response,
                            # "vox_up_downstream":vox_up_downstream_response,
                            # "vox_device_type":vox_device_type_response
        }})

    start_time = time.time()
    result_summ = await asyncio.gather(llm_new_vox_prc_response(issue=issue),llm_new_vox_rca_response(issue=issue),llm_new_vox_summary(issue=issue))
    end_time = time.time()
    print("-----------------------------------execution time for prc, rca, vox_summary:",end_time-start_time)
    summ_token = result_summ[0][1] + result_summ[1][1]+result_summ[2][1]
    print("summary token  :  ",summ_token)
    try:
        vox_prc_response_sorted = sorted(ast.literal_eval(result_summ[0][0]),key=lambda x:x["likelihood"],reverse=True)
        print("--------------------vox_prc_response---------------------",vox_prc_response_sorted)
    except Exception as e:
        print("exception for vox_prc_response_sorted data : ", e)
        vox_prc_response_sorted = {}
    try:
        vox_rca_response_ = result_summ[1][0]['content']
        print("--------------------vox_rca_response_---------------------",vox_rca_response_)
    except Exception as e:
        print("exception for vox_rca_response data : ", e)
        vox_rca_response_ = []
    try:
        vox_sum_response = result_summ[2][0]['content']
        print("--------------------vox_sum_response---------------------",vox_sum_response)
    except Exception as e:
        print("exception for vox_sum_response data : ", e)
        vox_sum_response = []
    response_data = {
                "llm_rca": vox_rca_response_,#vox_rca_response(issue=issue),
                "llm_prc": vox_prc_response_sorted,
                "vox_location": list(vox_location_response.values()),
                "vox_app_server": list(vox_app_server_response.values()),
                "vox_assign_group": list(vox_assign_group_response.values()),
                "vox_summary": vox_sum_response, #vox_summary(issue=issue),
            }
    
    print("\n\n\n\n\n\n\n\n")
    print("response_data ****************************************************",response_data)
       

    return {
            "message": "Successfully returned the data",
            "data": response_data
        }