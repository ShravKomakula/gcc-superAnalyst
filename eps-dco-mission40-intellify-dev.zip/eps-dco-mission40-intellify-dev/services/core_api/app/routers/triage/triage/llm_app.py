import os
import uuid
import boto3
import random
from datetime import datetime, timedelta
import chromadb
import requests
import pandas as pd
import json
import warnings
from botocore.exceptions import ClientError
from fastapi import FastAPI, HTTPException, Query
warnings.simplefilter(action="ignore", category=FutureWarning)
from termcolor import colored

 
#from database import connect_to_postgres,get_postgres_secrets
from database.database import connect_to_postgres,get_postgres_secrets

def generate_token():
    '''
    Generates the Bearer token needed for OpenAI API authentication. Returns the Bearer token as a string.
    '''
    try:
        url = f"{verification_url}"
        payload = f"client_id={client_id}&client_secret={client_secret}"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        response = requests.request("POST", url, headers=headers, data=payload)
        token = response.json()["access_token"]
        return "Bearer " + token
 
    except Exception as e:
        return {
            "status": "error",
            "data": e,
            "message": e.orig.args if hasattr(e, "orig") else f"{e}",
        }



def get_secret():

    secret_name =os.getenv('vox_secret_name',"") 
    
    region_name = "us-east-1"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        # For a list of exceptions thrown, see
        raise e

    secret = get_secret_value_response['SecretString']
    return secret

data=json.loads(get_secret())

endpointurl=data["OpenAI_URL"]
username = data["Client_ID"]
password = data["Client_Secret"]
verification_url=data['verification_url']





#To list config items
mulesoft_url = endpointurl
verification_url = verification_url
client_id = username
client_secret = password

def generate_token():
    '''
    Generates the Bearer token needed for OpenAI API authentication. Returns the Bearer token as a string.
    '''
    try:
        url = f"{verification_url}"
        payload = f"client_id={client_id}&client_secret={client_secret}"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        response = requests.request("POST", url, headers=headers, data=payload)
        token = response.json()["access_token"]
        return "Bearer " + token
    except Exception as e:
        return {
            "status": "error",
            "data": e,
            "message": e.orig.args if hasattr(e, "orig") else f"{e}",
        }


#Generate the token, valid for 30 min
#token = generate_token()

engine = "gpt-4-32k"
temperature=0.8
max_tokens=1000

url_chatCompletion = mulesoft_url + '/chatCompletion'
#headers = {"Authorization": token, "Content-Type": "application/json"}

import httpx

def llm_app_new_triage(data):

    print(data)
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages":[
            {"role": "system", "content": "You are a helpful IT support assistant that identifie the root cause and suggests Triage details"},
            {"role": "user", "content": data}
        ],
                "temperature":temperature,
                "max_tokens":max_tokens
            }

    text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
    print(text_response.json())
    result_json = json.loads(text_response.json()['result'])
    result = result_json['content']
    #print(result)
    totalTokens = text_response.json()['totalTokens']

    
    return result,totalTokens

def llm_app_vox_triage_response(data):
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages":[
            {"role": "system", "content": "You are a helpful IT support assistant that identifie the root cause and suggests resolution steps based on similar past tickets."},
            {"role": "user", "content": data}
        ],
                "temperature":temperature,
                "max_tokens":max_tokens
            }

    text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
    #print(text_response.json())
    result_json = json.loads(text_response.json()['result'])
    result = result_json['content']
    #print(result)
    totalTokens = text_response.json()['totalTokens']

    
    return result,totalTokens



def llm_app_vox_triage_response_i(data):
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages":[
            {"role": "system", "content": "You are a helpful IT support assistant that suggests resolution steps based on similar past tickets."},
            {"role": "user", "content": data}
        ],
                "temperature":temperature,
                "max_tokens":max_tokens
            }

    text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
    #print(text_response.json())
    result_json = json.loads(text_response.json()['result'])
    result = result_json['content']
    totalTokens = text_response.json()['totalTokens']

    
    return result,totalTokens


def llm_app_get_root_by_id_p(id):
    filtered_df = df[df['ID'] == id]
    if not filtered_df.empty:
        root_cause = filtered_df['ROOT_CAUSE'].values[0]
        #root_cause_updated = filtered_df['UPDATE_TXT'].values[0]
        root_cause_updated =""

        task_res = filtered_df['RESOLUTION'].values[0]
        workaround = filtered_df['WORKAROUND'].values[0]
        Proposed_solution = filtered_df['PROPOSED_SOLUTION'].values[0]

        # Format the texts
        root_cause_text = "root_cause: {}".format(root_cause if root_cause != 'nan' else '')

        root_cause_updated_text = "root_cause_updated: {}".format(root_cause_updated if root_cause_updated != 'nan' else '')

        workaround_text = "workaround: {}".format(workaround if workaround != 'nan' else '')
        task_res_text = "task_res: {}".format(task_res if task_res != 'nan' else '')
        Proposed_solution_text = "Proposed_solution: {}".format(Proposed_solution if Proposed_solution != 'nan' else '')

        texts = " ".join([root_cause_text, root_cause_updated_text,workaround_text, task_res_text,Proposed_solution_text])
        texts.replace("nan","")

        return texts
    else:
        return "No match found for given ID"
    

def llm_app_get_root_by_id_pt(id):

    filtered_df = df[df['ID'] == id]
    if not filtered_df.empty:
        root_cause = filtered_df['ROOT_CAUSE'].values[0]
        workaround = filtered_df['WORKAROUND'].values[0]
        task_res = filtered_df['TASK_RESOLUTION'].values[0]

        # Format the texts
        root_cause_text = "root_cause: {}".format(root_cause if root_cause != 'nan' else '')
        workaround_text = "workaround: {}".format(workaround if workaround != 'nan' else '')
        task_res_text = "task_res: {}".format(task_res if task_res != 'nan' else '')

        texts = " ".join([root_cause_text, workaround_text, task_res_text])
        texts.replace("nan","")

        return texts
    else:
        return "No match found for given ID"
    


# def get_stepstaken_by_id(df, id):

#     print("Inside the stepstaken by id:",df.columns.to_list())
#     texts = df[df['NUMBERPRGN'] == id]['INCIDENT_STEPS_TO_RESOLVE']
    
#     texts = [str(item) for item in texts if item is not None]
#     texts = " ".join(texts)
#     #print(texts)
#     return texts



def llm_app_get_stepstaken_by_id(id):
    conn = connect_to_postgres({})
    cursor = conn.cursor()

    query = """
        SELECT resolution
        FROM dc1sm_ro.incidents
        WHERE numberprgn = %s;
        """
    # query = """
    #         SELECT column_name 
    #         FROM information_schema.columns
    #         WHERE table_schema = 'dc1sm_ro'
    #         AND table_name = 'incidents'
    #         ORDER BY ordinal_position;
    #     """
    # # cursor.execute(query)
    # columns = cursor.fetchall()

    # for col in columns:

        # print("Incident col >>>>>>>>>>>>>>>>>>>>",col)
        
    

    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (id,))
    texts = cursor.fetchone()
    print("TEXTS-->>>>>>>>>>>>>>>>>",texts)

    cursor.close()
    conn.close()

    
    
    if not texts:
        texts=""

        print("Incident not founddd")


    #print("Inside the stepstaken by id:",df.columns.to_list())
    #texts = df[df['NUMBERPRGN'] == id]['RESOLUTION']
    
    texts = [str(item) for item in texts if item is not None]
    texts = " ".join(texts)
    #print(texts)
    return texts




def llm_app_get_note_by_id(id):
    query = """
        SELECT event_note
        FROM dc1.events
        WHERE event_id = %s;
        """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (id,))
    texts = cursor.fetchone()
    cursor.close()
    conn.close()

    if not texts:
        raise HTTPException(status_code=404, detail="Event not found.")

    #texts = df[df['event_id'] == id]['event_note']
    print("TEXTS::>>>>>>>>>>>>>>>>>>>>>>>>>",texts)
    print("EVENT ID FOUND>>>>>",id)
    
    texts = [str(item) for item in texts if item is not None]
    texts = " ".join(texts)

    #print(texts)
    return texts

