import traceback
from aiohttp import ClientError
from fastapi import APIRouter, HTTPException, Depends, Body
from utils.login.sso_utils import get_http_client
import httpx
from auth import *
import boto3    
import json   

import os
from dotenv import load_dotenv
 

login_router = APIRouter()

def get_secret():
    secret_name =os.getenv('login_credentials',"")
    region_name = "us-east-1"
    # Load environment variables from .env file if not already loaded

    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)

    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    except ClientError as e:
        raise e

    secret = get_secret_value_response['SecretString']
    return secret


def get_secret_sso():
    secret_name =os.getenv('sso_auth',"")
    print("secret_name ",secret_name)
    region_name = "us-east-1"
    # Load environment variables from .env file if not already loaded

    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)

    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    except ClientError as e:
        raise e

    secret = get_secret_value_response['SecretString']
    soo_auth_data=json.loads(secret)
    return soo_auth_data

# Define the route for checking email and password
@login_router.get("/login")
def check_email_password(email: str, password: str):
    try:
        # Fetch secrets
        secret = get_secret()
        secret_dict = json.loads(secret)

        # Validate email and password
        if email in secret_dict:
            is_valid = secret_dict[email] == password
            return is_valid
        else:
            return False
    except Exception as e:
        # Handle errors
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")
 
 
# @login_router.post("/token_oauth2")
# async def get_access_token(code: str = Body(..., embed=True), client: httpx.AsyncClient = Depends(get_http_client)):
#     if not code:
#         raise HTTPException(status_code=400, detail="Code is required")
        
#     try:
#         response = await client.post(
#             f"{ISSUER}token.oauth2?grant_type=authorization_code&redirect_uri={REDIRECT_URL}&response_type={RESPONSE_TYPE}&scope={SCOPE}&code={code}",
#             auth=(USERNAME, PASSWORD)
#         )
#         response.raise_for_status()
#         return {"message": "SSO request successful", "status": 200, "data": response.json()}
#     except httpx.HTTPStatusError as e:
#         raise HTTPException(status_code=400, detail=str(e))   
    
@login_router.post("/token_oauth2")
async def get_access_token(code: str = Body(..., embed=True), client: httpx.AsyncClient = Depends(get_http_client)):
    if not code:
        raise HTTPException(status_code=400, detail="Code is required")
        
    try:
        soo_auth_data=get_secret_sso()
        print("*********************",soo_auth_data)
        response = await client.post(
            f"{soo_auth_data.get('ISSUER')}token.oauth2?grant_type=authorization_code&redirect_uri={soo_auth_data.get('REDIRECT_URL')}&response_type={soo_auth_data.get('RESPONSE_TYPE')}&scope={soo_auth_data.get('SCOPE')}&code={code}",
            auth=(soo_auth_data.get('USERNAME'), soo_auth_data.get('PASSWORD'))
        )
        response.raise_for_status()
        return {"message": "SSO request successful", "status": 200, "data": response.json()}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))



# @login_router.post("/token_oauth2")
# async def get_access_token(
#     code: str = Body(..., embed=True), 
#     client: httpx.AsyncClient = Depends(get_http_client)
# ):
#     if not code:
#         raise HTTPException(status_code=400, detail="Authorization code is required")

#     try:
#         soo_auth_data = get_secret_sso()
#         print("soo_auth_data",soo_auth_data)
#         token_url = f"{soo_auth_data['ISSUER']}token.oauth2"
#         print("token_url",token_url)

#         headers = {
#             "Content-Type": "application/x-www-form-urlencoded"
#         }

#         data = {
#             "grant_type": "authorization_code",
#             "redirect_uri": soo_auth_data["REDIRECT_URL"],
#             "code": code  # Corrected: Using code directly
#         }

#         auth = (soo_auth_data["USERNAME"], soo_auth_data["PASSWORD"])
#         print("client.post(token_url, data=data, headers=headers, auth=auth)",client.post(token_url, data=data, headers=headers, auth=auth))

#         response = await client.post(token_url, data=data, headers=headers, auth=auth)
#         print("response",response.__dict__)
#         response.raise_for_status()  # Raise error if request fails

#         return {
#             "message": "SSO request successful",
#             "status": 200,
#             "data": response.json()
#         }
#     except httpx.HTTPStatusError as e:
#         error_trace = traceback.format_exc()
#         print("HTTPStatusError Traceback:\n", error_trace)
#         raise HTTPException(status_code=e.response.status_code, detail=f"OAuth2 Error: {e.response.text}")
    
#     except Exception as e:
#         error_trace = traceback.format_exc()  # Get full traceback
#         print("Unexpected Error Traceback:\n", error_trace)
#         raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")

@login_router.post("/validate_oauth2")
async def validate_token(token: str = Body(..., embed=True), client: httpx.AsyncClient = Depends(get_http_client)):
    if not token:
        raise HTTPException(status_code=400, detail="Token is required")

    try:
        soo_auth_data=get_secret_sso()
        response = await client.post(
            f"{soo_auth_data.get('ISSUER')}token.oauth2",
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            data={
                'client_id': soo_auth_data.get('USERNAME'), 
                'client_secret': soo_auth_data.get('PASSWORD'),
                'grant_type': 'urn:pingidentity.com:oauth2:grant_type:validate_bearer',
                'token': token
            }
        )
        response.raise_for_status()
        return {"message": "SSO request successful", "status": 200, "data": response.json()}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))

@login_router.post("/refresh_oauth2")
async def refresh_token(refresh_token: str = Body(..., embed=True), client: httpx.AsyncClient = Depends(get_http_client)):
    if not refresh_token:
        raise HTTPException(status_code=400, detail="Refresh Token is required")

    try:
        response = await client.post(
            f"{ISSUER}token.oauth2",
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            data={
                'client_id': USERNAME,
                'client_secret': PASSWORD,
                'refresh_token': refresh_token,
                'grant_type': 'refresh_token'
            }
        )
        response.raise_for_status()
        return {"message": "SSO request successful", "status": 200, "data": response.json()}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))

@login_router.post("/introspect_oauth2")
async def introspection_token(token: str = Body(..., embed=True), client: httpx.AsyncClient = Depends(get_http_client)):
    if not token:
        raise HTTPException(status_code=400, detail="Token is required")

    try:
        response = await client.post(
            f"{ISSUER}introspect.oauth2",
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            data={
                'client_id': USERNAME,
                'client_secret': PASSWORD,
                'token_type_hint': 'access_token',
                'token': token
            }
        )
        response.raise_for_status()
        return {"message": "SSO request successful", "status": 200, "data": response.json()}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))
