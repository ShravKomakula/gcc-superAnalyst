from langchain_chroma import Chroma
from .llm_app import llm_app_vox_triage_response, llm_app_get_root_by_id_p, llm_app_get_root_by_id_pt, llm_app_get_note_by_id, llm_app_get_stepstaken_by_id, llm_app_new_triage
import warnings
from fastapi.middleware.cors import CORSMiddleware
# from pgload import get_all_tables
import os
from fastapi import APIRouter,HTTPException
from pydantic import BaseModel
from fastapi import FastAPI, HTTPException, Query
from langchain_community.embeddings.sentence_transformer import SentenceTransformerEmbeddings
from typing import Optional, List, Dict, Any
import boto3
from botocore.exceptions import ClientError
from database.database import connect_to_postgres,get_postgres_secrets
import pandas as pd
import json
import re
import numpy as np
# from s3 import load_s3_folder_to_dfs
#from llm_app import llm_new_vox_triage_response, llm_new_load_s3_data_to_dfs, llm_new_vox_rca_response,llm_new_vox_prc_response, llm_new_vox_location,llm_new_vox_Events,llm_new_vox_app_server,llm_new_vox_assign_group,llm_new_vox_summary,llm_new_vox_up_downstream,llm_new_vox_device_type
import uvicorn
import pandas as pd
import numpy as np
# import boto3
import io
import logging
from typing import Any
import warnings
# from pgload import get_all_tables

from datetime import datetime, date,timedelta
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import json
import ast
import asyncio
import time
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi import Body
import httpx
from auth import *
import uvicorn

from .search_open import knn_search

# app = FastAPI()

# # CORS setup
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )
# warnings.simplefilter(action="ignore", category=FutureWarning)
# warnings.simplefilter(action="ignore", category=DeprecationWarning)

similarity = APIRouter()


# ----------------------------------------- sso ----------------------------------------


# Define a dependency for the httpx.AsyncClient
async def get_http_client():
    async with httpx.AsyncClient() as client:
        yield client

@similarity.post("/token_oauth2")
async def get_access_token(code: str = Body(..., embed=True), client: httpx.AsyncClient = Depends(get_http_client)):
    if not code:
        raise HTTPException(status_code=400, detail="Code is required")
        
    print(f"Code: {code}")
    print(f"ISSUER: {ISSUER}") 
    try:
        response = await client.post(
            f"{ISSUER}token.oauth2?grant_type=authorization_code&redirect_uri={REDIRECT_URL}&response_type={RESPONSE_TYPE}&scope={SCOPE}&code={code}",
            auth=(USERNAME, PASSWORD)
        )
        print(f"Code: {code}")
        response.raise_for_status()
        print(f"CodeAfters: {code}")
    
        return {"message": "SSO request successful", "status": 200, "data": response.json()}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))

@similarity.post("/validate_oauth2")
async def validate_token(token: str = Body(..., embed=True), client: httpx.AsyncClient = Depends(get_http_client)):
    if not token:
        raise HTTPException(status_code=400, detail="Token is required")

    try:
        response = await client.post(
            f"{ISSUER}token.oauth2",
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            data={
                'client_id': USERNAME,
                'client_secret': PASSWORD,
                'grant_type': 'urn:pingidentity.com:oauth2:grant_type:validate_bearer',
                'token': token
            }
        )
        response.raise_for_status()
        return {"message": "SSO request successful", "status": 200, "data": response.json()}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))

@similarity.post("/refresh_oauth2")
async def refresh_token(refresh_token: str = Body(..., embed=True), client: httpx.AsyncClient = Depends(get_http_client)):
    if not refresh_token:
        raise HTTPException(status_code=400, detail="Refresh Token is required")

    try:
        response = await client.post(
            f"{ISSUER}token.oauth2",
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            data={
                'client_id': USERNAME,
                'client_secret': PASSWORD,
                'refresh_token': refresh_token,
                'grant_type': 'refresh_token'
            }
        )
        response.raise_for_status()
        return {"message": "SSO request successful", "status": 200, "data": response.json()}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))

@similarity.post("/introspect_oauth2")
async def introspection_token(token: str = Body(..., embed=True), client: httpx.AsyncClient = Depends(get_http_client)):
    if not token:
        raise HTTPException(status_code=400, detail="Token is required")

    try:
        response = await client.post(
            f"{ISSUER}introspect.oauth2",
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            data={
                'client_id': USERNAME,
                'client_secret': PASSWORD,
                'token_type_hint': 'access_token',
                'token': token
            }
        )
        response.raise_for_status()
        return {"message": "SSO request successful", "status": 200, "data": response.json()}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))


# -------------------------------------- app old ----------------------------------------------------


BUCKET_NAME = 'gccsuperanalystdata'
FOLDERS = ['raw_19_11_2024/cmdb', 'raw_19_11_2024/dc1']

def process_dataframes(dataframes, rows=2000000):
    data = {}
    global ci_data

    for name, df in dataframes.items():
        print(name, "\n", df.columns)

        if name == 'incidents':
            df = df.drop_duplicates(subset='NUMBERPRGN', keep='first')
            #df['OPEN_TIME'] = pd.to_datetime(df['OPEN_TIME'], errors='coerce')

            df.fillna(" ", inplace=True)
            df = df.head(rows)
            data[name] = df

        elif name == 'rfc':
            df = df.drop_duplicates(subset='NUMBERPRGN', keep='first')
            df = df.head(rows)
            data[name] = df

        elif name == 'events':
            df = df.drop_duplicates(subset='event_title', keep='first')
            df.fillna(" ", inplace=True)
            df['created_ts'] = pd.to_datetime(df['created_ts'],errors='coerce')
            df = df.sort_values(by='created_ts', ascending=False)
            df = df.head(rows)
            data[name] = df

        elif name == 'ci':
            ci_data = df
            df.replace('', np.nan, inplace=True)
            df.fillna(value="None", inplace=True)
            df = df.head(rows)
            data[name] = df

        elif name == 'problems':
            #df = df.drop_duplicates(subset='ID', keep='first')
            df = df.head(rows)
            data[name] = df

        elif name == 'problem_tasks':
            #df = df.drop_duplicates(subset='ID', keep='first')
            df = df.head(rows)
            data[name] = df

        else:
            pass

    return data

#data = load_s3_folder_to_dfs(BUCKET_NAME, FOLDERS)
# unified_data=get_all_tables()
# data=unified_data
# print(data.keys())

# data = process_dataframes(data)

# print(data.keys())

# dc_events_df = data["events"]
# incidents_df = data["incidents"]
# print("INCIDENTS DATASET SHAPE",incidents_df.shape)
# problems_tasks_df = data["problem_tasks"]
# problems_df = data["problems"]
# rfc_df = data["rfc"]
# ci_df = data["ci"]


k_similarity_docs = 20
top_p = 0.5
temperature = 0.8
max_new_tokens = 6000
conv_ret_chain_vox= []


def get_secret():

    secret_name =os.getenv('opensearch_index',"") 
    region_name = "us-east-1"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
        
    except ClientError as e:
        # For a list of exceptions thrown, see
        raise e

    secret = get_secret_value_response['SecretString']
    print("Opennnnnnnnnnnnnnnnnnnnnnn",secret)
    
    return secret

data=json.loads(get_secret())
index_events = data['index_events']
index_incidents = data["index_incidents"]
index_rfcs =data["index_rfcs"]
index_problems = data["index_problems"]
index_problems_tasks = data["index_problems_tasks"]
 
    


def db(input_query: str, k: int = 10, site: Optional[str] = None) -> tuple:
    similar_events = []
    filter = {"LOCATION": site} if site else None
    # docs = search_with_fallback(db_events, input_query, k, filter)
    docs,event_scores = knn_search(input_query, index_events)

    print("Length of events before:", len(docs))

    # Filter out the event if it matches the input ID
    #filtered_docs = [ticket for ticket in docs if ticket[0].metadata.get('event_id') != int(tid)]

        
    filtered_docs = [
        ticket for ticket in docs if str(ticket) != str(tid)
    ]
    

    print("Length of events after:", len(filtered_docs))

    # Process the remaining documents
    for id in filtered_docs:
        text = llm_app_get_note_by_id(id)
        if not all(part == "nan" for part in text.split()):
            similar_events.append(text)

    print("event notes:---\n",similar_events)
    if len(similar_events)>0:

        suggested_steps = generate_suggested_steps(input_query, similar_events)
        return suggested_steps, filtered_docs,event_scores
  
    return "",filtered_docs,event_scores



def db_ic(input_query: str, k: int = 10, site: Optional[str] = None) -> tuple:
    similar_stepstaken = []
    filter = {"LOCATION": site} if site else None
    # docs = search_with_fallback(ic_db1, input_query, k, filter)
    docs,ic_scores = knn_search(input_query, index_incidents)

    print("Length of incidents before:", len(docs))

    # Filter out the incident if it matches the input ID
    filtered_docs = [ticket for ticket in docs if ticket != tid]

    print("Length of incidents after:", len(filtered_docs))

    # Process the remaining documents
    for id in filtered_docs:
        text = llm_app_get_stepstaken_by_id(id)
        if not all(part == "nan" for part in text.split()):
            similar_stepstaken.append(text)

    if len(similar_stepstaken)>0:

        suggested_steps = generate_suggested_steps_i(input_query, similar_stepstaken)
        return suggested_steps, filtered_docs,ic_scores

    

    return "", filtered_docs,ic_scores





def db_rfc(input_query: str, k: int = 10, site: Optional[str] = None) -> tuple:
    similar_stepstaken = []
    filter = {"LOCATION": site} if site else None

    # docs = search_with_fallback(rfc_db, input_query, k, filter)
    docs,rfc_scores = knn_search(input_query, index_rfcs)

    if len(docs)>0:
    
        for ic_id in docs:
            text = llm_app_get_stepstaken_by_id(ic_id)
            if not all(part == "nan" for part in text.split()):
                similar_stepstaken.append(text)
        
        suggested_steps = generate_suggested_steps_i(input_query, similar_stepstaken)
        return suggested_steps, docs,rfc_scores

    return "",docs,rfc_scores

def db_p(input_query: str, site: Optional[str] = None) -> tuple:
    steps = []
    filter = {"LOCATION": site} if site else None
    # docs = search_with_fallback(p_db, input_query, filter=filter)
    docs = knn_search(input_query, index_problems)
    
    for id in docs:
        text = llm_app_get_root_by_id_p(id)
        steps.append(text)

    if len(steps)>0:
    
        suggested_steps = generate_suggested_steps(input_query, steps)
        return suggested_steps, docs

    return '',docs

def db_pt(input_query: str, site: Optional[str] = None) -> tuple:
    steps = []
    filter = {"LOCATION": site} if site else None
    # docs = search_with_fallback(pt_db, input_query, filter=filter)
    docs = knn_search(input_query, index_problems_tasks)
    
    for id in docs:
        text = llm_app_get_root_by_id_pt(id)
        steps.append(text)
    if len(steps)>0:
   
        suggested_steps = generate_suggested_steps(input_query, steps)
        return suggested_steps, docs

    return "",docs
# def get_secret():
    # secret_name =os.getenv('login_credentials',"")

#     region_name = "us-east-1"

#     session = boto3.session.Session()
#     client = session.client(service_name='secretsmanager', region_name=region_name)

#     try:
#         get_secret_value_response = client.get_secret_value(SecretId=secret_name)
#     except ClientError as e:
#         raise e

#     secret = get_secret_value_response['SecretString']
#     return secret

# @app.get("/login")
# def check_email_password(email: str, password: str):
#     secret = get_secret()
#     secret_dict = json.loads(secret)

#     if email in secret_dict:
#         return secret_dict[email] == password
#     else:
#         return False

def format_response(similar_data):
    """
    Format response for frontend by querying database for incidents, events, and RFCs.
    
    Args:
        similar_data (dict): Dictionary containing lists of similar incidents, events, and RFCs.
            Expected format:
            {
                "similar_incidents": [str],  # List of incident numbers
                "similar_events": [str],     # List of event IDs
                "similar_rfc": [str]         # List of RFC numbers
            }
    
    Returns:
        dict: Formatted response with required columns for frontend.
            Format:
            {
                "incidents": [{"number": str, "resolution": str}],
                "events": [{"id": str, "description": str}],
                "rfc": [{"number": str, "summary": str}]
            }
    """
    formatted_response = {
        "incidents": [],
        "events": [],
        "rfcs": []
    }

    def fetch_data(data_type, query, data_key):
        """
        Helper function to fetch data from database and format results.
        
        Args:
            data_type (str): Type of data to fetch (similar_incidents, similar_events, similar_rfc)
            query (str): SQL query to execute
            data_key (str): Key in formatted_response to store results
        """
        if similar_data.get(data_type):
            conn = connect_to_postgres({})
            try:
                with conn.cursor() as cursor:
                    cursor.execute(query, (similar_data[data_type],))
                    results = cursor.fetchall()
                    
                    if data_key == "incidents":
                        #numberprgn, brief_description,status, cause_code, resolution, created_ts
                        formatted_response[data_key] = [
                            {"numberprgn": row[0], "brief_description": row[1],"status": row[2],"cause_code": row[3],"resolution": row[4],"created_ts": row[5]}
                            for row in results if row[0] is not None
                        ]
                    elif data_key == "events":
                        formatted_response[data_key] = [
                            {"event_id": row[0], "event_title": row[1],"issue_source": row[2], "severity": row[3],"event_status": row[4]}
                            #event_id, event_title, issue_source, severity, event_status
                            for row in results if row[0] is not None
                        ]
                    elif data_key == "rfcs":
                        formatted_response[data_key] = [
                            {"numberprgn": row[0],"approval_status":row[1],"brief_description":row[2],"planned_start":row[3],"planned_end":row[4]}
                            #numberprgn, type, approval_status, description, planned_start, planned_end
                            for row in results if row[0] is not None
                        ]
            finally:
                conn.close()

    # Query and format incidents
    incidents_query = """
        SELECT distinct numberprgn, brief_description,status, cause_code, resolution,open_time
        FROM dc1sm_ro.incidents 
        WHERE numberprgn = ANY(%s);
    """
    fetch_data("similar_incidents", incidents_query, "incidents")

    # Query and format events
    events_query = """
        SELECT distinct event_id, event_title, issue_source, severity, event_status
        FROM dc1.events 
        WHERE event_id = ANY(%s);
    """
    fetch_data("similar_events", events_query, "events")

    # Query and format RFCs
    rfc_query = """
        SELECT distinct numberprgn, approval_status, brief_description, planned_start, planned_end
        FROM dc1sm_ro.rfcs
        WHERE numberprgn = ANY(%s);
    """
    fetch_data("similar_rfc", rfc_query, "rfcs")

    return formatted_response

def remove_duplicates(formatted_response):
    # Remove duplicates from incidents based on numberprgn
    if "incidents" in formatted_response:
        seen_incidents = set()
        unique_incidents = []
        for incident in formatted_response["incidents"]:
            if incident["numberprgn"] not in seen_incidents:
                seen_incidents.add(incident["numberprgn"])
                unique_incidents.append(incident)
        formatted_response["incidents"] = unique_incidents

    # Remove duplicates from events based on event_id
    if "events" in formatted_response:
        seen_events = set()
        unique_events = []
        for event in formatted_response["events"]:
            if event["event_id"] not in seen_events:
                seen_events.add(event["event_id"])
                unique_events.append(event)
        formatted_response["events"] = unique_events

    # Remove duplicates from rfcs based on numberprgn
    if "rfcs" in formatted_response:
        seen_rfcs = set()
        unique_rfcs = []
        for rfc in formatted_response["rfcs"]:
            if rfc["numberprgn"] not in seen_rfcs:
                seen_rfcs.add(rfc["numberprgn"])
                unique_rfcs.append(rfc)
        formatted_response["rfcs"] = unique_rfcs

    return formatted_response

def add_scores_to_items(formatted_response, ic_scores, event_scores, rfc_scores):
    def convert_score(score):
        return round(score * 100)
    
    # Add scores and sort incidents
    for incident in formatted_response["incidents"]:
        numberprgn = incident["numberprgn"]
        if numberprgn in ic_scores:
            incident["score"] = convert_score(ic_scores[numberprgn])
    formatted_response["incidents"] = sorted(
        formatted_response["incidents"], 
        key=lambda x: x.get("score", 0), 
        reverse=True
    )

    # Add scores and sort events
    for event in formatted_response["events"]:
        event_id = event["event_id"]
        if event_id in event_scores:
            event["score"] = convert_score(event_scores[event_id])
    formatted_response["events"] = sorted(
        formatted_response["events"], 
        key=lambda x: x.get("score", 0), 
        reverse=True
    )

    # Add scores and sort rfcs
    for rfc in formatted_response["rfcs"]:
        numberprgn = rfc["numberprgn"]
        if numberprgn in rfc_scores:
            rfc["score"] = convert_score(rfc_scores[numberprgn])
    formatted_response["rfcs"] = sorted(
        formatted_response["rfcs"], 
        key=lambda x: x.get("score", 0), 
        reverse=True
    )

    return formatted_response

from datetime import datetime


def sort_format_results(format_results):
    # Extract incidents and rfcs with empty list as default
    incidents = format_results.get('incidents', [])
    rfcs = format_results.get('rfcs', [])
    events = format_results.get('events', [])

    # Simple sort by created_ts string
    sorted_incidents = sorted(
        incidents,
        key=lambda x: x['created_ts'],
        reverse=True
    )
    
    # Handle None values in the planned_start field
    # Items with None values will be placed at the end when reverse=True
    sorted_rfcs = sorted(
        rfcs,
        key=lambda x: (x['planned_start'] is None, x['planned_start']),
    )
    
    # Return as a dictionary with sorted lists
    return {
        'incidents': sorted_incidents,
        'rfcs': sorted_rfcs,
        "events": events
    }


# def sort_format_results(format_results):
#     # Extract incidents and rfcs with empty list as default
#     incidents = format_results.get('incidents', [])
#     rfcs = format_results.get('rfcs', [])
#     events = format_results.get('events', [])
    
#     # Simple sort by created_ts string
#     sorted_incidents = sorted(
#         incidents,
#         key=lambda x: x['created_ts'],
#         reverse=True
#     )
    
#     sorted_rfcs = sorted(
#         rfcs,
#         key=lambda x: x['planned_start'],
#         reverse=True
#     )
    
#     # Return as a dictionary with sorted lists
#     return {
#         'incidents': sorted_incidents,
#         'rfcs': sorted_rfcs,
#         "events":events
#     }
# def sort_format_results(format_results):
#     # Extract incidents and rfcs with empty list as default
#     incidents = format_results.get('incidents', [])
#     rfcs = format_results.get('rfcs', [])
#     events=format_results.get('events', [])
    
#     # Sort incidents and rfcs separately
#     sorted_incidents = sorted(
#         incidents,
#         key=lambda x: datetime.fromisoformat(x['created_ts'].replace('Z', '+00:00')),
#         reverse=True
#     )
    
#     sorted_rfcs = sorted(
#         rfcs,
#         key=lambda x: datetime.fromisoformat(x['planned_start'].replace('Z', '+00:00')),
#         reverse=True
#     )
    
#     # Return as a dictionary with sorted lists
#     return {
#         'incidents': sorted_incidents,
#         'rfcs': sorted_rfcs,
#         "events":events
#     }

# # Sort and maintain separate lists

@similarity.get("/similarity_api")
def read_root(event_id: str, input_query: str, site: Optional[str] = None):
    global tid

    tid=event_id
    
    print("INPUT ISSUE:\n", input_query)

    similar_steps_taken, similar_IC,ic_scores = db_ic(input_query, site=site)
    res_rfc, similar_RFC,rfc_scores = db_rfc(input_query, site=site)
    steps_to_be_taken, similar_event,event_scores = db(input_query, k=10, site=site)
    # res, similar_problem = db_p(input_query, site=site)
    # res_pt, similar_pt = db_pt(input_query, site=site)

    #final_text = steps_to_be_taken + similar_steps_taken + res + res_pt
    final_text = steps_to_be_taken + similar_steps_taken
    if len(final_text)>0:
        print("Final text---------------------------------\n",final_text)
        suggested_steps = generate_suggested_steps_i(input_query, final_text)
    else:
        suggested_steps=""


    similar_data={"similar_events": similar_event,
        "similar_incidents": similar_IC,
        "similar_rfc": similar_RFC,
        }

    
    format_results=format_response(similar_data)
    format_results=remove_duplicates(format_results)

    format_results=add_scores_to_items(format_results,ic_scores,event_scores,rfc_scores)

    format_results["ic_scores"]=ic_scores
    format_results["event_scores"]=event_scores
    format_results["rfc_scores"]=rfc_scores

    print("FORMATED >>>>>>>>>>>>>>>>>>> RESULTS __>>>>>\n",format_results)



    sorted_results = sort_format_results(format_results)
    print("Sorted Incidents:")
    for incident in sorted_results['incidents']:
        print(f"{incident['created_ts']} - {incident['numberprgn']}")

    for rfc in sorted_results['rfcs']:
        print(f"{rfc['planned_start']} - {rfc['numberprgn']}")
    
    for event in sorted_results['events']:
        print(f"{event['event_id']}")


    # return {
    #     "format_results",format_results
    #     "gcc_notes": steps_to_be_taken,
    #     "incident_steps": similar_steps_taken,
    #     "rfc_steps": res_rfc,
    #     # "problem_data": res,
    #     # "problem_task_data": res_pt,
    #     "overall_runbook": suggested_steps,
    #     "similar_events": similar_event,
    #     "similar_incidents": similar_IC,
    #     "similar_rfc": similar_RFC,
    #     # "similar_problems": similar_problem,
    #     # "similar_pt": similar_pt,
    # }

    return {
        "format_results":sorted_results,
        "gcc_notes": steps_to_be_taken,
        "incident_steps": similar_steps_taken,
        "rfc_steps": res_rfc,
        # "problem_data": res,
        # "problem_task_data": res_pt,
        "overall_runbook": suggested_steps
        # "similar_events": similar_event,
        # "similar_incidents": similar_IC,
        # "similar_rfc": similar_RFC,
        # "similar_problems": similar_problem,
        # "similar_pt": similar_pt,
    }


# @app.get("/dashboard")
# def dash(page: int = Query(1, ge=1), per_page: int = Query(10, ge=1)):
#     df = dc_events_df.copy().drop_duplicates(subset=["event_id"])
#     start = (page - 1) * per_page
#     end = start + per_page
#     result = df[start:end].to_dict(orient='records')
#     return result

# @app.get("/dashboard_IC")
# def dash(page: int = Query(1, ge=1), per_page: int = Query(10, ge=1)):
#     start = (page - 1) * per_page
#     df_ic = incidents_df.copy().drop_duplicates(subset=["NUMBERPRGN"])
#     # columns:['NUMBERPRGN', "BRIEF_DESCRIPTION",'NETWORK_NAME','TYPE','DATESTAMP', 'DESCRIPTION','LOCATION']
#     df_ic=df_ic[['NUMBERPRGN', "BRIEF_DESCRIPTION",'NETWORK_NAME',"PROBLEM_STATUS","OPEN_TIME"]]
#     #NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME
#     end = start + per_page
#     result_ic = df_ic[start:end].to_dict(orient='records')
#     return result_ic

# @app.get("/dashboard_IC1")
# def dashIC():
    
#     df_ic = incidents_df.copy().drop_duplicates(subset=["NUMBERPRGN"])
#     # columns:['NUMBERPRGN', "BRIEF_DESCRIPTION",'NETWORK_NAME','TYPE','DATESTAMP', 'DESCRIPTION','LOCATION']
#     df_ic=df_ic[['NUMBERPRGN', "BRIEF_DESCRIPTION",'NETWORK_NAME',"PROBLEM_STATUS","OPEN_TIME"]]
#     #NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME
    
#     result_ic = df_ic.to_dict(orient='records')
#     return result_ic

# @app.get("/get_event_byid")
# def get_event_by_id(id: int):
#     df = dc_events_df.copy()
#     df = df[df["event_id"] == id]

#     if df.empty:
#         raise HTTPException(status_code=404, detail="Event not found")

#     result = df.to_dict(orient="records")[0]
#     return result

# def trigae(input_id):
#     match_in_a = dc_events_df[dc_events_df['event_id'] == int(input_id)]
#     print("matching event data:\n", match_in_a)

#     if not match_in_a.empty:
#         id_v1 = match_in_a['config_item_id'].values[0]
#         print("LOGICAL NAME:\n", id_v1)
#         data_in_b = ci_df[ci_df['LOGICAL_NAME'] == id_v1]
#         if not data_in_b.empty:
#             return data_in_b.iloc[0].to_dict()
#     return {}

# def trigae_ic(input_id):
#     match_in_a = incidents_df[incidents_df['NUMBERPRGN'] == input_id]
#     print("MATCHING IC DATA------\n:")
#     print("COLS OF INCIDENTS:\n", incidents_df.columns.to_list())
#     if not match_in_a.empty:
#         id_v1 = match_in_a['NETWORK_NAME'].values[0]
#         print("LOGICAL NAME:\n", id_v1)
#         data_in_b = ci_df[ci_df['LOGICAL_NAME'] == id_v1]
#         if not data_in_b.empty:
#             return data_in_b.iloc[0].to_dict()
#     return {}

def generate_suggested_steps(query_text, similar_gccnotes):
    prompt = f"""Given the following query and similar resolved tickets, suggest steps to resolve the issue:

    Query: {query_text}

    {similar_gccnotes}

    Suggested steps to resolve the query:"""
    response, _ = llm_app_vox_triage_response(prompt)
    return response

def generate_suggested_steps_i(query_text, similar_stepstaken):
    prompt = f"""Given the following query and similar resolved tickets, what could be the root cause issue and suggest steps to resolve the issue
    Query: {query_text}

    {similar_stepstaken}

    ROOT CAUSE AND Suggested steps to resolve the query:"""
    response, _ = llm_app_vox_triage_response(prompt)
    return response

# ---------------------------------------- api_ai app_new --------------------------------------------






