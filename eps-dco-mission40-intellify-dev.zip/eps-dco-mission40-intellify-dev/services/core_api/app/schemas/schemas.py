from pydantic import BaseModel,Field,Json
from typing import Optional,Dict,Any,List,Union
from datetime import date, datetime
from enum import Enum     

# Pydantic Models for API Inputs
class Pagination(BaseModel):
    page: int = Field(1, ge=1, description="Page number for pagination")
    per_page: int = Field(100, ge=1, description="Number of items per page")

class SearchQuery(BaseModel):
    query: str = Field(..., description="Search term to look up in the database")

class TriageEvent(BaseModel):
    event_input_id: int = Field(..., description="Event ID to triage")

class TriageIncident(BaseModel):
    incident_input_id: str = Field(..., description="Incidents ID to triage")


class IncidentRequest(BaseModel):
    numberprgn: str  

class TestingIncident(BaseModel):
    numberprgn: str
    title: str
    incident_filter: int
    rfc_filter: int
    
class TriageCI(BaseModel):
    ci_id: str

class EventRequest(BaseModel):
    event_id: int
  
  
class DateTimeFilter(BaseModel):
    start_date: datetime
    end_date: datetime
      
class EventFilterRequest(BaseModel):
    event_id: int
    title: str
    incident_filter: DateTimeFilter
    rfc_filter: DateTimeFilter
    
class IncidentFilterRequest(BaseModel):
    numberprgn: str
    title: str
    incident_filter: DateTimeFilter
    rfc_filter: DateTimeFilter

class TokenRequest(BaseModel):
    id: str  
    title: Optional[str] = ""
    incident_start_datetime:datetime
    incident_end_datetime:datetime
    rfc_start_datetime:datetime
    rfc_end_datetime:datetime
    token_count: Optional[int] = 0

'''class SummaryRequest(BaseModel):
    summary_data: Json  '''

class VoxData(BaseModel):
    title: str
    numberprgn: str
    incident_filter: DateTimeFilter 
    rfc_filter: DateTimeFilter
    vox_location: List[Union[str,List[Dict[str,Any]],List[Dict[str,Any]]]]
    vox_events: List[Union[str,List[Dict[str,Any]]]]
    vox_app_server: List[Union[str,List[Dict[str,Any]],List[Dict[str,Any]]]]
    vox_assign_group: List[Union[str,List[Dict[str,Any]],List[Dict[str,Any]]]]
    vox_up_downstream: List[Union[str,List[Dict[str,Any]],List[Dict[str,Any]],List[Dict[str,Any]],List[Dict[str,Any]]]]
    vox_device_type: List[Union[str,List[Dict[str,Any]],List[Dict[str,Any]]]]
    total_tokens:int




class summaryApi(BaseModel):
    #metadata : Dict[str,Any] 
    #message: str
    data: str

# class FeedbackRequest(BaseModel):
#     user_id: str
#     is_positive: Optional[bool] = None  # Make is_positive optional
#     llm_response: str
#     text_feedback: Optional[str] = None  # Make text_feedback optional
#     timestamp: datetime  # Timestamp is required


# Response Schema
class FeedbackResponse(BaseModel):
    message: str
    status: str
    user_id: str

class TokenResponse(BaseModel):
    message: str
    status: str
    user_id: str


class TabType(str, Enum):
    RCA = "rca"
    TRIAGE = "triage"
    EVENTS = "events"
    SUMMARY = "summary"
    LOCATION = "location"
    APPLICATION = "application"
    ASSIGNMENT = "assignment"
    DC1 = "dc1"
    DEVICE = "device"
    CONFIG = "configuration"


class FeedbackRequest(BaseModel):
    tab_type: TabType
    is_positive: bool
    # llm_response: Union[str, List[str]],
    llm_response: List[str] # Can be either string or list of strings
    text_feedback: Optional[str] = None
    id: str




#dashboard 


class FeedbackSummaryRequest(BaseModel):
    filter_type: Optional[str] = None  # "day", "week", "month", "custom_date"
    start_date: Optional[date] = None  # Required only if filter_type = "custom_date"
    end_date: Optional[date] = None    # Required only if filter_type = "custom_date"
    
class FeedbackTableRequest(BaseModel):
    page: int = 1      # Page number (default=1)
    limit: int = 10    # Number of records per page
    filter_type: Optional[str] = None  # "day", "week", "month", "custom_date"
    start_date: Optional[date] = None  # Required only if filter_type = "custom_date"
    end_date: Optional[date] = None    # Required only if filter_type = "custom_date"
	
class FeedbackFilterRequest(BaseModel):
    page: int = Field(..., gt=0, description="Page number for pagination")
    limit: int = Field(..., gt=0, description="Number of records per page")
    filter_option: Optional[str] = Field(None, description="Filter option: 'positive', 'negative', or 'feedback'")
    filter_type: Optional[str] = Field(None, description="Date filter type: 'day', 'week', 'month', 'custom_date'")
    start_date: Optional[date] = Field(None, description="Start date for custom date filtering (YYYY-MM-DD)")
    end_date: Optional[date] = Field(None, description="End date for custom date filtering (YYYY-MM-DD)")
	
	

#addd new date filter


