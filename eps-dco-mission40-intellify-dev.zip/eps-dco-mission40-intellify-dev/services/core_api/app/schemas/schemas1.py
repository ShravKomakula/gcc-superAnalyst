from pydantic import BaseModel,Field
from typing import Optional
from datetime import datetime     

# Pydantic Models for API Inputs
class Pagination(BaseModel):
    page: int = Field(1, ge=1, description="Page number for pagination")
    per_page: int = Field(100, ge=1, description="Number of items per page")

class SearchQuery(BaseModel):
    query: str = Field(..., description="Search term to look up in the database")

class TriageEvent(BaseModel):
    event_input_id: int = Field(..., description="Event ID to triage")

class TriageIncident(BaseModel):
    incident_input_id: str = Field(..., description="Incidents ID to triage")


class IncidentRequest(BaseModel):
    numberprgn: str  

class TestingIncident(BaseModel):
    numberprgn: str
    title: str
    incident_filter: int
    rfc_filter: int
    
class TriageCI(BaseModel):
    ci_id: str

class EventRequest(BaseModel):
    event_id: int
    
class EventFilterRequest(BaseModel):
    event_id: int
    title: str
    incident_filter: Optional[int] = 1 
    rfc_filter: Optional[int] = 1
    
class IncidentFilterRequest(BaseModel):
    numberprgn: str  
    title: Optional[str] = ""
    period:Optional[str] = "Days"
    incident_filter: Optional[int] = 1 
    rfc_filter: Optional[int] = 1
    
    
class FeedbackRequest(BaseModel):
    user_id: str
    is_positive: Optional[bool] = None  # Make is_positive optional
    llm_response: str
    text_feedback: Optional[str] = None  # Make text_feedback optional
    timestamp: datetime  # Timestamp is required

# Response Schema
class FeedbackResponse(BaseModel):
    message: str
    status: str
    user_id: str

