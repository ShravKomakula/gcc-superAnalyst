# eps-dco-mission40-intellify
The purpose of this repository is for Intellify Project -  GEN AI model, most specifically we want to develop a LLM for the below personas: 
 - GenAI Super Analyst & Ops Support to reduce time to triage, research and diagnose service-impacting event  and reduce hand-offs,
 - GenAI Service Quality & Assurance Reduce human effort by replacing manual reviews and assurance tasks with automated reviews

# General Project Details

This project is related to the CI details which can be found at [CI Details](https://smweb.pfizer.com/dynci/?ID=CI4280533).

For more information, please refer to the following Confluence pages:

- [GCC & SRE Super Analyst](https://confluence.pfizer.com/pages/viewpage.action?pageId=407896242)
- [Audit Analyst](https://confluence.pfizer.com/pages/viewpage.action?pageId=407896244&src=contextnavpagetreemode)

# Technical Requirements

## AWS Access

You need to have AWS Rapid Account Request access on this group: `PFE-RAPID-CUSTOMER-ADMIN-SSO_905418048995_PFE-AWS-PROD`. You can request access through [Group Manager](https://requestmanager1.pfizer.com/Group/Default.aspx?lang_o=en) by selecting the distribution list.

## Local Execution

For local execution, install SAML by following the instructions provided [here](https://confluence.pfizer.com/display/aespublic/Using+AWS+CLI+with+SAML+Authentication+-+Version+2).

## Data Migration

For data migration, follow these steps:

- **SRE Analyst**: First run `datamigrationsre.py` and then `sre_dc1_events.py` including the `oracle_cx` dependency.
- **GCC Analyst**: Run `datamigration.py`.

## Machine Details

- The Windows Machine Network Name is `amraewp00023799` and it is located in the `us-east-1` region.
- The Linux Machine Network Name is `amraelp00023801` and it is located in the `us-east-1` region.

# Branching and Committing

Always your commits should be signed!!!!

When working on a new feature or bug fix, create a new branch from the `dev` branch. The branch name should be descriptive and reflect the work being done.

Include the story ID in your commit messages. This helps to track the work done for each story and provides a clear history of changes.

Here's an example of a commit message:
In this example, `1234` is the story ID and `Add new feature` is a brief description of the changes made in the commit.