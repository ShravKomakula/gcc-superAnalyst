
from datetime import datetime
from fastapi import APIRouter,HTTPException
import boto3
from botocore.exceptions import ClientError
from typing import List,Dict
import psycopg2
import json
from pydantic import BaseModel
from schemas.schemas import TestingIncident,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.ci_based_incidents import get_ci_based_incidents

from utils.events.ci_based_events_util import get_ci_based_events


ci_based_incidents =APIRouter()



@ci_based_incidents.post("/get_all_ci_based_incidents")
async def get_all_ci_based_incidents(request: IncidentFilterRequest):
    numberprgn = request.numberprgn
    incident_filter = request.incident_filter
    # period=request.period
    is_im = numberprgn.startswith("IM")
      
    if is_im:
        try: 
            #print("********************************************",period)

            # Fetch incident details to get network_name
            query = """
            SELECT network_name,open_time
            FROM dc1sm_ro.incidents
            WHERE numberprgn = %s;
            """
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(query, (numberprgn,))
            incident = cursor.fetchone()
            cursor.close()
            conn.close()

            if not incident:
                raise HTTPException(status_code=404, detail="Incident not found.")

            network_name = incident[0]
            open_time = incident[1]
            

            # Fetch CI-based incidents
            ci_based_incidents = get_ci_based_incidents(network_name, incident_filter,open_time)

            # Return all combined data
            result = {
                "ci_based_incidents": ci_based_incidents
            }
            return {
                "message": "Successfully returned the  data",
                "data": result,
            }
        except Exception as e:
            return {
                "status_code": 400,
                "message": "Error fetching data",
                "details": str(e)
            }
    else:
        try:
            event_id = int(request.numberprgn)
            incident_filter = request.incident_filter  # Incident filter parameter
            # period=request.period
            
            #print("EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE",event_id)
            # Fetch event details to get network_name
            query = """
            SELECT network_name,created_ts
            FROM dc1.events
            WHERE event_id = %s;
            """
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(query, (event_id,))
            event = cursor.fetchone()
            cursor.close()
            conn.close()

            if not event:
                raise HTTPException(status_code=404, detail="Event not found.")

            network_name = event[0]
            open_time = event[1]
            

            # Fetch CI-based incidents with incident filter
            ci_based_events = get_ci_based_events(network_name, incident_filter,open_time)

            # Return all combined data
            result = {
                "network_name": network_name,
                "ci_based_incidents": ci_based_events,
            }
            
            #print("result resultresult",result)
            return {
                "message": "Successfully returned the data",
                "data": result
            }
        except Exception as e:
            return {
                "status_code": 400,
                "message": "Error fetching data",
                "details": str(e)
            }
    



@ci_based_incidents.post("/ci_based_incidents_ci")
async def ci_based_incidents_ci(request: IncidentFilterRequest):
    try:
        network_name = request.numberprgn
        incident_filter = request.incident_filter
        open_time = datetime.now()
        print("Network name:----------\n",network_name)

        # Fetch CI-based incidents
        ci_based_incidents = get_ci_based_incidents(network_name, incident_filter,open_time)

        print("incidents_data  #############################:\n",ci_based_incidents)

        # Return all combined data
        result = {
            "ci_based_incidents": ci_based_incidents
        }
        return {
            "message": "Successfully returned the  data",
            "data": result,
        }

    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }


