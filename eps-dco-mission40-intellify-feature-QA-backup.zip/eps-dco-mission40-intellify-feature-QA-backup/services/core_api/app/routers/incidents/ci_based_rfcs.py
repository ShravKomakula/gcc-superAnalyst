

from fastapi import APIRouter,HTTPException
import boto3
from botocore.exceptions import ClientError
from typing import List,Dict
import psycopg2
import json
from datetime import datetime
from pydantic import BaseModel
from schemas.schemas import TestingIncident,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.ci_based_rfcs import get_ci_based_rfcs





ci_based_rfcs =APIRouter()





    
@ci_based_rfcs.post("/get_all_ci_based_rfcs")
async def get_all_ci_based_rfcs(request: IncidentFilterRequest):
    numberprgn = request.numberprgn
    rfc_filter = request.rfc_filter  # New filter parameter for RFCs
    is_im = numberprgn.startswith("IM")
    if is_im:
        try:
            # Fetch incident details to get network_name
            query = """
            SELECT network_name,open_time
            FROM dc1sm_ro.incidents
            WHERE numberprgn = %s;
            """
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(query, (numberprgn,))
            incident = cursor.fetchone()
            cursor.close()
            conn.close()

            if not incident:
                raise HTTPException(status_code=404, detail="Incident not found.")

            network_name = incident[0]
            open_time=incident[1]

            # Fetch CI-based RFCs
            ci_based_rfcs = get_ci_based_rfcs(network_name, rfc_filter,open_time)

            # Return all combined data
            result = {
                "network_name": network_name,
                "ci_based_rfcs": ci_based_rfcs
            }
            return {
                "message": "Successfully returned the data",
                "data": result
            }
        except Exception as e:
            return {
                "status_code": 400,
                "message": "Error fetching data",
                "details": str(e)
            }
    else:
        try:
            event_id = int(request.numberprgn)
            rfc_filter=request.rfc_filter 
            # Fetch incident details to get network_name
            query = """
            SELECT network_name,created_ts
            FROM dc1.events
            WHERE event_id = %s;
            """
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(query, (event_id,))
            event = cursor.fetchone()
            cursor.close()
            conn.close()

            if not event:
                raise HTTPException(status_code=404, detail="Event not found.")

            network_name = event[0]
            created_ts=event[1]
            

            # Fetch data      
            ci_based_rfcs_events=get_ci_based_rfcs(network_name,rfc_filter,created_ts)
            
            #print("ci_based_rfcs_events",ci_based_rfcs_events)
            
            # Return all combined data
            result= {
                "network_name": network_name,
                "ci_based_rfcs_events":ci_based_rfcs_events
            }
            return {"message": "Successfully returned the data",
                                "data":result}
        except Exception as e:
            return {
                "status_code": 400,
                "message": "Error fetching data",
                "details": str(e)
            }



@ci_based_rfcs.post("/ci_based_rfcs_ci")
async def ci_based_rfcs_ci(request: IncidentFilterRequest):
    try:
        network_name = request.numberprgn
        rfc_filter = request.rfc_filter  # New filter parameter for RFCs
        open_time = datetime.now()

        # Fetch CI-based RFCs
        ci_based_rfcs = get_ci_based_rfcs(network_name, rfc_filter,open_time)
        print("ci_based_rfcs_ci ci_based_rfcs_ci api ",ci_based_rfcs)

        # Return all combined data
        result = {
            "network_name": network_name,
            "ci_based_rfcs": ci_based_rfcs
        }
        return {
            "message": "Successfully returned the data",
            "data": result
        }
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }



