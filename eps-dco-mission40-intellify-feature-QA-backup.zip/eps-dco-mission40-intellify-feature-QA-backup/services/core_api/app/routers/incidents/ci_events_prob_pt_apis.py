
import traceback
from fastapi import APIRouter,HTTPException
import boto3
from botocore.exceptions import ClientError
from typing import List,Dict
import psycopg2
import json
from pydantic import BaseModel
from schemas.schemas import TestingIncident,IncidentRequest,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.ci_events_prob_pt import get_ci_based_events,get_problem_tasks,get_problems
from utils.utils import get_days_hours

ci_events_prob_pt =APIRouter()

# Main API Endpoint
@ci_events_prob_pt.post("/get_all_others_data")
async def get_all_others_data(request: IncidentFilterRequest):
    try:
        numberprgn=request.numberprgn
        is_im = numberprgn.startswith("IM")
        if  is_im :
            numberprgn = request.numberprgn
            incident_filter = request.incident_filter
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            # Fetch incident details to get network_name
            query = """
            SELECT logical_name,open_time,network_name
            FROM dc1sm_ro.incidents
            WHERE numberprgn = %s;
            """
            cursor.execute(query, (numberprgn,))
            incident = cursor.fetchone()
            if not incident:
                raise HTTPException(status_code=404, detail="Incident not found.")

            logical_name = incident[0]
            open_time = incident[1]
            network_name =  incident[2]
            
            latest_open_time_result=open_time
            if latest_open_time_result:
                latest_open_time = latest_open_time_result
                incident_cutoff_time_before,incident_cutoff_time_after=get_days_hours(incident_filter,latest_open_time)
            print("incident_cutoff_time_before",incident_cutoff_time_before)
            print("incident_cutoff_time_after",incident_cutoff_time_after)

            event_query = f"""
                WITH Rankedevents AS (
                    SELECT
                        event_id,event_title,created_ts,severity,event_status,
                        ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY created_ts DESC) AS rn
                    FROM
                        dc1.events
                    WHERE 
                        network_name = %s
                )
                SELECT
                    event_id,event_title,created_ts,severity,event_status
                FROM
                    Rankedevents
                WHERE
                    rn = 1
                ORDER BY
                    created_ts DESC;
                """
            cursor.execute(event_query, (network_name,))
            #events=cursor.fetchall()
            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            events = [dict(zip(columns, row)) for row in rows]
            cursor.close()
            conn.close()
            # Fetch data       
            problems_tasks = get_problem_tasks(network_name)
            problems = get_problems(network_name)
            result = {
                "network_name": network_name,           
                "problems_tasks": problems_tasks,
                "problems":problems, 
                "ci_based_events":events
            }
            return {
                "message": "Successfully returned the  data",
                "data": result,
            }
            
        else:
            event_id = int(request.numberprgn)

            # Fetch incident details to get network_name
            query = """
            SELECT network_name
            FROM dc1.events
            WHERE event_id = %s;
            """
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(query, (event_id,))
            incident = cursor.fetchone()
            cursor.close()
            conn.close()

            if not incident:
                raise HTTPException(status_code=404, detail="Incident not found.")

            network_name = incident[0]

            # Fetch data       
            problems_tasks = get_problem_tasks(network_name)
            problems = get_problems(network_name)
            ci_based_events = get_ci_based_events(network_name)
            print(problems_tasks)
            ci_based_events = [row for row in ci_based_events if row['event_id'] != event_id]


            # Return all combined data
            result= {
                "network_name": network_name,           
                "problems_tasks": problems_tasks,
                "problems":problems,          
                "ci_based_events":ci_based_events,            
            }
            return {"message": "Successfully returned the data",
                            "data":result}
    except Exception as e:
        error_trace = traceback.format_exc()  # Captures full stack trace
        print("Error Traceback:", error_trace)  # Prints full traceback to the console
        
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e),
            "traceback": error_trace  # Optional: Return traceback in response
        }
