
from datetime import datetime
from fastapi import APIRouter,HTTPException
import boto3
from botocore.exceptions import ClientError
from typing import List,Dict
import psycopg2
import json
from pydantic import BaseModel
from schemas.schemas import TestingIncident,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from fastapi import APIRouter, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List,Optional,Dict, List
from utils.prompts import *

# from utils.incidents.ci_based_incidents import get_ci_based_incidents

# from utils.events.ci_based_events_util import get_ci_based_events


ic_initial_analysis =APIRouter()




@ic_initial_analysis.post("/ic_initial_analysis")
async def ic_analysis(request: IncidentFilterRequest):
        numberprgn = request.numberprgn
        #incident_filter = request.incident_filter
        open_time = datetime.now()
        print("Network name:----------\n",numberprgn)

        # Fetch CI-based incidents
        try: 
            #print("********************************************",period)

            # Fetch incident details to get network_name
            query = """
            SELECT numberprgn,network_name,open_time,description,brief_description
            FROM dc1sm_ro.incidents
            WHERE numberprgn = %s;
            """
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(query, (numberprgn,))
            incident = cursor.fetchone()
            cursor.close()
            conn.close()

            if not incident:
                raise HTTPException(status_code=404, detail="Incident not found.")

            incident_number = incident[0]
            network_name=incident[1]
            open_time = incident[2]
            description=incident[3]
            brief_description=incident[4]
            result = {
                "incident_number": incident_number,
                "open_time":open_time,
                "Incident_network":network_name,
                "brief_description":brief_description,
                "description":description
            }

            result,t=await llm_incident_triage_response(str(result))
            return {
                "message": "Successfully returned the  data",
                "data": result,
            }
        except Exception as e:
            return {
                "status_code": 400,
                "message": "Error fetching data",
                "details": str(e)
            }
            
            

