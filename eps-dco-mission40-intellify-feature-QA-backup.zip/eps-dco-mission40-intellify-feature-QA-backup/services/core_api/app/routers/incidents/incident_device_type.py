from fastapi import APIRouter, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List,Optional,Dict, List
from pydantic import BaseModel, Field
import boto3
import psycopg2
from datetime import datetime
import json
from botocore.exceptions import ClientError
import uvicorn
from schemas.schemas import TestingIncident,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.incident_device_type import get_incident_device_type
from utils.utils import get_days_hours

# Router
incident_device_type = APIRouter()

@incident_device_type.post("/get_all_incident_device_type")
async def get_all_incident_device_type_data(request: IncidentFilterRequest):
    cursor = None
    conn = None
    try:
        numberprgn = request.numberprgn
        incident_filter = request.incident_filter
        
        # First fetch the network name and type for the incident
        incident_query = """
        SELECT i.network_name, c.type,i.open_time
        FROM dc1sm_ro.incidents i
        LEFT JOIN itsm_owner.cis c ON i.network_name = c.network_name
        WHERE i.numberprgn = %s;
        """
        
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        cursor.execute(incident_query, (numberprgn,))
        incident_data = cursor.fetchone()
        
        if not incident_data:
            cursor.close()
            conn.close()
            return {
                "message": f"No incident found for: {numberprgn}",
                "networks_data": []
            }
            
        network_name, network_type,latest_open_time_result = incident_data
        
        if not network_type:
            cursor.close()
            conn.close()
            return {
                "message": f"No network type found for network: {network_name}",
                "networks_data": []
            }
        
        # Get networks of the same type
        networks_query = """
        SELECT network_name
        FROM itsm_owner.cis
        WHERE type = %s
        AND istatus IN ('Active', 'Run')
        LIMIT 5;
        """
        
        cursor.execute(networks_query, (network_type,))
        networks = [row[0] for row in cursor.fetchall()]
        
        # Get incidents data for each network
        all_networks_data = []
        
        for network in networks:

            print("network at line 74\n",network)
            # Get the latest open_time for cutoff calculation
            # latest_query = """
            # SELECT open_time
            # FROM dc1sm_ro.incidents
            # WHERE NETWORK_NAME = %s
            # ORDER BY open_time DESC
            # LIMIT 1;
            # """
            
            # cursor.execute(latest_query, (network,))
            # latest_open_time_result = cursor.fetchone()
            
            if not latest_open_time_result:
                continue
                
            latest_open_time = latest_open_time_result
            print("incident_latest_open_time >>>>>>>>>\n",latest_open_time)
            incident_cutoff_time_before ,incident_cutoff_time_after= get_days_hours(incident_filter, latest_open_time)
            
            # Get incidents data with cutoff
            # incidents_query = """
            # WITH RankedIncidents AS (
            #     SELECT 
            #         numberprgn, status, assignment, brief_description, 
            #         location, open_time,
            #         ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
            #     FROM dc1sm_ro.incidents
            #     WHERE 
            #         NETWORK_NAME = %s
            #         AND open_time >= %s
            # )
            # SELECT 
            #     numberprgn, status, assignment, brief_description, 
            #     location, open_time
            # FROM RankedIncidents
            # WHERE rn = 1
            # ORDER BY open_time DESC;
            # """
            incidents_query = """
            WITH RankedIncidents AS (
    SELECT 
        numberprgn, status, assignment, brief_description, 
        location, open_time, network_name,
        ROW_NUMBER() OVER (PARTITION BY numberprgn, network_name ORDER BY open_time DESC) AS rn  -- Added network_name to partition
    FROM dc1sm_ro.incidents
    WHERE 
        NETWORK_NAME = %s
        AND open_time >= %s
        AND open_time <= %s
       
)
SELECT 
    numberprgn, status, assignment, brief_description, 
    location, open_time, network_name
FROM RankedIncidents
WHERE rn = 1
ORDER BY open_time DESC;
            """
            print("incident_cutoff_time >>>>>>>>> /n",incident_cutoff_time_before)
            cursor.execute(incidents_query, (network, incident_cutoff_time_before,incident_cutoff_time_after))
            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            print("columns at line 114\n",columns)
            
            network_incidents = [dict(zip(columns, row)) for row in rows]
            
            if network_incidents:
                all_networks_data.append({
                    # "network_name": network,
                    "incidents": network_incidents
                })
        
        if cursor:
            cursor.close()
        if conn:
            conn.close()
        result = {
            # "original_network": network_name,
            # "network_type": network_type,
            "incidents_data": all_networks_data
        }
        
        log_data = {
            "input_ticket": request.dict(),
            "networks_found": networks,
            "response_data": result,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # Added timestamp
        }
        
        
        try:
            with open('device_result.json', 'r') as f:
                existing_data = json.load(f)
                if not isinstance(existing_data, list):
                    existing_data = [existing_data]
        except (FileNotFoundError, json.JSONDecodeError):
            existing_data = []
        
        
        existing_data.append(log_data)
        
        
        with open('device_result.json', 'w') as f:
            json.dump(existing_data, indent=2, default=str, fp=f)
            
        return {
                "message": "Successfully returned the  data",
                "data": result,
            }      
    except Exception as e:
        if 'cursor' in locals() and cursor:
            cursor.close()
        if 'conn' in locals() and conn:
            conn.close()
        raise HTTPException(status_code=500, detail=str(e))