from fastapi import APIRouter, HTTPException,Query
from fastapi.middleware.cors import CORSMiddleware
from typing import List,Optional,Dict, List
from pydantic import BaseModel, Field
import boto3 
import psycopg2
import json
from botocore.exceptions import ClientError
import uvicorn 
from schemas.schemas import Pagination,SearchQuery,TriageIncident,TriageEvent,TriageCI,FeedbackSummaryRequest,FeedbackTableRequest,FeedbackFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.utils import execute_paginated_query,execute_query,fetch_query_results,get_total_count
from psycopg2.extras import RealDictCursor

dashboard_api = APIRouter()




@dashboard_api.post("/get_all_event_dashboard")
def get_all_event_dashboard(pagination: Pagination):
    """
    Paginated results for events with additional columns and totals.
    """
    try:
        # Base query without pagination for total count
        base_query = """
            WITH RankedEvents AS (
                SELECT
                    event_id,
                    created_ts,
                    event_title,
                    severity,
                    event_status,
                    location,
                    ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY created_ts DESC) AS rn
                FROM
                    dc1.events
            )
            SELECT
                event_id, created_ts, event_title, severity, event_status, location
            FROM
                RankedEvents
            WHERE
                rn = 1
        """

        # Calculate total records
        total_count = get_total_count(base_query)

        # Pagination logic
        start = (pagination.page - 1) * pagination.per_page
        paginated_query = base_query + """
            ORDER BY created_ts DESC
            LIMIT %s OFFSET %s
        """
        columns = ["event_id", "created_ts", "event_title", "severity", "event_status","location"]
        result = fetch_query_results(paginated_query, (pagination.per_page, start), columns)

        # Calculate total records for the current page
        total_records_per_page = len(result)

        # Return response with pagination details
        return {
            "message": "Successfully returned the data",
            "data": result,
            "page": pagination.page,
            "per_page": pagination.per_page,
            "total_records": total_count,
            "total_pages": (total_count + pagination.per_page - 1) // pagination.per_page,
            "records_on_page": total_records_per_page
        }
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }



@dashboard_api.post("/get_all_incident_dashboard")
def get_all_incident_dashboard(pagination: Pagination):
    """
    Paginated results for incidents with additional metadata.
    """
    try:
        # Base query without pagination for total count
        base_query = """
            select distinct NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME, LOCATION, LOGICAL_NAME FROM dc1sm_ro.incidents
        """

        # Calculate total records
        total_count = get_total_count(base_query)

        # Pagination logic
        start = (pagination.page - 1) * pagination.per_page
        paginated_query = base_query + """
            ORDER BY
                OPEN_TIME DESC
            LIMIT %s OFFSET %s
        """
        columns = ["NUMBERPRGN", "BRIEF_DESCRIPTION", "NETWORK_NAME", "PROBLEM_STATUS", "OPEN_TIME", "LOCATION", "LOGICAL_NAME"]
        result = fetch_query_results(paginated_query, (pagination.per_page, start), columns)

        # Calculate total records for the current page
        total_records_per_page = len(result)

        # Return response with pagination details
        return {
            "message": "Successfully returned the data",
            "data": result,
            "page": pagination.page,
            "per_page": pagination.per_page,
            "total_records": total_count,
            "total_pages": (total_count + pagination.per_page - 1) // pagination.per_page,
            "records_on_page": total_records_per_page
        }
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }


@dashboard_api.post("/search_api_events")
def search_events(search: SearchQuery, pagination: Pagination):
    try:
        """
        Search events with status and severity, calculate total records, and implement pagination.
        """
        offset = (pagination.page - 1) * pagination.per_page
        limit = pagination.per_page

        # Base query to fetch all matching records with status and severity
        base_query = """
            SELECT DISTINCT event_id, config_item_id, created_ts, event_title, severity, event_status
            FROM dc1.events
            WHERE event_title ILIKE %s OR config_item_id ILIKE %s
        """
        search_term = f"%{search.query}%"

        # Query to count total matching records
        count_query = f"""
            SELECT COUNT(*) AS total_count
            FROM ({base_query}) AS subquery
        """
        total_count_result = fetch_query_results(count_query, (search_term, search_term), ["total_count"])
        total_count = total_count_result[0]["total_count"]

        # Paginated query with LIMIT and OFFSET
        paginated_query = base_query + " ORDER BY created_ts DESC LIMIT %s OFFSET %s"
        columns = ["event_id", "config_item_id", "created_ts", "event_title", "severity", "event_status"]
        results = fetch_query_results(paginated_query, (search_term, search_term, limit, offset), columns)

        # Calculate total pages
        total_pages = (total_count + pagination.per_page - 1) // pagination.per_page

        return {
            "message": "Successfully returned the data",
            "data": results,
            "total_records": total_count,
            "total_pages": total_pages,
            "page": pagination.page,
            "per_page": pagination.per_page
        }
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }


@dashboard_api.post("/search_api_incidents")
def search_incidents(search: SearchQuery, pagination: Pagination):
    """
    Search incidents with paginated results, total records, and total pages.
    """
    try:
        # Calculate offset and limit for pagination
        offset = (pagination.page - 1) * pagination.per_page
        limit = pagination.per_page

        # Query to count total matching records
        count_query = """
            SELECT COUNT(DISTINCT NUMBERPRGN) AS total_count
            FROM dc1sm_ro.incidents
            WHERE BRIEF_DESCRIPTION ILIKE %s OR NETWORK_NAME ILIKE %s
        """
        search_term = f"%{search.query}%"
        count_result = fetch_query_results(count_query, (search_term, search_term), ["total_count"])
        total_count = count_result[0]["total_count"]

        # Query to fetch paginated results
        paginated_query = """
            SELECT DISTINCT NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME
            FROM dc1sm_ro.incidents
            WHERE BRIEF_DESCRIPTION ILIKE %s OR NETWORK_NAME ILIKE %s
            ORDER BY OPEN_TIME DESC
            LIMIT %s OFFSET %s
        """
        columns = ["NUMBERPRGN", "BRIEF_DESCRIPTION", "NETWORK_NAME", "PROBLEM_STATUS", "OPEN_TIME"]
        results = fetch_query_results(paginated_query, (search_term, search_term, limit, offset), columns)

        # Calculate total pages
        total_pages = (total_count + pagination.per_page - 1) // pagination.per_page

        return {
            "message": "Successfully returned the data",
            "data": results,
            "total_records": total_count,
            "total_pages": total_pages,
            "page": pagination.page,
            "per_page": pagination.per_page
        }
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }



@dashboard_api.post("/get_event_by_id")
def get_event_by_id(event_input_id: TriageEvent):
    try:
        """
        Get event by ID and calculate the total records.
        """
        query = "SELECT event_id, config_item_id, created_ts, event_title, severity, event_status FROM dc1.events WHERE event_id = %s"
        columns = ["event_id", "config_item_id", "created_ts", "event_title", "severity", "event_status"]
        result = fetch_query_results(query, (event_input_id.event_input_id,), columns)

        per_pages = 100
        total_count = len(result)  # Total records for the given event_id
        total_pages = (total_count + per_pages - 1) // per_pages
        if not result:
            raise HTTPException(status_code=404, detail="Event not found")
        
        return {
            "message": "Successfully returned the data",
            "data": result[0],  # Since event_id is unique, only return the first record
            "total_records": total_count,
            "total_pages":total_pages
        }
    except Exception as e:
        return {"status_code": "400", "Message": "Error fetching data", "details": str(e)}



# 4. Get Incident by ID API
@dashboard_api.post("/get_incident_by_id")
def get_incident_by_id(incident_input_id: TriageIncident):
    try:
        """
        Get incident by ID and calculate the total records.
        """
        query = "SELECT NUMBERPRGN, BRIEF_DESCRIPTION, NETWORK_NAME, PROBLEM_STATUS, OPEN_TIME FROM dc1sm_ro.incidents WHERE NUMBERPRGN = %s"
        columns = ["NUMBERPRGN", "BRIEF_DESCRIPTION", "NETWORK_NAME", "PROBLEM_STATUS", "OPEN_TIME"]
        result = fetch_query_results(query, (incident_input_id.incident_input_id,), columns)

        total_count = len(result)  # Total records for the given incident_id

        if not result:
            raise HTTPException(status_code=404, detail="Incident not found")
        
        return {
            "message": "Successfully returned the data",
            "data": result[0],  # Since incident_id is unique, only return the first record
            "total_records": total_count
        }
    except Exception as e:
        return {"status_code": "400", "Message": "Error fetching data", "details": str(e)}



@dashboard_api.post("/get_events_by_ci_id")
def get_events_by_ci_id(ci_input: TriageCI, pagination: Pagination):
    """
    Get events by CI ID with paginated results, total records, and total pages.
    """
    try:
        # Calculate offset and limit for pagination
        offset = (pagination.page - 1) * pagination.per_page
        limit = pagination.per_page

        # Query to fetch paginated results
        paginated_query = """
            SELECT DISTINCT
                event_id, 
                config_item_id, 
                created_ts, 
                event_title, 
                severity, 
                event_status
            FROM 
                dc1.events
            WHERE 
                config_item_id = %s
            ORDER BY 
                created_ts DESC
            LIMIT %s OFFSET %s
        """
        columns = ["event_id", "config_item_id", "created_ts", "event_title", "severity", "event_status"]
        results = fetch_query_results(paginated_query, (ci_input.ci_id, limit, offset), columns)

        if not results:
            raise HTTPException(status_code=404, detail="No events found for the given CI ID")

        # Calculate total records based on the result size
        total_records = len(results)

        # Calculate total pages (if less than `per_page`, total_pages is 1)
        total_pages = (total_records + pagination.per_page - 1) // pagination.per_page

        return {
            "message": "Successfully returned the data",
            "data": results,
            "total_records": total_records,  # This reflects only the rows in the result
            "total_pages": total_pages,
            "page": pagination.page,
            "per_page": pagination.per_page
        }
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }

@dashboard_api.post("/get_incidents_by_ci_id")
def get_incidents_by_ci_id(ci_input: TriageCI, pagination: Pagination):
    """
    Get incidents by CI ID with paginated results, total records, and total pages.
    """
    try:
        # Calculate offset and limit for pagination
        offset = (pagination.page - 1) * pagination.per_page
        limit = pagination.per_page

        # Query to fetch paginated results
        query = """
            SELECT DISTINCT
                NUMBERPRGN, 
                BRIEF_DESCRIPTION, 
                NETWORK_NAME, 
                PROBLEM_STATUS, 
                OPEN_TIME
            FROM 
                dc1sm_ro.incidents
            WHERE 
                logical_name = %s
            ORDER BY 
                OPEN_TIME DESC
            LIMIT %s OFFSET %s
        """
        columns = ["NUMBERPRGN", "BRIEF_DESCRIPTION", "NETWORK_NAME", "PROBLEM_STATUS", "OPEN_TIME"]
        results = fetch_query_results(query, (ci_input.ci_id, limit, offset), columns)

        if not results:
            raise HTTPException(status_code=404, detail="No incidents found for the given CI ID")

        # Calculate total records based on the result size
        total_records = len(results)

        # Calculate total pages
        total_pages = (total_records + pagination.per_page - 1) // pagination.per_page

        return {
            "message": "Successfully returned the data",
            "data": results,
            "total_records": total_records,  # Reflects only the rows in the result
            "total_pages": total_pages,
            "page": pagination.page,
            "per_page": pagination.per_page
        }
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }



#dashboard materic

# API to Fetch Feedback Table Data with Pagination
@dashboard_api.post("/feedback_table")
def get_feedback_table(request: FeedbackTableRequest):
    """
    Fetch paginated feedback data with optional date filters.
    Supports: day, week, month, custom_date filters.
    """
    try:
        conn = connect_to_postgres({})
        cursor = conn.cursor(cursor_factory=RealDictCursor)

        offset = (request.page - 1) * request.limit  # Pagination offset

        # Determine date filter condition
        date_condition = ""
        if request.filter_type:
            if request.filter_type == "day":
                date_condition = "AND timestamp >= CURRENT_DATE"
            elif request.filter_type == "week":
                date_condition = "AND timestamp >= CURRENT_DATE - INTERVAL '7 days'"
            elif request.filter_type == "month":
                date_condition = "AND timestamp >= CURRENT_DATE - INTERVAL '1 month'"
            elif request.filter_type == "custom_date" and request.start_date and request.end_date:
                # Fix for same-day filtering (00:00:00 to 23:59:59)
                if request.start_date == request.end_date:
                    date_condition = f"AND timestamp BETWEEN '{request.start_date} 00:00:00' AND '{request.start_date} 23:59:59'"
                else:
                    date_condition = f"AND timestamp BETWEEN '{request.start_date} 00:00:00' AND '{request.end_date} 23:59:59'"

        # Fetch paginated feedback records
        query = f"""
            SELECT tab_type, id, is_positive, timestamp, text_feedback FROM user_feedback.combined_feedback 
            WHERE 1=1 {date_condition}
            ORDER BY timestamp DESC
            LIMIT {request.limit} OFFSET {offset}
        """
        cursor.execute(query)
        feedback_data = cursor.fetchall()

        # Get total count with the same filters
        cursor.execute(f"""
            SELECT COUNT(*) AS total FROM user_feedback.combined_feedback 
            WHERE 1=1 {date_condition}
        """)
        total_records = cursor.fetchone()["total"]

        cursor.close()
        conn.close()

        return {
            "status": "success",
            "page": request.page,
            "limit": request.limit,
            "total_records": total_records,
            "data": feedback_data
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching feedback: {str(e)}")

#  API to Fetch Feedback Summary
@dashboard_api.post("/feedback_summary")
def get_feedback_summary(request: FeedbackSummaryRequest):
    """
    Fetch summary of feedback data with optional date filters.
    Supports: day, week, month, custom_date filters.
    """
    try:
        conn = connect_to_postgres({})
        cursor = conn.cursor(cursor_factory=RealDictCursor)

        # Determine date filter condition
        date_condition = ""
        if request.filter_type:
            if request.filter_type == "day":
                date_condition = "AND timestamp >= CURRENT_DATE"
            elif request.filter_type == "week":
                date_condition = "AND timestamp >= CURRENT_DATE - INTERVAL '7 days'"
            elif request.filter_type == "month":
                date_condition = "AND timestamp >= CURRENT_DATE - INTERVAL '1 month'"
            elif request.filter_type == "custom_date" and request.start_date and request.end_date:
                # Fix for same-day filtering (00:00:00 to 23:59:59)
                if request.start_date == request.end_date:
                    date_condition = f"AND timestamp BETWEEN '{request.start_date} 00:00:00' AND '{request.start_date} 23:59:59'"
                else:
                    date_condition = f"AND timestamp BETWEEN '{request.start_date} 00:00:00' AND '{request.end_date} 23:59:59'"

        # Get total feedback count
        cursor.execute(f"""
            SELECT COUNT(*) AS total 
            FROM user_feedback.combined_feedback 
            WHERE 1=1 {date_condition}
        """)
        total_records = cursor.fetchone()["total"]

        # Get count per tab_type
        cursor.execute(f"""
            SELECT tab_type, COUNT(*) AS count 
            FROM user_feedback.combined_feedback 
            WHERE 1=1 {date_condition}
            GROUP BY tab_type
        """)
        tab_type_counts = {row["tab_type"]: row["count"] for row in cursor.fetchall()}

        # Get category-wise count of positive and negative feedback
        cursor.execute(f"""
            SELECT tab_type AS category, 
                   SUM(CASE WHEN is_positive::BOOLEAN = TRUE THEN 1 ELSE 0 END) AS positive,
                   SUM(CASE WHEN is_positive::BOOLEAN = FALSE THEN 1 ELSE 0 END) AS negative
            FROM user_feedback.combined_feedback 
            WHERE 1=1 {date_condition}
            GROUP BY tab_type
        """)
        category_stats = []
        for row in cursor.fetchall():
            total = row["positive"] + row["negative"]
            percentage_positive = (row["positive"] / total * 100) if total > 0 else 0
            category_stats.append({
                "category": row["category"],
                "positive": row["positive"],
                "negative": row["negative"],
                "percentage_positive": f"{percentage_positive:.2f}%"
            })

        cursor.close()
        conn.close()

        return {
            "status": "success",
            "total_records": total_records,
            "categories": tab_type_counts,
            "category_stats": category_stats
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching feedback summary: {str(e)}")
 
@dashboard_api.post("/filter_feedback_status")
def filter_feedback_status(request: FeedbackFilterRequest):
    """
    Fetch feedback data based on filter criteria for positive/negative feedback:
    - 'positive': Show only positive feedback (is_positive = TRUE)
    - 'negative': Show only negative feedback (is_positive = FALSE)
    - Supports date filters: day, week, month, custom_date
    """
    try:
        conn = connect_to_postgres({})
        cursor = conn.cursor(cursor_factory=RealDictCursor)

        offset = (request.page - 1) * request.limit  # Pagination offset

        # Determine filter condition for positive/negative feedback
        filter_condition = ""
        if request.filter_option == "positive":
            filter_condition += "AND CAST(is_positive AS BOOLEAN) = TRUE"
        elif request.filter_option == "negative":
            filter_condition += "AND CAST(is_positive AS BOOLEAN) = FALSE"

        # Determine date filter condition
        date_condition = ""
        if request.filter_type:
            if request.filter_type == "day":
                date_condition = "AND timestamp >= CURRENT_DATE"
            elif request.filter_type == "week":
                date_condition = "AND timestamp >= CURRENT_DATE - INTERVAL '7 days'"
            elif request.filter_type == "month":
                date_condition = "AND timestamp >= CURRENT_DATE - INTERVAL '1 month'"
            elif request.filter_type == "custom_date" and request.start_date and request.end_date:
                # Fix for same-day filtering (00:00:00 to 23:59:59)
                if request.start_date == request.end_date:
                    date_condition = f"AND timestamp BETWEEN '{request.start_date} 00:00:00' AND '{request.start_date} 23:59:59'"
                else:
                    date_condition = f"AND timestamp BETWEEN '{request.start_date} 00:00:00' AND '{request.end_date} 23:59:59'"

        # Fetch paginated filtered feedback records
        query = f"""
            SELECT tab_type, id, is_positive, timestamp, text_feedback 
            FROM user_feedback.combined_feedback 
            WHERE 1=1 {filter_condition} {date_condition}
            ORDER BY timestamp DESC
            LIMIT {request.limit} OFFSET {offset}
        """
        cursor.execute(query)
        feedback_data = cursor.fetchall()

        # Get total count with the same filters
        cursor.execute(f"""
            SELECT COUNT(*) AS total FROM user_feedback.combined_feedback 
            WHERE 1=1 {filter_condition} {date_condition}
        """)
        total_records = cursor.fetchone()["total"]

        cursor.close()
        conn.close()

        return {
            "status": "success",
            "page": request.page,
            "limit": request.limit,
            "total_records": total_records,
            "data": feedback_data
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error filtering feedback: {str(e)}")
        
@dashboard_api.get("/token_table")
def get_token_table(
    page: int = Query(1, ge=1),  # Page number (default: 1, minimum: 1)
    limit: int = Query(10, ge=1)  # Number of records per page (default: 10, minimum: 1)
):
    """
    Fetch paginated token data using page and limit.

    :param page: Page number (default=1, minimum=1)
    :param limit: Number of records per page (default=10, minimum=1)
    """
    try:
        conn = connect_to_postgres({})
        cursor = conn.cursor(cursor_factory=RealDictCursor)

        offset = (page - 1) * limit  # Calculate offset based on page number

        # Fetch paginated data
        query = """
            SELECT * FROM user_feedback.token_monitoring 
            ORDER BY id DESC
            LIMIT %s OFFSET %s
        """
        cursor.execute(query, (limit, offset))
        token_data = cursor.fetchall()
        print("token_data",token_data)

        # Get total count of records
        cursor.execute("SELECT COUNT(*) AS total FROM user_feedback.token_monitoring")
        total_records = cursor.fetchone()["total"]

        avg_query = "SELECT AVG(token_count) AS avg_token_count  FROM user_feedback.token_monitoring WHERE timestamp >= NOW() - INTERVAL '30 days'"
        cursor.execute(avg_query)
        avg_token_count = cursor.fetchone()["avg_token_count"]
        
        print("avg_token_count",avg_token_count)

        cursor.close()
        conn.close()

        return {
            "status": "success",
            "page": page,
            "limit": limit,
            "total_records": total_records,
            "data": token_data,
            "avg":avg_token_count
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching token data: {str(e)}")
