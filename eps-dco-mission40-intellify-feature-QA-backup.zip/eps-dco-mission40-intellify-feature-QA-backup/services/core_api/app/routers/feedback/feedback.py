

from fastapi import APIRouter, HTTPException
from datetime import datetime
from schemas.schemas import TabType,FeedbackRequest
from database.database import connect_to_postgres
from schemas.schemas import FeedbackRequest, FeedbackResponse,TokenRequest,TokenResponse

feedback_router = APIRouter()



from fastapi import FastAPI, Query
from datetime import datetime
from enum import Enum
import json
import os
from typing import Optional, List, Union
from pydantic import BaseModel



# Route for submitting feedback
from datetime import datetime
@feedback_router.post("/submit_feedback", response_model=FeedbackResponse)
async def submit_feedback(feedback: FeedbackRequest):
    try:
        timestamp=datetime.now()
        # Prepare the feedback entry with the timestamp from the request
        feedback_entry = {
            "user_id": feedback.id,
            "tab_type": feedback.tab_type,
            "is_positive": str(feedback.is_positive),  # This can be None
            "llm_response": feedback.llm_response,
            "text_feedback": feedback.text_feedback,  # This can also be None
            "timestamp": timestamp  # Use the user-provided timestamp
        }
        print("feedback_entry : >>>>>>>>>>>>>>>>>>>>>>>>>>>/n",feedback_entry["llm_response"])
        # Connect to PostgreSQL database
        conn = connect_to_postgres({})

        # Prepare the insert query
        insert_query = """
            INSERT INTO user_feedback.combined_feedback (id,tab_type, is_positive, llm_response, text_feedback, timestamp)
            VALUES (%s, %s,%s, %s, %s, %s)
        """

        # Insert the feedback data
        with conn.cursor() as cursor:
            cursor.execute(insert_query, (
                feedback_entry["user_id"],
                feedback_entry["tab_type"],
                feedback_entry["is_positive"],  # Can be None, PostgreSQL will handle it as NULL
                feedback_entry["llm_response"],
                feedback_entry["text_feedback"],  # Can be None, PostgreSQL will handle it as NULL
                feedback_entry["timestamp"]  # Use the timestamp from the request body
            ))

            # Commit the transaction
            conn.commit()

        # Close the connection
        conn.close()

        return FeedbackResponse(message="Feedback submitted successfully", status="success", user_id=feedback.id)

    except Exception as e:
        # Handle unexpected errors
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")



# @feedback_router.post("/submit_feedback_rca", response_model=FeedbackResponse)
# async def submit_feedback_rca(feedback: FeedbackRequest):
#     try:
#         # Prepare the feedback entry
#         feedback_entry = {
#             "user_id": feedback.user_id,
#             "is_positive": feedback.is_positive,
#             "llm_response": feedback.llm_response,
#             "text_feedback": feedback.text_feedback,
#             "timestamp": feedback.timestamp
#         }

#         # Use the existing `connect_to_postgres` function
#         conn = connect_to_postgres({})

#         # Prepare and execute the insert query
#         insert_query = """
#             INSERT INTO user_feedback.feedback_rca (user_id, is_positive, llm_response, text_feedback, date_timestamp)
#             VALUES (%s, %s, %s, %s, %s)
#         """
#         with conn.cursor() as cursor:
#             cursor.execute(
#                 insert_query,
#                 (
#                     feedback_entry["user_id"],
#                     feedback_entry["is_positive"],
#                     feedback_entry["llm_response"],
#                     feedback_entry["text_feedback"],
#                     feedback_entry["timestamp"]
#                 )
#             )
#             conn.commit()

#         # Close the connection
#         conn.close()

#         return FeedbackResponse(
#             message="Feedback submitted successfully",
#             status="success",
#             user_id=feedback.user_id
#         )

#     except Exception as e:
#         # Handle unexpected errors
#         raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")


@feedback_router.post("/token_monitor",response_model=TokenResponse)
async def token_monitor(request: TokenRequest):
    try:
        # Prepare the feedback entry
        feedback_entry = {
            "id": request['id'],
            "title": request['title'],
            "incident_start_datetime":request['incident_start_datetime'],
            "incident_end_datetime":request['incident_end_datetime'],
            "rfc_start_datetime":request['rfc_start_datetime'],
            "rfc_end_datetime":request['rfc_end_datetime'],
            "token_count":request['token_count']
        }

        # Use the existing `connect_to_postgres` function
        conn = connect_to_postgres({})

        # Prepare and execute the insert query
        insert_query = """
            INSERT INTO user_feedback.token_monitoring (id, title,timestamp, incident_start_datetime,incident_end_datetime,rfc_start_datetime,rfc_end_datetime,token_count)
            VALUES (%s,%s, %s, %s, %s, %s, %s ,%s)
        """
        with conn.cursor() as cursor:
            cursor.execute(
                insert_query,
                (
                    feedback_entry["id"],
                    feedback_entry["title"],
                    datetime.now(),
                    feedback_entry["incident_start_datetime"],
                    feedback_entry["incident_end_datetime"],
                    feedback_entry["rfc_start_datetime"],
                    feedback_entry["rfc_end_datetime"],
                    feedback_entry["token_count"]
                )
            )
            conn.commit()

        # Close the connection
        conn.close()

        return FeedbackResponse(
            message="Feedback submitted successfully",
            status="success",
            user_id=request['id']
        )

    except Exception as e:
        # Handle unexpected errors
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")
