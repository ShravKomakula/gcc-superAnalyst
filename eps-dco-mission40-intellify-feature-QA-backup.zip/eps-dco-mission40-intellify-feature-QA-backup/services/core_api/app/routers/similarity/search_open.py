import os
import requests
import json
from sentence_transformers import SentenceTransformer
from typing import List
import boto3
from botocore.exceptions import ClientError

from .vox import IASOpenaiEmbeddings

# Initialize the embedding model
model = IASOpenaiEmbeddings(engine="text-embedding-ada-002")

def get_secret():

    secret_name =os.getenv('opensearch_secret',"")
    
    region_name = "us-east-1"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        # For a list of exceptions thrown, see
        raise e

    secret = get_secret_value_response['SecretString']
    #a = get_secret_value_response['SecretString']['OpenAI']
    return secret

# OpenSearch Configuration
access_json = json.loads(get_secret())
opensearch_host = access_json['opensearch_host']
index_name = 'chunked_embeddings_vox1'
headers = {"Content-Type": "application/json"}
username = access_json['username']
password = access_json['password']
auth = (username, password) 

# Function to perform k-NN search
def knn_search(query_text: str, index_name: str, k: int = 10):
    """Perform k-NN search on OpenSearch index."""
    query_embedding = model.embed_query(query_text)

    search_query = {
        "size": k,  # Number of results
        "query": {
            "knn": {
                "embedding": {
                    "vector": query_embedding,
                    "k": k
                }
            }
        }
    }

    response = requests.post(
        f"{opensearch_host}/{index_name}/_search",
        headers=headers,
        data=json.dumps(search_query),
        auth=auth
    )

    if response.status_code == 200:
        #print("Search results:", json.dumps(response.json(), indent=2))
        response = response.json()
        res=[hit['_source']['title'] for hit in response['hits']['hits']]
        # res=[{'title': hit['_source']['title'], 'score': hit['_score']} for hit in response['hits']['hits']]
        #scores=[hit['_score'] for hit in response['hits']['hits']]
        scores = {hit['_source']['title']: hit['_score'] for hit in response['hits']['hits']}
        print("RES>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n",res,scores)
        return res,scores
        
    else:
        print(f"Search failed: {response.status_code}, {response.text}")
        return []
