
import os
from aiohttp import ClientError
from fastapi import logger
import requests
import json
from sentence_transformers import SentenceTransformer
from typing import List
import boto3
from .vox import IASOpenaiEmbeddings

# Initialize the embedding model
model = IASOpenaiEmbeddings(engine="text-embedding-ada-002")

# OpenSearch Configuration
def get_secret():
    secret_name =os.getenv('opensearch_secret',"") 
    region_name = "us-east-1"
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        raise e

    secret = get_secret_value_response['SecretString']
    logger.info("Secrets retrieved from AWS Secrets Manager successfully.")
    return json.loads(secret)
data=get_secret()
print("dataaaaaaaaaaaaaaa opennnnnnnnnnnnnnnnn",data)
opensearch_host=data['opensearch_host']
username=data['username']
password=data['password']
auth=(username,password)

index_name = 'chunked_embeddings_vox1'
headers = {"Content-Type": "application/json"}


# Function to perform k-NN search
def knn_search(query_text: str, index_name: str, k: int = 3):
    """Perform k-NN search on OpenSearch index."""
    query_embedding = model.embed_query(query_text)

    search_query = {
        "size": k,  # Number of results
        "query": {
            "knn": {
                "embedding": {
                    "vector": query_embedding,
                    "k": k
                }
            }
        }
    }

    response = requests.post(
        f"{opensearch_host}/{index_name}/_search",
        headers=headers,
        data=json.dumps(search_query),
        auth=auth
    )

    if response.status_code == 200:
        #print("Search results:", json.dumps(response.json(), indent=2))
        response = response.json()
        return [hit['_source']['title'] for hit in response['hits']['hits']]
    else:
        print(f"Search failed: {response.status_code}, {response.text}")
        return []
