
from fastapi import APIRouter, HTTPException, Query
from psycopg2.extras import RealDictCursor
import psycopg2
from datetime import datetime, timedelta
import json
import uvicorn
import boto3
from botocore.exceptions import ClientError
from typing import Dict, Optional
from schemas.schemas import TestingIncident
from database.database import connect_to_postgres,get_postgres_secrets
from utils.utils import execute_paginated_query,fetch_query_results


# Setup FastAPI pfizer_router
triage_router = APIRouter()

@triage_router.post("/test_triage")
async def triage(details:TestingIncident,page: int = Query(1, ge=1),page_size: int = Query(10, ge=1, le=100),):
    start = datetime.now()
    print(f"Start Time: {start}")
    try: 
        filtered_incidents = []
        filtered_events = []
        filtered_rfc = []
        created_time = None  # Default value

        # Incident Logic
        if details.new_item.startswith("IM"):
            query = """
                SELECT assignment, open_time, type
                FROM dc1sm_ro.incidents
                WHERE NUMBERPRGN = %s
            """
            incident = execute_paginated_query(query, (details.new_item,), page, page_size)
            print(f"Incident Data: {incident}")  # Debug log

            if not incident:
                raise HTTPException(status_code=404, detail="Incident not found.")

            assignment = incident[0].get("assignment")
            open_time = incident[0].get("open_time")
            device_type = incident[0].get("type")

            if not all([assignment, open_time, device_type]):
                raise HTTPException(status_code=404, detail="Missing required field(s) in incident data.")

            start_date = open_time - timedelta(days=details.incident_filter)

            # Query to fetch filtered incidents
            filtered_incidents_query = """
                SELECT *
                FROM dc1sm_ro.incidents
                WHERE open_time BETWEEN %s AND %s
                AND NUMBERPRGN != %s
            """
            filtered_incidents = execute_paginated_query(
                filtered_incidents_query,
                (start_date, open_time, details.new_item),
                page,
                page_size
            )

        # Event Logic
        else:
            query = """
                SELECT created_ts, config_item_id
                FROM dc1.events
                WHERE event_id = %s
            """
            event = execute_paginated_query(query, (int(details.new_item),), page, page_size)
            print(f"Event Data: {event}")  # Debug log

            if not event:
                raise HTTPException(status_code=404, detail="Event not found.")

            created_time = event[0].get("created_ts")
            config_item_id = event[0].get("config_item_id")

            if not all([created_time, config_item_id]):
                raise HTTPException(status_code=404, detail="Missing required field(s) in event data.")

            start_date = created_time - timedelta(days=details.incident_filter)

            # Query to fetch filtered events
            filtered_events_query = """
                SELECT *
                FROM dc1.events
                WHERE created_ts BETWEEN %s AND %s
                AND event_id != %s
            """
            filtered_events = execute_paginated_query(
                filtered_events_query,
                (start_date, created_time, int(details.new_item)),
                page,
                page_size
            )

        # RFC Logic
        if created_time is None:
            created_time = datetime.now()  # Fallback if no event timestamp

        start_date_rfc = created_time - timedelta(days=details.rfc_filter)
        filtered_rfc_query = """
            SELECT *
            FROM dc1sm_ro.rfcs
            WHERE open_time BETWEEN %s AND %s
        """
        filtered_rfc = execute_paginated_query(
            filtered_rfc_query,
            (start_date_rfc, created_time),
            page,
            page_size
        )

        # Combine Results
        response = {
            "filtered_incidents": filtered_incidents if details.new_item.startswith("IM") else [],
            "filtered_events": filtered_events if not details.new_item.startswith("IM") else [],
            "filtered_rfc": filtered_rfc,
            "pagination": {
                "current_page": page,
                "page_size": page_size
            }
        }
        end = datetime.now()
        elapsed_time = end - start
        print(f"Elapsed Time: {elapsed_time}")
        return response

    except HTTPException as http_ex:
        print(f"HTTP Error: {http_ex.detail}")
        raise http_ex
    except Exception as e:
        print(f"Unexpected Error: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

# # Run the FastAPI application
# if __name__ == "__main__":
#     uvicorn.run(pfizer_router, host="127.0.0.1", port=8244)
