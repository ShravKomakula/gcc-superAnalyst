import ast
import asyncio
import time
from schemas.schemas import IncidentFilterRequest
from fastapi import APIRouter, HTTPException

from routers.incidents.incident_assignment_group import *
from routers.incidents.rfc_assignment_group import *
from routers.incidents.ci_events_prob_pt_apis import *
from routers.incidents.ci_based_incidents import *
from routers.incidents.ci_based_rfcs import *
from routers.incidents.get_incident_location import *
from routers.incidents.rfc_location import *
from routers.incidents.rfc_device_type import *
from routers.incidents.ci_info import get_ci_info as ci_information
from routers.incidents.ci_info_depend import get_up_downstream
from routers.incidents.incident_device_type import *
from utils.incidents.ci_based_incidents import *
from utils.prompts import *
from routers.events.ci_based_events import *
from routers.events.ci_based_rfcs_events import *
from routers.events.ci_events_prob_pt_apis_events import *
from routers.events.event_assignment_group import *
from routers.events.rfc_assignment_group_events import *
from routers.events.rfc_location_events import *
from routers.events.ci_info_events import *
from routers.events.get_events_location import *

# ... (Import your other modules and functions)

triage_llm_req = APIRouter()

async def fetch_data(request, is_im):
    """Fetches data based on the IM/Event condition."""
    if is_im:
        incident_location = await get_all_incident_location(request)
        rfc_location = await get_all_rfc_location(request)
        rfc_assignment_group = await get_rfc_assignment_group_data(request)  # Corrected function name
        incident_assignment_group = await get_all_incident_assignment_group_data(request)
        ci_based_incident = await get_all_ci_based_incidents(request)
        ci_based_rfcs = await get_all_ci_based_rfcs(request)
        #new
        device_type_incident = await get_all_incident_device_type_data(request)
        device_type_rfc = await get_all_rfc_device_type_data(request)
        ci_events = {}

        ci_info_up_down_depend =await ci_information(request)
        ci_info_up_down_depend_data = ci_info_up_down_depend.get('data',{})
        ci_info = ci_info_up_down_depend_data.get('ci_info',"NA")
        upstream = ci_info_up_down_depend_data.get('upstream',"NA")
        infrastructure_dependencies = ci_info_up_down_depend_data.get('infrastructure_dependencies',"NA")
        downstream = ci_info_up_down_depend_data.get('downstream',"NA")

        ci_info_up_downstream =await get_up_downstream(request)
        ci_info_up_downstream_data = ci_info_up_downstream.get('data',{})
        ci_info = ci_info_up_downstream_data.get('ci_info',"NA")
        upstream_incidents = ci_info_up_downstream_data.get('upstream_incidents',"NA")
        upstream_rfcs = ci_info_up_downstream_data.get('upstream_rfcs',"NA")
        downstreams_incidents = ci_info_up_downstream_data.get('downstreams_incidents',"NA")
        downstreams_rfcs = ci_info_up_downstream_data.get('downstreams_rfcs',"NA")


        prab_pt_data = await get_all_others_data(request)
        data = prab_pt_data.get('data', {})
        problems_tasks = data.get('problems_tasks', "NA")
        problems = data.get('problems', "NA")
        others_data = {"problems_tasks": problems_tasks, "problems": problems}
    else:
        incident_location = await get_all_incident_location_events(request)
        rfc_location = await get_all_rfc_location_events(request)
        rfc_assignment_group = await get_rfc_assignment_group_data_events(request)
        incident_assignment_group = await get_all_event_assignment_group_data(request)
        ci_based_incident = await get_all_ci_based_incidents(request)
        ci_based_rfcs = await get_all_ci_based_rfcs_events(request)
        device_type_incident = {}
        device_type_rfc = {}
        ci_based_events = await get_all_others_data_events(request)
        ci_based_events_data = ci_based_events.get('data',{})
        ci_events = ci_based_events_data.get('ci_based_events',"NA")
        problems_tasks = ci_based_events_data.get('problems_tasks',"NA")
        problems = ci_based_events_data.get('problems',"NA")
        others_data = {"problems_tasks": problems_tasks, "problems": problems}

        ci_info_up_down_depend =await get_ci_info_events(request)
        ci_info_up_down_depend_data = ci_info_up_down_depend.get('data',{})
        ci_info = ci_info_up_down_depend_data.get('ci_info',"NA")
        upstream = ci_info_up_down_depend_data.get('upstream',"NA")
        infrastructure_dependencies = ci_info_up_down_depend_data.get('infrastructure_dependencies',"NA")
        downstream = ci_info_up_down_depend_data.get('downstream',"NA")
        upstream_incidents={}
        upstream_rfcs={}
        downstreams_incidents={}
        downstreams_rfcs ={}

    return incident_location, rfc_location, rfc_assignment_group, incident_assignment_group, ci_based_incident, ci_based_rfcs, others_data,device_type_incident,device_type_rfc,ci_events,ci_info,upstream_incidents,upstream_rfcs,downstreams_incidents,downstreams_rfcs,upstream,infrastructure_dependencies,downstream

@triage_llm_req.post("/get_all_triage_llm")
async def triage_llm(request: IncidentFilterRequest):
    numberprgn = request.numberprgn
    title = request.title
    is_im = numberprgn.startswith("IM")

    start_time_total = time.time()

    # Fetch data concurrently
    incident_location, rfc_location, rfc_assignment_group, incident_assignment_group, ci_based_incident, ci_based_rfcs, others_data,device_type_incident,device_type_rfc,ci_events,ci_info,upstream_incidents,upstream_rfcs,downstreams_incidents,downstreams_rfcs,upstream,infrastructure_dependencies,downstream = await fetch_data(request, is_im)

    issue_location = str({"issue": title, "data": {"Incidents_by_location": incident_location, "RFCs_by_location": rfc_location}})
    issue_app_server = str({"issue": title, "data": {"Same_network_Incidents": ci_based_incident, "Same_network_RFCs": ci_based_rfcs}})
    issue_assign_group = str({"issue": title, "data": {"Incidents_by_Assign_Group": incident_assignment_group, "RFCs_by_Assign_Group": rfc_assignment_group}})
    #new
    issue_device_type = str({"issue": title, "data": {"Incidents_by_Device_Type": device_type_incident, "RFCs_by_Device_Type": device_type_rfc}})
    issue_up_downstream = str({"issue": title, "data": {"upstream":{"Incidents": upstream_incidents, "RFCs": upstream_rfcs},"downstream":{"Incidents": downstreams_incidents, "RFCs": downstreams_rfcs}}})
    issue_events = str({"issue": title, "data": {"Events": ci_events}})

    start_correlation = time.time()
    result_correlation = await asyncio.gather(
        llm_new_vox_location(issue=issue_location),
        llm_new_vox_app_server(issue=issue_app_server),
        llm_new_vox_assign_group(issue=issue_assign_group),
        llm_new_vox_Events(issue=issue_events),
        llm_new_vox_up_downstream(issue=issue_up_downstream),
        llm_new_vox_device_type(issue=issue_device_type),
        #llm_new_vox_triage_response(data=str(ci_info))
                   )

    end_correlation = time.time()
    correlation_time = end_correlation - start_correlation
    print(f"Correlation Time: {correlation_time}")
    corr_token = sum(item[1] for item in result_correlation) # more pythonic way to sum the tokens
    print(f"Correlation Tokens: {corr_token}")

    vox_location_response, vox_app_server_response, vox_assign_group_response,vox_Events_response,vox_up_downstream_response,vox_device_type_response = {}, {}, {},{}, {}, {}
    try: vox_location_response = ast.literal_eval(result_correlation[0][0])
    except (SyntaxError, ValueError) as e: print(f"Vox Location Error: {e}")
    try: vox_app_server_response = ast.literal_eval(result_correlation[1][0])
    except (SyntaxError, ValueError) as e: print(f"Vox App Server Error: {e}")
    try: vox_assign_group_response = ast.literal_eval(result_correlation[2][0])
    except (SyntaxError, ValueError) as e: print(f"Vox Assign Group Error: {e}")
    try: vox_Events_response = ast.literal_eval(result_correlation[3][0])
    except (SyntaxError, ValueError) as e: print(f"Vox Event Error: {e}")
    try: 
        vox_up_downstream_response = ast.literal_eval(result_correlation[4][0])
        vox_up_downstream_response = [
                        list(vox_up_downstream_response.values())[0],
                        list(list(vox_up_downstream_response.values())[1].values())[0],
                        list(list(vox_up_downstream_response.values())[1].values())[1],
                        list(list(vox_up_downstream_response.values())[2].values())[0],
                        list(list(vox_up_downstream_response.values())[2].values())[1],
                            ]
    except Exception as e: 
        print(f"Vox Up_Down stream Error: {e}")
        vox_up_downstream_response = []
    try: 
        print("vox_device_type_response:",result_correlation[5][0])
        vox_device_type_response = ast.literal_eval(result_correlation[5][0])
    except (SyntaxError, ValueError) as e: print(f"Vox device type Error: {e}")
    # try: 
    #     print("ci_info_response ",result_correlation[6] )
    #     ci_info_response = ast.literal_eval(result_correlation[6][0])
    #     print("ci_info_response ",ci_info_response)
    # except (SyntaxError, ValueError) as e:
    #     print(f"Vox CI data Error: {e}")
    #     ci_info_response = None

    start_summary = time.time()
    issue = str({"issue":title,
                            "data":{"vox_location": vox_location_response,
                            "vox_events": vox_Events_response,
                            "vox_app_server": vox_app_server_response,
                            "vox_assign_group": vox_assign_group_response,
                            "vox_up_downstream":vox_up_downstream_response,
                            "vox_device_type":vox_device_type_response
        }})
    result_summ = await asyncio.gather(llm_new_vox_prc_response(issue=issue), llm_new_vox_rca_response(issue=issue), llm_new_vox_summary(issue=issue))
    end_summary = time.time()
    print(f"Summary Time: {end_summary - start_summary}")

    summ_token = sum(item[1] for item in result_summ) # more pythonic way to sum the tokens
    print(f"Summary Tokens: {summ_token}")

    vox_prc_response_sorted, vox_rca_response_, vox_sum_response = [], [], []
    try: vox_prc_response_sorted = sorted(ast.literal_eval(result_summ[0][0]), key=lambda x: x["likelihood"], reverse=True)
    except (SyntaxError, ValueError) as e: print(f"Vox PRC Error: {e}")
    try: vox_rca_response_ = result_summ[1][0].get('content', []) # safer way to access nested dict
    except (AttributeError, KeyError) as e: print(f"Vox RCA Error: {e}")
    try: vox_sum_response = result_summ[2][0].get('content', [])
    except (AttributeError, KeyError) as e: print(f"Vox Summary Error: {e}")

    response_data = {
        "triage_llm": ci_info,
        "llm_rca": vox_rca_response_,
        "llm_prc": vox_prc_response_sorted,
        "vox_location": list(vox_location_response.values()),
        "vox_app_server": list(vox_app_server_response.values()),
        "vox_assign_group": list(vox_assign_group_response.values()),
        "vox_events":list(vox_Events_response.values()),
        "vox_device_type":list(vox_device_type_response.values()),
        "vox_up_downstream": vox_up_downstream_response,
        "vox_summary": vox_sum_response,
        "total_tokens":summ_token+corr_token
    }
    end_time_total = time.time()
    print(f"Total Execution Time: {end_time_total - start_time_total}")
    return {"message": "Successfully returned the data", "data": response_data}

