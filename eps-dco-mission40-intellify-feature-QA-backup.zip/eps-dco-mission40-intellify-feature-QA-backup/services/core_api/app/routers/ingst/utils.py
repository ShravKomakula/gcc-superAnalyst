
import boto3
import os
import requests
import json
from botocore.exceptions import ClientError
from datetime import datetime
import logging
from fastapi import HTTPException
import os
# Initialize global variables
token_gen_time = None
token = None

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_secret():
    secret_name =os.getenv('vox_secret_name',"") 
    region_name = "us-east-1"
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        raise e

    secret = get_secret_value_response['SecretString']
    logger.info("Secrets retrieved from AWS Secrets Manager successfully.")
    return json.loads(secret)


# Load secrets
docinsights_keys = get_secret()
CLIENT_ID = docinsights_keys['Client_ID']
CLIENT_SECRET = docinsights_keys['Client_Secret']
PINGFEDERATE_URL =docinsights_keys['verification_url']
Docinsights_url=docinsights_keys['DocInsight_URL']
INGEST_URL=Docinsights_url +'/ingest' 
STATUS_URL=Docinsights_url + '/status'
SEARCH_URL=Docinsights_url +'/search'


from datetime import datetime, timedelta  # Importing correctly

def auto_token(prev_token_gen_time, token):
    global token_gen_time
    current_time = datetime.now()  # Use the imported datetime

    if token is None or (current_time - prev_token_gen_time).total_seconds() > 3600:
        try:
            token = federate_auth()  # Obtain a new token
            token_gen_time = current_time  # Update the generation time
            logger.info("New token generated.")
        except Exception as e:
            logger.error(f"Failed to generate new token: {e}")
            raise HTTPException(status_code=500, detail="Token generation failed.")
    else:
        logger.info("Using existing token.")

    return token_gen_time, token

def federate_auth() -> str:
    try:
        payload = f"client_id={CLIENT_ID}&client_secret={CLIENT_SECRET}"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        response = requests.post(PINGFEDERATE_URL, headers=headers, data=payload)
        response.raise_for_status()  # Check for HTTP errors
        token = response.json().get("access_token")
        
        if token is None:
            logger.error("Failed to retrieve access token: No token returned.")
            raise HTTPException(status_code=401, detail="No token returned from authentication.")
        
        logger.info(f"Access token retrieved: {token[:5]}...")  # Log first few characters for confirmation
        return token
    except requests.exceptions.HTTPError as e:
        logger.error(f"HTTP Error during token generation: {e}")
        raise HTTPException(status_code=e.response.status_code, detail="Failed to obtain access token.")
    except requests.exceptions.RequestException as e:
        logger.error(f"Request Exception during token generation: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error during token generation.")

def ingest_documents_from_s3_to_di(bucket_name, folder_name):
    pass

def get_status(request_id, token):
    """Gets status from ingestion based on request id"""
    if not request_id:
        logger.error("Request ID is empty.")
        raise HTTPException(status_code=400, detail="Request ID must be provided.")

    try:
        url = f"{STATUS_URL}?request_id={request_id}"
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {token}'
        }

        logger.info(f"Making request to status API: {url} with headers: {headers}")
        
        response = requests.get(url, headers=headers)

        # Log the response status code and content
        logger.info(f"Status API response: {response.status_code} - {response.text}")

        response.raise_for_status()  # This will raise an error for bad responses
        return response.json()

    except requests.exceptions.HTTPError as e:
        logger.error(f"Error fetching status: {e.response.status_code} {e.response.text}")
        raise HTTPException(status_code=e.response.status_code, detail="Error fetching status.")
    except Exception as e:
        logger.error(f"An error occurred while fetching status: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal Server Error.")


def get_time():
    return datetime.now()

def time_elapsed(start_time):
    current_time = datetime.now()
    elapsed = current_time - start_time
    return elapsed.total_seconds()


def choose_index(index):
    indexes = {"cis" : {
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 0,
            "index": {
                "knn": True,  # Enable kNN support
                "knn.algo_param": {
                    "ef_search": 128,
                    "ef_construction": 512
                }
            }
        },
        "mappings": {
            "properties": {
                "id": {"type": "keyword"},
                "title": {"type": "text", "analyzer": "standard"},
                "network_name": {"type": "text", "analyzer": "standard"}, 
                "r_logical_name": {"type": "text", "analyzer": "standard"},
                "r_network_name": {"type": "text", "analyzer": "standard"}, 
                "pfz_application_name": {"type": "text", "analyzer": "standard"},
                "location": {"type": "text", "analyzer": "standard"},
                "description": {"type": "text"},
                "embedding": {
                    "type": "knn_vector",
                    "dimension": 1536 , 
                    "method": {
                            "name": "hnsw",
                            "space_type": "cosinesimil",
                            "engine": "nmslib"
                        }
                }
            }
        }
    },

    "events" : {
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 0,
            "index": {
                "knn": True  # Enable kNN support
            }
        },
        "mappings": {
            "properties": {
                "id": {"type": "keyword"},
                "title": {"type": "text", "analyzer": "standard"},
                "event_title": {"type": "text", "analyzer": "standard"},
                "config_item_id": {"type": "text", "analyzer": "standard"},
                "description": {"type": "text", "analyzer": "standard"},
                "location": {"type": "text", "analyzer": "standard"},
                "embedding": {
                    "type": "knn_vector",
                    "dimension": 1536 , 
                    "method": {
                            "name": "hnsw",
                            "space_type": "cosinesimil",
                            "engine": "nmslib"
                        }
                }
            }
        }
    },


    "incidnt" : {
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 0,
            "index": {
                "knn": True  # Enable kNN support
            }
        },
        "mappings": {
            "properties": {
                "id": {"type": "keyword"},
                "title": {"type": "text", "analyzer": "standard"},
                "brief_description": {"type": "text", "analyzer": "standard"},
                "network_name": {"type": "text", "analyzer": "standard"},
                "location": {"type": "text", "analyzer": "standard"},
                "logical_name": {"type": "text", "analyzer": "standard"},
                "embedding": {
                    "type": "knn_vector",
                    "dimension": 1536 , 
                    "method": {
                            "name": "hnsw",
                            "space_type": "cosinesimil",
                            "engine": "nmslib"
                        }
                }
            }
        }
    },

    "problems_tasks" : {
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 0,
            "index": {
                "knn": True  # Enable kNN support
            }
        },
        "mappings": {
            "properties": {
                "id": {"type": "keyword"},
                "title": {"type": "text", "analyzer": "standard"},
                "brief_description": {"type": "text", "analyzer": "standard"},
                "parent_problem": {"type": "text", "analyzer": "standard"},
                "embedding": {
                    "type": "knn_vector",
                    "dimension": 1536 , 
                    "method": {
                            "name": "hnsw",
                            "space_type": "cosinesimil",
                            "engine": "nmslib"
                        }
                }
            }
        }
    },

    "problems" : {
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 0,
            "index": {
                "knn": True  # Enable kNN support
            }
        },
        "mappings": {
            "properties": {
                "id": {"type": "keyword"},
                "title": {"type": "text", "analyzer": "standard"},
                "brief_description": {"type": "text", "analyzer": "standard"},
                "embedding": {
                    "type": "knn_vector",
                    "dimension": 1536 , 
                    "method": {
                            "name": "hnsw",
                            "space_type": "cosinesimil",
                            "engine": "nmslib"
                        }
                }
            }
        }
    },

    "rfcs" : {
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 0,
            "index": {
                "knn": True  # Enable kNN support
            }
        },
        "mappings": {
            "properties": {
                "id": {"type": "keyword"},
                "title": {"type": "text", "analyzer": "standard"},
                "brief_description": {"type": "text", "analyzer": "standard"},
                "embedding": {
                    "type": "knn_vector",
                    "dimension": 1536 , 
                    "method": {
                            "name": "hnsw",
                            "space_type": "cosinesimil",
                            "engine": "nmslib"
                        }
                }
            }
        }
    }
    }
    return indexes[index]
