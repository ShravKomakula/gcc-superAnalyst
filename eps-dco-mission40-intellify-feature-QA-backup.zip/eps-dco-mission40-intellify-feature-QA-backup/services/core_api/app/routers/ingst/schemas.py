
from pydantic import BaseModel
from typing import List

class IngestionRequest(BaseModel):
    bucket_name: str
    folder_name: str
    schedule:str

class StatusRequest(BaseModel):
    request_id: str
