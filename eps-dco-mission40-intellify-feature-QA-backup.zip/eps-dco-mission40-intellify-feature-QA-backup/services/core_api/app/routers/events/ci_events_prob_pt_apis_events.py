
from fastapi import APIRouter,HTTPException
import boto3
from botocore.exceptions import ClientError
from typing import List,Dict
import psycopg2
import json
from pydantic import BaseModel
from schemas.schemas import EventRequest,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.utils import get_days_hours
from utils.incidents.ci_events_prob_pt import get_ci_based_events,get_problem_tasks,get_problems

ci_events_prob_pt_events =APIRouter()

# Main API Endpoint
@ci_events_prob_pt_events.post("/get_all_others_data_events")
async def get_all_others_data_events(request: IncidentFilterRequest):
    try:
        numberprgn=request.numberprgn
        is_im = numberprgn.startswith("IM")
        if  is_im :
            print("IFFFFFFFFFFFFFFFFFFFFFFFFFFF condition inside")
            numberprgn = request.numberprgn
            incident_filter = request.incident_filter
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            

            # Fetch incident details to get network_name
            query = """
            SELECT logical_name,open_time,network_name
            FROM dc1sm_ro.incidents
            WHERE numberprgn = %s;
            """
            cursor.execute(query, (numberprgn,))
            incident = cursor.fetchone()
            
            print("incident",incident)


            if not incident:
                raise HTTPException(status_code=404, detail="Incident not found.")

            logical_name = incident[0]
            open_time = incident[1]
            network_name =  incident[2]
            
            print("open_time",open_time)
            print("logical_name",logical_name)
            print("network_name",network_name)
            
            
            latest_open_time_result=open_time
            
            # !!!!!! import new code feb 12 i got mahesh
            # if latest_open_time_result:
            #     print("issssssssssssss")
            #     latest_open_time = latest_open_time_result
            #     incident_cutoff_time=get_days_hours(incident_filter,latest_open_time,period)
            # print("incident_cutoff_time",incident_cutoff_time)
            # print("open time ",open_time)
            # event_query = f"""
            #     WITH Rankedevents AS (
            #         SELECT
            #             event_id,event_title,created_ts,severity,event_status,
            #             ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY created_ts DESC) AS rn
            #         FROM
            #             dc1.events
            #         WHERE 
            #             config_item_id = %s
            #             {f"AND created_ts >= '{incident_cutoff_time}' AND created_ts <= '{latest_open_time}'" if incident_cutoff_time else ''}
            #     )
            #     SELECT
            #         event_id,event_title,created_ts,severity,event_status
            #     FROM
            #         Rankedevents
            #     WHERE
            #         rn = 1
            #     ORDER BY
            #         created_ts DESC;
            #     """
            # cursor.execute(event_query, (logical_name,))
            
            if latest_open_time_result:
                print("issssssssssssss")
                latest_open_time = latest_open_time_result
                incident_cutoff_time_before,incident_cutoff_time_after=get_days_hours(incident_filter,latest_open_time)
            print("incident_cutoff_time_before",incident_cutoff_time_before)
            print("incident_cutoff_time_after",incident_cutoff_time_after)

            print("open time ",open_time)
            event_query = f"""
                WITH Rankedevents AS (
                    SELECT
                        event_id,event_title,created_ts,severity,event_status,
                        ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY created_ts DESC) AS rn
                    FROM
                        dc1.events
                    WHERE 
                        network_name = %s
                )
                SELECT
                    event_id,event_title,created_ts,severity,event_status
                FROM
                    Rankedevents
                WHERE
                    rn = 1
                ORDER BY
                    created_ts DESC;
                """
            cursor.execute(event_query, (network_name,))
           
            events=cursor.fetchall()
            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            events = [dict(zip(columns, row)) for row in rows]
            cursor.close()
            conn.close()
            # Fetch data       
            problems_tasks = get_problem_tasks(network_name)
            problems = get_problems(network_name)
            result = {
                "network_name": network_name,           
                "problems_tasks": problems_tasks,
                "problems":problems, 
                "ci_based_events":events
            }
            return {
                "message": "Successfully returned the  data",
                "data": result,
            }
            
        else:
            event_id = int(request.numberprgn)

            # Fetch incident details to get network_name
            query = """
            SELECT network_name
            FROM dc1.events
            WHERE event_id = %s;
            """
            conn = connect_to_postgres({})
            cursor = conn.cursor()
            cursor.execute(query, (event_id,))
            incident = cursor.fetchone()
            cursor.close()
            conn.close()

            if not incident:
                raise HTTPException(status_code=404, detail="Incident not found.")

            network_name = incident[0]
            
            
            print("network_name ************",network_name)

            # Fetch data       
            problems_tasks = get_problem_tasks(network_name)
            problems = get_problems(network_name)
            ci_based_events = get_ci_based_events(network_name)
            print(problems_tasks)
            ci_based_events = [row for row in ci_based_events if row['event_id'] != event_id]


            # Return all combined data
            result= {
                "network_name": network_name,           
                "problems_tasks": problems_tasks,
                "problems":problems,          
                "ci_based_events":ci_based_events,            
            }
            return {"message": "Successfully returned the data",
                            "data":result}
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }

