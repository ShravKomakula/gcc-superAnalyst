from fastapi import APIRouter, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List,Optional,Dict, List
from pydantic import BaseModel, Field
import boto3 
import psycopg2
import json
from botocore.exceptions import ClientError
import uvicorn 
from schemas.schemas import EventFilterRequest,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.incident_assignment_group import get_incident_assignment_group


event_assignment_group = APIRouter()

@event_assignment_group.post("/get_all_event_assignment_group_data")
async def get_all_event_assignment_group_data(request: IncidentFilterRequest):
    try:
        event_id = int(request.numberprgn)
        incident_filter = request.incident_filter  # Get the incident_filter value from the request

        # Fetch incident details to get network_name
        query = """
        SELECT network_name,created_ts
        FROM dc1.events
        WHERE event_id = %s;
        """
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        cursor.execute(query, (event_id,))
        incident = cursor.fetchone()
        cursor.close()
        conn.close()

        if not incident:
            raise HTTPException(status_code=404, detail="Incident not found.")

        network_name = incident[0]
        open_time = incident[1]

        # Fetch incident assignment group data using the network_name and incident_filter
        incident_assignment_group_data = get_incident_assignment_group(network_name, incident_filter,open_time)
        incident_assignment_group_data = [row for row in incident_assignment_group_data if row['numberprgn'] != event_id]

        result = {
            "incident_assignment_group": incident_assignment_group_data,
        }

        # Return all combined data
        return {
            "message": "Successfully returned the  data",
            "data": result,
        }

    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }

