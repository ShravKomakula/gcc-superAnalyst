
from fastapi import APIRouter,HTTPException
import boto3
from botocore.exceptions import ClientError
from typing import List,Dict
import psycopg2
import json
from pydantic import BaseModel
from schemas.schemas import EventRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.get_incident_location import get_incident_location

from fastapi import APIRouter, HTTPException
from typing import Optional
from schemas.schemas import EventFilterRequest,IncidentFilterRequest
from utils.incidents.get_incident_location import get_incident_location

get_incident_location_api_events = APIRouter()

@get_incident_location_api_events.post("/get_all_incident_location_events")
async def get_all_incident_location_events(request: IncidentFilterRequest):
    try:
        event_id = int(request.numberprgn)
        incident_filter = request.incident_filter  # Get the incident_filter value from the request
        rfc_filter = request.rfc_filter

        # Fetch event details to get network_name
        query = """
        SELECT network_name,created_ts
        FROM dc1.events
        WHERE event_id = %s;
        """
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        cursor.execute(query, (event_id,))
        event = cursor.fetchone()
        cursor.close()
        conn.close()

        if not event:
            raise HTTPException(status_code=404, detail="Event not found.")

        network_name = event[0]
        open_time = event[1]
        

        # Fetch incident location data using the network_name and incident_filter
        incident_location_data = get_incident_location(network_name, incident_filter,rfc_filter,open_time)
        incident_location_data = [row for row in incident_location_data if row['numberprgn'] != event_id]

        result = {
            "incident_location": incident_location_data,
        }

        # Return all combined data
        return {
            "message": "Successfully returned the  data",
            "data": result,
        }

    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }