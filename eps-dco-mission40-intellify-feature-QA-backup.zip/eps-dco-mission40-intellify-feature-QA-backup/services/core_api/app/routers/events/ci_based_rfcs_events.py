
from fastapi import APIRouter,HTTPException
import boto3
from botocore.exceptions import ClientError
from typing import List,Dict
import psycopg2
import json
from pydantic import BaseModel
from schemas.schemas import EventFilterRequest,IncidentFilterRequest
from database.database import connect_to_postgres,get_postgres_secrets
from utils.incidents.ci_based_rfcs import get_ci_based_rfcs

ci_based_rfcs_events =APIRouter()


@ci_based_rfcs_events.post("/get_all_ci_based_rfcs_events")
async def get_all_ci_based_rfcs_events(request: IncidentFilterRequest):
    try:
        event_id = int(request.numberprgn)
        rfc_filter=request.rfc_filter 

        # Fetch incident details to get network_name
        query = """
        SELECT network_name,created_ts
        FROM dc1.events
        WHERE event_id = %s;
        """
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        cursor.execute(query, (event_id,))
        event = cursor.fetchone()
        cursor.close()
        conn.close()

        if not event:
            raise HTTPException(status_code=404, detail="Event not found.")

        network_name = event[0]
        created_ts=event[1]
        

        # Fetch data      
        ci_based_rfcs_events=get_ci_based_rfcs(network_name,rfc_filter,created_ts)
        
        print("ci_based_rfcs_events",ci_based_rfcs_events)
        
        # Return all combined data
        result= {
            "network_name": network_name,
            "ci_based_rfcs_events":ci_based_rfcs_events
        }
        return {"message": "Successfully returned the data",
                            "data":result}
    except Exception as e:
        return {
            "status_code": 400,
            "message": "Error fetching data",
            "details": str(e)
        }
    
    

