
import requests
import json
from sentence_transformers import SentenceTransformer
from typing import List
import boto3
from botocore.exceptions import ClientError
import os
from dotenv import load_dotenv

from routers.universal.vox import IASOpenaiEmbeddings

if os.getenv("opensearch_secret") is None:
    load_dotenv()

def get_secret():

    secret_name = os.getenv("opensearch_secret")
    region_name = "us-east-1"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        # For a list of exceptions thrown, see
        # https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
        raise e

    secret = get_secret_value_response['SecretString']
    #a = get_secret_value_response['SecretString']['OpenAI']
    return secret

# OpenSearch Configuration
access_json = json.loads(get_secret())
opensearch_host = access_json['opensearch_host']
index_name = 'chunked_embeddings_vox1'
headers = {"Content-Type": "application/json"}
username = access_json['username']
password = access_json['password']
auth = (username, password) 

# Initialize the embedding model
model = IASOpenaiEmbeddings(engine="text-embedding-ada-002")

def knn_response(query_text, index_name, fields, k, condtn, score):
        search_query = {
                        "size": k,
                        "sort": [{ "_seq_no": "desc" } ],
                            "query": {
                                "bool": {
                                "should": [
                                    {
                                    "multi_match": {
                                        "query": query_text,
                                        "fields": fields,
                                        "type": "phrase",
                                        "minimum_should_match": score,
                                    }
                                    },
                                    {
                                    "multi_match": {
                                        "query": query_text,
                                        "fields": fields,
                                        "type": "cross_fields",
                                        "operator": condtn,
                                        "analyzer": "stop",
                                        "minimum_should_match": score
                                    }
                                    }
                                ],
                                "minimum_should_match": 1
                                }
                            }
                        }
        response = requests.post(
            f"{opensearch_host}/{index_name}/_search",
            headers=headers,
            data=json.dumps(search_query),
            auth=auth)
        return response



# Function to perform k-NN search
def knn_search(query_text: str, index_name: str, fields, k: int = 3,  sparse_weight: float = 0.5, condtn: str = "and"):
    """Perform k-NN search on OpenSearch index."""
    
    def get_titles(response):
        """Extracts titles from the response if hits are found."""
        return [hit["_source"]["title"] for hit in response.get("hits", {}).get("hits", [])]

    def search_with_condition(score, condition):
        """Executes k-NN search and processes response."""
        response = knn_response(query_text, index_name, fields, k, condition, score)
        if response.status_code == 200:
            response = response.json()
            titles = get_titles(response)
            if titles:
                return titles
        else:
            print(f"Search failed: {response.status_code}, {response.text}")
        return []

    # List of fallback conditions to try
    fallback_conditions = [
        ("90%", "and"),  
        ("70%", "and"),   
        ("50%", "and"),  
        ("90%", "or"),  
        ("70%", "or"),   
        ("50%", "or"),
        ("40%", "or"),   
        ("30%", "or")   
    ]

    # Loop through fallback conditions and return the first successful result
    for acc, cond in fallback_conditions:
        titles = search_with_condition(acc, cond)
        if titles:  # If we get results, return immediately
            return titles
        print(f"No results found with {acc} accuracy and condition '{cond}', trying next...")

    # If all fallbacks fail, return an empty list
    print("All fallback attempts failed. No results found.")
    return []
