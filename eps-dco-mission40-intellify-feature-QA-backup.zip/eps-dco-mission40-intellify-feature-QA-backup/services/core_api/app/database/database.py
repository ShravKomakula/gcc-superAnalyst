import boto3
from botocore.exceptions import ClientError
from typing import Dict
from psycopg2.extras import RealDictCursor
import psycopg2
import json
import os
from dotenv import load_dotenv

# Load environment variables from .env file if not already loaded
if os.getenv("postgres_secret_name") is None:
    load_dotenv()

# Load secret name from environment variables
postgres_secret_name = os.getenv("postgres_secret_name")

# Helper to fetch secrets from AWS Secrets Manager
def get_postgres_secrets():
    secret_name = postgres_secret_name
    region_name = 'us-east-1'
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        raise e
    secret = get_secret_value_response['SecretString']
    return secret

# Establish a connection to PostgreSQL
def connect_to_postgres(db_params: Dict) -> psycopg2.extensions.connection:
    result = get_postgres_secrets()
    result_dict = json.loads(result)

    try:
        postgres_conn = psycopg2.connect(
            dbname=result_dict['dbname'],
            user=result_dict['username'],
            password=result_dict['password'],
            host=result_dict['host'],
            port=result_dict['port']
        )
        return postgres_conn
    except Exception as e:
        print(f"Error connecting to database: {e}")
        raise
