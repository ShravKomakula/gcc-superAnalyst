import uuid
import json
from dateutil import parser
import boto3
from botocore.exceptions import ClientError
import requests
import pandas as pd
import io,httpx
import uuid
import boto3
import random
from datetime import datetime, timedelta
import chromadb
import requests
import pandas as pd
import json
import warnings
warnings.simplefilter(action="ignore", category=FutureWarning)
from termcolor import colored
import os

def get_secret():
 
    secret_name = os.getenv("vox_secret_name")
    region_name = "us-east-1"
 
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
 
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        # For a list of exceptions thrown, see
        raise e
 
    secret = get_secret_value_response['SecretString']
    return secret
 
    # Your code goes here.
data=json.loads(get_secret())
 
endpointurl=data["OpenAI_URL"]
username = data["Client_ID"]
password = data["Client_Secret"]
verification_url = data["verification_url"]

mulesoft_url = endpointurl
verification_url = verification_url
client_id = username
client_secret = password
engine = "gpt-4-32k"
temperature=0.8
max_tokens=20000
 
url_chatCompletion = mulesoft_url + '/chatCompletion'
 


def llm_new_load_s3_data_to_dfs(bucket_name, folder_name):
    """
    Load CSV and Parquet files from an S3 folder into pandas DataFrames.
   
    Parameters:
    bucket_name (str): The name of the S3 bucket.
    folder_name (str): The folder path within the S3 bucket.
   
    Returns:
    dict: A dictionary where the keys are file names (without extensions) and values are DataFrames.
    """
    # Initialize S3 client
    s3 = boto3.client('s3')
   
    # List objects in the specified S3 folder
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix=folder_name)
   
    # Dictionary to store DataFrames
    dfs = {}
   
    # Check if the folder contains files
    if 'Contents' not in response:
        print(f"No files found in {folder_name}")
        return dfs
   
    # Loop through the files in the folder
    for obj in response['Contents']:
        file_key = obj['Key']
       
        # Skip directories or non-data files
        if file_key.endswith('/'):
            continue
       
        # Extract file name without folder path
        file_name = file_key.split('/')[-1]
        file_name_without_ext = file_name.split('.')[0]
       
        # Read CSV or Parquet files into DataFrames
        if file_name.endswith('.csv'):
            obj = s3.get_object(Bucket=bucket_name, Key=file_key)
            dfs[file_name_without_ext] = pd.read_csv(io.BytesIO(obj['Body'].read()))
        elif file_name.endswith('.parquet'):
            obj = s3.get_object(Bucket=bucket_name, Key=file_key)
            dfs[file_name_without_ext] = pd.read_parquet(io.BytesIO(obj['Body'].read()))
   
    return dfs
 
def generate_token():
    '''
    Generates the Bearer token needed for OpenAI API authentication. Returns the Bearer token as a string.
    '''
    try:
        url = f"{verification_url}"
        payload = f"client_id={client_id}&client_secret={client_secret}"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        response = requests.request("POST", url, headers=headers, data=payload)
        token = response.json()["access_token"]
        return "Bearer " + token
 
    except Exception as e:
        return {
            "status": "error",
            "data": e,
            "message": e.orig.args if hasattr(e, "orig") else f"{e}",
        }
 


async def llm_incident_triage_response(data):
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages": [
                    {
                        "role": "system",
                        "content": """
                       You are a Senior global command center Analyst/Expert. Review the incident and provide a clear overview summary in 170 words that includes:

                       Brief description of the core problem, impacted systems. This summary should help take a decision whether to initiate a major event or not.
                       
                       Summarize in a way that gives clear situational awareness to the team and make sure to include the incident number at the top of the response as well as a brief summary of the incident description.
                       
                       Make sure to begin the response with the incident number at the top and a brief summary of the incident description.
                       
                       Add: Present a suggested action item in a separate final paragraph.     
                        """,
                    },
                    {
                        "role": "user",
                        "content": 'give me the triage analysis of the following: Incident :' + data,
                    }
                ],
                "temperature":temperature,
                "max_tokens":20000
            }
 
    text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
    # async with httpx.AsyncClient(timeout=40.0) as client:
    #     text_response = await client.post(url=url_chatCompletion, headers=headers, json=payload)
    print("VOX IC INITIAL API:", text_response.json())
    try:
        result_json = json.loads(text_response.json()['result'])
        #result = json.loads(text_response.json()['result'])
        result = result_json['content']
        totalTokens = text_response.json()['totalTokens']
 
    except KeyError:
        result = None
        totalTokens=None
        
 
    return result,totalTokens


 
async def llm_new_vox_triage_response(data):
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages": [
                    {
                        "role": "system",
                        "content": """
                        As a GCC analyst, assess this application following EXACTLY this format:
 
                       The critical network details for triaging include:
                       1. Logical Name: 
                       2. Network Name: 
                       3. Relationship Subtype:
                       4. I Status: 
                       5. Usage: 
                       6. Type: 
                       7. Subtype: 
                       8. Added Time:
                       9. Operating System: 
                       10. Location:
                       11. Assignment:
                       12. CI Primary Contact:
                       13. CI Contacts: 
                       14. ESC Assignment:
                       15. Site Category: 
                       16. Time Zone: 
                       17. Corporate Structure: 
                       18. Aliases: 
                       19. Related Logical Names: 
                       20. Related Network Names: 
                       21. Description:
                        
                        
                        """,
                    },
                    {
                        "role": "user",
                        "content": 'What are the critical network details for triaging? CI Details :' + data,
                    }
                ],
                "temperature":temperature,
                "max_tokens":20000
            }
 
    text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
    # async with httpx.AsyncClient(timeout=40.0) as client:
    #     text_response = await client.post(url=url_chatCompletion, headers=headers, json=payload)
    #print("VOX TRIAGE API:", text_response.json())
    try:
        result_json = json.loads(text_response.json()['result'])
        result = json.loads(text_response.json()['result'])
        #result = result_json['content']
        totalTokens = text_response.json()['totalTokens']
 
    except KeyError:
        result = None
        totalTokens=None
        
 
    return result,totalTokens
 

''' 
GetSecretValue - AWS Secrets Manager
Retrieves the contents of the encrypted fields SecretString or SecretBinary from the specified version of a secret, whichever contains content.'''
 
#Prompt for root cause analysis:
async def llm_new_vox_rca_response(issue):
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload ={
                "engine": engine,
                "messages":[
                    {"role": "system",
                        "content":"""
                        #context#
                        This is a ROOT CAUSE ANALYZER AI system that determines the root cause by analyzing the given incident and RFC (Request for Change) data.

                        The system identifies the root cause based on Incidents and RFCs considering the following factors:

                        Location
                        Events
                        Assignment Groups
                        Device Type
                        Upstream and Downstream Dependencies
                        # Objective#
                        Evaluate the given user incident and determine the root cause by analyzing previous incidents and RFC data based on:

                        Location
                        Events
                        Assignment Groups
                        Device Type
                        Upstream and Downstream Dependencies
                        The analysis should be strictly derived from the given data without introducing fabricated information.

                        # Style#
                        The response should be clear, concise, and self-contained while maintaining completeness.
                        The output should logically connect the findings to the given data.
                        Ensure clarity in explaining the root cause without unnecessary assumptions.
                        # Tone#
                        The response should be neutral and fact-based, accurately capturing the essence of the original incident.
                        The explanation should be professional and actionable for the resolution team.
                        # Audience#
                        The audience is the ticket resolution team, who will use this analysis to diagnose and resolve the issue efficiently.

                        # Response#
                        The response should be in string format and contain a structured root cause analysis based on:

                        Location
                        Events
                        Assignment Groups
                        Device Type
                        Upstream and Downstream Dependencies
                        The response should be strictly based on the provided data. Do not introduce external assumptions or hallucinate responses.

                        Below is an example for reference. Do not output the same response.
                        Issue: AGILE MANUFACTURING PRODUCTION SYSTEM

                        Data Provided:
                        {
                        "downstream": [
                            {
                            "LOGICAL_NAME": "SC3195092",
                            "NETWORK_NAME": "EMARINW077",
                            "R_LOGICAL_NAME": "SC3157596",
                            "R_NETWORK_NAME": "AGILE MANUFACTURING PRODUCTION SYSTEM (AMPS) (PGS) - 7.7.0 - RINGASKIDDY API - PRODUCTION",
                            "STATUS": "Active",
                            "RESOLUTION": "One of the dependencies, procurement from ABC manufacture, was delayed. Plan procurement in advance."
                            }
                        ],
                        "Same_network_Events": [],
                        "Same_network_Incidents": [
                            {
                            "NUMBERPRGN": "IM44892527",
                            "STATUS": "closed",
                            "OPEN_TIME": "2024-09-26T08:11:07",
                            "NETWORK_NAME": "EMARINW077",
                            "BRIEF_DESCRIPTION": "CPU utilization is above threshold in Host EMARINW077",
                            "LOCATION": "VENDOR-INDIA - NON PFIZER BASED"
                            },
                            {
                            "NUMBERPRGN": "IM44820803",
                            "STATUS": "closed",
                            "OPEN_TIME": "2024-09-04T11:52:16",
                            "NETWORK_NAME": "EMARINW077",
                            "BRIEF_DESCRIPTION": "Dynatrace Problem Alert: Network availability monitor global outage for Network availability monitor EMARINW077: EBRDistributedEventSheet 17084 Status: P-240937412",
                            "LOCATION": "GROTON"
                            }
                        ]
                        }

                        LLM Response for the given data:
                        Root Cause Analysis:

                        - **Location-based Cause:** The issue is observed across multiple locations, including "VENDOR-INDIA - NON PFIZER BASED" and "GROTON." This suggests a broader network/system impact rather than an isolated problem.

                        - **Event-based Cause:** No events were recorded in the provided data, indicating that external triggers such as maintenance or security issues may not be contributing factors.

                        - **Assignment Group-related Cause:** No assignment group details are provided. If available, historical trends of responsible teams could help identify recurring patterns.

                        - **Device Type-related Cause:** The CPU utilization exceeding the threshold in "EMARINW077" suggests a potential performance issue due to high resource consumption. This could indicate excessive load, insufficient resource allocation, or process inefficiencies.

                        - **Upstream & Downstream Cause:** A **critical dependency in procurement** from "ABC manufacture" was delayed, directly impacting the "AGILE MANUFACTURING PRODUCTION SYSTEM." Addressing **procurement scheduling and supply chain optimization** can mitigate future disruptions.

                        **Recommendation:**  
                        Prioritize procurement planning and analyze CPU performance trends to optimize system stability.

                        """
                    },
                    {
                        "role": "user",
                        "content": "What are the similar issue for the below issue and data_provided. issue :" + issue  ,
                         
                    }
                ],
                "temperature":temperature,
                "max_tokens":20000
            }
 
    #print("payload to llm",payload)
    #text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
    async with httpx.AsyncClient(timeout=200.0) as client:
        text_response = await client.post(url=url_chatCompletion, headers=headers, json=payload)
    #print("VOX RCA :", text_response.json())
    try:
        result_json = json.loads(text_response.json()['result'])
        result = json.loads(text_response.json()['result'])
        #result = result_json['content']
        totalTokens = text_response.json()['totalTokens']
 
    except KeyError:
        result = None
        totalTokens=None
 
    return result,totalTokens


#Prompt for probable root cause
async def llm_new_vox_prc_response(issue):
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages":[
                    {"role": "system",
                        "content": """#context#
                    This is PROBABLE ROOT CAUSE AI system that determines lIST OUT THE PROBABLE root causes,their possible related record(from given data),recommended team engagement,recommended remediation steps and likelihood percentage of the root cause  by understanding given incident and similar or past incidents data.
                    #########

                    # Objective#
                    Evaluate the given user incident and determine probable root causes by analyzing the previous ticket data.and select only similar incidents for Probable root cause 
                    #########

                    # Style#
                    The response should be clear, concise, self contained, while maintaining the intent which has to include all the necessary information 
                    #########

                    #Tone#
                    Neutral and focused on accurately capturing the essence of the original incident and conclude from similar incidents
                    #########

                    #Audience#
                    The Audience is the ticket resolving team.
                    #########

                    #Response#
                    response shall be in the list format only, shall not be in string format. Dont consider no rfcs or no incidents as probable root causes.

                        below is the example for your reference, dont output the same:

                        issue: Wireless issues impacting packaging operations at Freiburg, Germany

                    data_provided : {"downstream": [],
                    "Same_network_Events": [],
                    "Same_network_Incidents": [
                        {
                        "NUMBERPRGN": "IM44892527",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARINW077",
                        "BRIEF_DESCRIPTION": "ALL LogOS handheld scanners of the AFF do not have a connection",
                        "LOCATION": "VENDOR-INDIA - NON PFIZER BASED"
                        },
                        {
                        "NUMBERPRGN": "IM44892327",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARIW077",
                        "BRIEF_DESCRIPTION": "Wireless issues in packing",
                        "LOCATION": "VENDOR-INDIA - NON PFIZER BASED",
                        "ASSIGNEE_NAME": "Shiva"
                        }]
                    "RFC":[{
                        "ID": "CR2374458",
                        "STATUS": "WORK IN PROGRESS ",
                        "OPEN_TIME": "2024-09-04T11:52:16",
                        "NETWORK_NAME": "EMARINW077",
                        "BRIEF_DESCRIPTION": "FRE-FREIBUR,GERMANY- MIGRATE wireless access points to a new wireless LAN controller",
                        "LOCATION": "GERMANY"
                        }]
                    ],
}
                    llm response for above example : [{"Title":"High network Utilization","Possible_Related_Record":[{"Confidence":95,"ID":"CR2374458","Description":"FRE-FREIBUR,GERMANY- MIGRATE wireless access points to a new wireless LAN controller","Type":"RFC"},{"Confidence":95,"ID":"IM44892327","Description":"Wireless issues in packing","Type":"Incidents"}],"Recommended_Team_Engagement":[{"Confidence":95,"Name":"Shiva","Title":"Wireless issues in packing"}],"Recommended_Remediation_Steps":["Review any recent change Requests(RFC)","Check the access points","Restart the system"],"likelihood":98},
                    {"Title":"Recurring alerts","Possible_Related_Record":[{pull the evidance from the data to justify probable root cause}],"Recommended_Team_Engagement":[],"Recommended_Remediation_Steps":[],"likelihood":60},
                    {"Title":"Issues iwth AT&T Link","Possible_Related_Record":[{pull the evidance from the data to justify probable root cause}],"Recommended_Team_Engagement":[],"Recommended_Remediation_Steps":[],"likelihood":20},
                    {"Title":"Incorrect network configuration","Possible_Related_Record":[{pull the evidance from the data to justify probable root cause}],"Recommended_Team_Engagement":[],"Recommended_Remediation_Steps":[],"likelihood":14},
                    {"Title":"Problem with physical connects","Possible_Related_Record":[{pull the evidance from the data to justify probable root cause}],"Recommended_Team_Engagement":[],"Recommended_Remediation_Steps":[],"likelihood":10},
                    {"Title":"Potential damage to network Infrastucture","Possible_Related_Record":[{pull the evidance from the data to justify probable root cause}],"Recommended_Team_Engagement":[],"Recommended_Remediation_Steps":[],"likelihood":8}]
                        """
                    },
                    {
                        "role": "user",
                        "content": "What are the similar issue for the below issue and data_provided. issue :" + issue  ,
                         
                    }
                ],
                "temperature":temperature,
                "max_tokens":20000
            }
 
    #print("payload to llm",payload)
    #text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
    async with httpx.AsyncClient(timeout=200.0) as client:
        text_response = await client.post(url=url_chatCompletion, headers=headers, json=payload)
    #print("VOX PRC  :       ", text_response.json())
    try:
        result_json = json.loads(text_response.json()['result'])
        result = result_json['content']
        totalTokens = text_response.json()['totalTokens']
 
    except KeyError:
        result = None
        totalTokens=None
 
    return result,totalTokens

#Prompt for simliar incidents in Location:
async def llm_new_vox_location(issue):
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages":[
                    {"role": "system",
                        "content": """#context#
                   This is required to analyze the issue if it is similar or keyword match to incidents and related  to Request for Change(RFC) records that is rfc have caused the incident.The similar or keyword match incidents and rfc should have the confidence score in the output. confidence score should be strictly calculated based on the similarity or keyword match.
                More focus should be on Approved or Completed RFCs status.  New status would be weighted less in the consideration in RFC.A change could potentially be completed before an RFC is created or approved.

                    #########

                    # Objective#
                    Evaluate the issue is similar to any  incidents and whether any RFCs may have caused the incident. Provide an inference indicating whether the incident is likely caused in the location or by the RFC . 
                    #########

                    # Style#
                    The response should be clear, concise, self contained, while maintaining the intent which has to include all the necessary information 
                    #########

                    #Tone#
                    Neutral and focused on accurately capturing the essence of the original incident. If given data(incidents and rfcs) has no relation with the input issue it should output the input incident is not related to the Location.
                    #########

                    #Audience#
                    The Audience is the ticket resolving team.
                    #########

                    #Response#
                    response should be in the json format.Follow the example output resopnse. similar incidents should have following keys :  ["CONFIDENCE_SCORE","NUMBERPRGN", "STATUS", "OPEN_TIME", "NETWORK_NAME","ASSIGNMENT, "BRIEF_DESCRIPTION", "LOCATION"]
                    and similar rfc should have following keys  rfc:  ["CONFIDENCE_SCORE","RFC", "STATUS","OPEN_TIME","NETWORK_NAME", "ASSIGN_DEPT", "BRIEF_DESCRIPTION", "LOCATION"]. no duplicate incidents and rfcs to be outputed in output json response.

                        below is the example for your reference, dont output the same:

                        issue: Power outage affecting the east wing

                        data_provided : {"INCIDENTS": [
                        {
                        "NUMBERPRGN": "IM3195092",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT": "SC3157596",
                        "BRIEF_DESCRIPTION": "power failure in the west wing",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                       {
                        "NUMBERPRGN": "IM3195992",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW177",
                        "ASSIGN_DEPT": "SC3157586",
                        "BRIEF_DESCRIPTION": "Heating system malfunction",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                       {
                        "NUMBERPRGN": "IM3195392",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW377",
                        "ASSIGN_DEPT": "SC3153596",
                        "BRIEF_DESCRIPTION": "network issues casuing slow connectivity",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                    ],
  
                    "RFCs": [
                        {
                        "RFC": "CR44892527",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "Installation of new power backup system",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        },
                        {
                        "RFC": "CR44820803",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-04T11:52:16",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "routine maintenance of electrical systems",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        }
                    ],
}
                    llm response for above example :{"INFERENCE":"There are very few related incidents for the location to suggest an widespread issue/outage for clients.Possible correlation may be to ticket IM3195092,rfc CR44892527 and which was created 14hrs previously, and suggests an issue with the power failure in location",
                    "INCIDENTS_BY_LOCATION": [
                        {
                        "CONFIDENCE_SCORE":95,
                        "NUMBERPRGN": "IM3195092",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT": "SC3157596",
                        "BRIEF_DESCRIPTION": "power failure in the west wing",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       }],
                       "RFCS_BY_LOCATION": [
                        {
                        "CONFIDENCE_SCORE":90,
                        "RFC": "CR44892527",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "Installation of new power backup system",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        }]
                       }
                   
                    
                        dont hallucinate the output response. it should be only from the data provided 
                        """
                    },
                    {
                        "role": "user",
                        "content": "What are the similar issue for the below issue and data_provided. issue :" + issue  ,
                         
                    }
                ],
                "temperature":temperature,
                "max_tokens":20000
            }
 
    #print("payload to llm",payload)
    #text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
    async with httpx.AsyncClient(timeout=200.0) as client:
        text_response = await client.post(url=url_chatCompletion, headers=headers, json=payload)
    #print("VOX Location :     ", text_response)
    try:
        result_json = json.loads(text_response.json()['result'])
        result = result_json['content']
        totalTokens = text_response.json()['totalTokens']
 
    except KeyError:
        result = None
        totalTokens=None
 
    return result,totalTokens

#Prompt for simliar events:
async def llm_new_vox_Events(issue):
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages":[
                    {"role": "system",
                        "content": """#context#
                    This required to analyze the issue in similar to events. Your task is to determine if the new incidents is similar to any recent events.The similar events must have the confidence score in the output.confidence score should be strictly calculated based on the similarity.
                    #########

                    # Objective#
                    Evaluate the issue is similar to events . Provide an inference indicating whether the incident is likely caused and made it a event. 
                    #########

                    # Style#
                    The response should be clear, concise, self contained, while maintaining the intent which has to include all the necessary information 
                    #########

                    #Tone#
                    Neutral and focused on accurately capturing the essence of the original incident. If given data(events) has no relation with the input issue it should output the input incident is not related to the events. follow the tone strictly. 
                    #########

                    #Audience#
                    The Audience is the ticket resolving team.
                    #########

                    #Response#
                    response should be in the JSON format. response should follow the example response style

                        below is the example for your reference, dont output the same:

                        issue: Power outage affecting the east wing

                        data_provided : {"Same_network_Events": [
                        {
                        "event_id": 52427,
                        "description": "apt-01-00-cr-sws-2.pfizer.com Down",
                        "created_time": "2024-10-27T13:25:25.967000",
                        "responsible_service_area": "Network - Data - LAN",
                        "event_title": "Network Stackable switch is unreachable at Algeris, Algeria",
                        "config_item_id": "SC3095323",
                        "network_name": "APT-01-00-CR-SWS-2"
                       },
                       {
                        "event_id": 53427,
                        "description": "apt-01-00-cr-sws-2.pfizer.com Down",
                        "created_time": "2024-10-27T13:25:25.967000",
                        "responsible_service_area": "Network - Data - LAN",
                        "event_title": "Network Stackable switch is unreachable at India",
                        "config_item_id": "SC3095323",
                        "network_name": "APT-01-00-CR-SWS-2"
                       },
                       {
                        "event_id": 55427,
                        "description": "apt-01-00-cr-sws-2.pfizer.com Down",
                        "created_time": "2024-10-27T13:25:25.967000",
                        "responsible_service_area": "Network - Data - LAN",
                        "event_title": "power outage restoring",
                        "config_item_id": "SC3095323",
                        "network_name": "APT-01-00-CR-SWS-2"
                       },
                    ]
}
                    llm response for above example :{"INFERENCE":"There is a related Event for the issue to which was created 8 day previously, and suggests an issue with the power failure in location",
                    "data":[{
                        "confidence_score":90,
                        "event_id": 55427,
                        "description": "apt-01-00-cr-sws-2.pfizer.com Down",
                        "created_time": "2024-10-27T13:25:25.967000",
                        "responsible_service_area": "Network - Data - LAN",
                        "event_title": "power outage restoring",
                        "config_item_id": "SC3095323",
                        "network_name": "APT-01-00-CR-SWS-2"
                       }]


                        dont hallucinate the output response. it should be only from the data provided 
                        """
                    },
                    {
                        "role": "user",
                        "content": "What are the similar issue for the below issue and data_provided. issue :" + issue  ,
                         
                    }
                ],
                "temperature":temperature,
                "max_tokens":20000
            }
 
    #print("payload to llm",payload)
    #text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
    async with httpx.AsyncClient(timeout=200.0) as client:
        text_response = await client.post(url=url_chatCompletion, headers=headers, json=payload)
    #print("VOX Events :     ", text_response.json())
    try:
        result_json = json.loads(text_response.json()['result'])
        result = result_json['content']
        totalTokens = text_response.json()['totalTokens']
 
    except KeyError:
        result = None
        totalTokens=None
 
    return result,totalTokens

 
#Prompt for simliar incidents in Location:
async def llm_new_vox_app_server(issue):
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages":[
                    {"role": "system",
                        "content": """#context#
                    This is required to analyze the issue in relation to  incidents and associated all Request for Change(RFC) records. Your task is to determine if the new incidents is similar to any  incidents and whether any RFCs may have caused the incident.The similar incidents and rfc should have the confidence score in the output.confidence score should be strictly calculated based on the similarity.
                    More focus should be on Approved or Completed RFCs status.  New status would be weighted less in the consideration in RFC.A change could potentially be completed before an RFC is created or approved.

                    #########

                    # Objective#
                    Evaluate the issue is similar to any  incidents and whether any RFCs may have caused the incident. Provide an inference indicating whether the incident is likely caused in any server or application. 
                    #########

                    # Style#
                    The response should be clear, concise, self contained, while maintaining the intent which has to include all the necessary information 
                    #########

                    #Tone#
                    Neutral and focused on accurately capturing the essence of the original incident. If given data(incidents and rfcs) has no relation with the input issue it should output the input incident is not related to the Location. Follow the tone strictly
                    #########

                    #Audience#
                    The Audience is the ticket resolving team.
                    #########

                    #Response#
                    response should be in the json format. response should follow example output style. similar incidents should have following keys :  ["CONFIDENCE_SCORE","NUMBERPRGN", "STATUS", "OPEN_TIME", "NETWORK_NAME","ASSIGNMENT, "BRIEF_DESCRIPTION", "LOCATION"]
                    and similar rfc should have following keys  rfc:  ["CONFIDENCE_SCORE","RFC", "STATUS","OPEN_TIME","NETWORK_NAME", "ASSIGN_DEPT", "BRIEF_DESCRIPTION", "LOCATION"]. no duplicate incidents and rfcs to be outputed in output json response.


                        below is the example for your reference, dont output the same:

                        issue: Power outage affecting the east wing

                        data_provided : {"INCIDENTS": [
                        {
                        "NUMBERPRGN": "IM3195092",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT": "SC3157596",
                        "BRIEF_DESCRIPTION": "power failure in the west wing",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                       {
                        "NUMBERPRGN": "IM3195992",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW177",
                        "ASSIGN_DEPT": "SC3157586",
                        "BRIEF_DESCRIPTION": "Heating system malfunction",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                       {
                        "NUMBERPRGN": "IM3195392",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW377",
                        "ASSIGN_DEPT": "SC3153596",
                        "BRIEF_DESCRIPTION": "network issues casuing slow connectivity",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                    ],
  
                    "RFCS": [
                        {
                        "RFC": "CR44892527",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "Installation of new power backup system",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        },
                        {
                        "RFC": "CR44820803",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-04T11:52:16",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "routine maintenance of electrical systems",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        }
                    ],
}
                    llm response for above example :{"INFERENCE":"There are very few related incidents for the location to suggest an widespread issue/outage for clients.Possible correlation may be to ticket IM3195092,rfc CR44892527 and which was created 14hrs previously, and suggests an issue with the power failure in location",
                    "INCIDENTS_BY_APP_SERVER": [
                        {
                        "CONFIDENCE_SCORE":95,
                        "NUMBERPRGN": "IM3195092",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT": "SC3157596",
                        "BRIEF_DESCRIPTION": "power failure in the west wing",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       }],
                       "RFCS_BY_APP_SERVER": [
                        {
                        "CONFIDENCE_SCORE":90,
                        "RFC": "CR44892527",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "Installation of new power backup system",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        }]
                       }

                        dont hallucinate the output response. it should be only from the data provided 
                        """
                    },
                    {
                        "role": "user",
                        "content": "What are the similar issue for the below issue and data_provided. issue :" + issue  ,
                         
                    }
                ],
                "temperature":temperature,
                "max_tokens":20000
            }
 
    #print("payload to llm",payload)
    #text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
    async with httpx.AsyncClient(timeout=200.0) as client:
        text_response = await client.post(url=url_chatCompletion, headers=headers, json=payload)
    #print("VOX Network :    ", text_response.json())
    try:
        result_json = json.loads(text_response.json()['result'])
        result = result_json['content']
        totalTokens = text_response.json()['totalTokens']
 
    except KeyError:
        result = None
        totalTokens=None
 
    return result,totalTokens

#Prompt for simliar incidents assign groups:
async def llm_new_vox_assign_group(issue):
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages":[
                    {"role": "system",
                        "content": """#context#
                    This is required to analyze the issue in relation to incidents and associated all Request for Change(RFC) records. Your task is to determine if the new incidents is similar to any  incidents and whether any RFCs may have caused the incident..The similar incidents and rfc should have the confidence score in the output.confidence score should be strictly calculated based on the similarity.
                    More focus should be on Approved or Completed RFCs status.  New status would be weighted less in the consideration in RFC.A change could potentially be completed before an RFC is created or approved.

                    #########

                    # Objective#
                    Evaluate the issue is similar to any  incidents and whether any RFCs may have caused the incident. Provide an inference indicating whether the incident is likely caused and assigned to any group. 
                    #########

                    # Style#
                    The response should be clear, concise, self contained, while maintaining the intent which has to include all the necessary information 
                    #########

                    #Tone#
                    Neutral and focused on accurately capturing the essence of the original incident. If given data(incidents and rfcs) has no relation with the input issue it should output the input incident is not related to the Location. strictly follow the tone
                    #########

                    #Audience#
                    The Audience is the ticket resolving team.
                    #########

                    #Response#
                    response should be in the json format. response shall follow the example output style. The picked similar incidents should have following keys :  ["CONFIDENCE_SCORE","NUMBERPRGN", "STATUS", "OPEN_TIME", "NETWORK_NAME","ASSIGNMENT, "BRIEF_DESCRIPTION", "LOCATION"]
                    and The picked similar rfc should have following keys  rfc:  ["CONFIDENCE_SCORE","RFC", "STATUS","OPEN_TIME","NETWORK_NAME", "ASSIGN_DEPT", "BRIEF_DESCRIPTION", "LOCATION"]. no duplicate incidents and rfcs to be outputed in output json response.


                        below is the example for your reference, dont output the same:

                        issue: Power outage affecting the east wing

                        data_provided : {"INCIDENTS": [
                        {
                        "NUMBERPRGN": "IM3195092",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT": "SC3157596",
                        "BRIEF_DESCRIPTION": "power failure in the west wing",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                       {
                        "NUMBERPRGN": "IM3195992",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW177",
                        "ASSIGN_DEPT": "SC3157586",
                        "BRIEF_DESCRIPTION": "Heating system malfunction",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                       {
                        "NUMBERPRGN": "IM3195392",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW377",
                        "ASSIGN_DEPT": "SC3153596",
                        "BRIEF_DESCRIPTION": "network issues casuing slow connectivity",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                    ],
  
                    "RFCS": [
                        {
                        "RFC": "CR44892527",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "Installation of new power backup system",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        },
                        {
                        "RFC": "CR44820803",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-04T11:52:16",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "routine maintenance of electrical systems",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        }
                    ],
}
                    llm response for above example :{"INFERENCE":"There are very few related incidents for the network to suggest an widespread issue/outage for clients.Possible correlation may be to ticket IM3195092,rfc CR44892527 and which was created 14hrs previously, and suggests an issue with the power failure in location",
                    "INCIDENTS_BY_ASSIGN_GROUP": [
                        {
                        "CONFIDENCE_SCORE":95,
                        "NUMBERPRGN": "IM3195092",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT": "SC3157596",
                        "BRIEF_DESCRIPTION": "power failure in the west wing",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       }],
                       "RFCS_BY_ASSIGN_GROUP": [
                        {
                        "CONFIDENCE_SCORE":90,
                        "RFC": "CR44892527",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "Installation of new power backup system",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        }]

                       }
                    
                    

                        dont hallucinate the output response. it should be only from the data provided 
                        """
                    },
                    {
                        "role": "user",
                        "content": "What are the similar issue for the below issue and data_provided. issue :" + issue  ,
                         
                    }
                ],
                "temperature":temperature,
                "max_tokens":20000
            }
 
    print("payload to llm done")
    #text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)

    async with httpx.AsyncClient(timeout=200.0) as client:
        text_response = await client.post(url=url_chatCompletion, headers=headers, json=payload)
    print("--------------------------------VOX Assign Group :   ", text_response.json())
    try:
        result_json = json.loads(text_response.json()['result'])
        result = result_json['content']
        totalTokens = text_response.json()['totalTokens']
 
    except KeyError:
        result = None
        totalTokens=None
 
    return result,totalTokens

#Prompt for simliar incidents in Location:
async def llm_new_vox_up_downstream(issue):
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages":[
                    {"role": "system",
                        "content": """#context#
                   This is required to analyze the issue if is similar to incidents and related  to Request for Change(RFC) records that is rfc have caused the incident for both upstream and downstream.The similar incidents and rfc should have the confidence score in the output.confidence score should be strictly calculated based on the similarity.
                More focus should be on Approved or Completed RFCs status.  New status would be weighted less in the consideration in RFC.A change could potentially be completed before an RFC is created or approved.

                    #########

                    # Objective#
                    Evaluate the issue is similar to any  incidents and whether any RFCs for both upstream and downstream may have caused the incident. Provide an inference indicating whether the incident is likely caused in the upstream or downstream . 
                    #########

                    # Style#
                    The response should be clear, concise, self contained, while maintaining the intent which has to include all the necessary information 
                    #########

                    #Tone#
                    Neutral and focused on accurately capturing the essence of the original incident. If given data(incidents and rfcs) has no relation with the input issue it should output the input incident is not related to the Location.
                    #########

                    #Audience#
                    The Audience is the ticket resolving team.
                    #########

                    #Response#
                    response should be in the json format.Follow the example output resopnse. similar incidents should have following keys :  ["CONFIDENCE_SCORE","NUMBERPRGN", "STATUS", "OPEN_TIME", "NETWORK_NAME","ASSIGNMENT, "BRIEF_DESCRIPTION", "LOCATION"]
                    and similar rfc should have following keys  rfc:  ["CONFIDENCE_SCORE","RFC", "STATUS","OPEN_TIME","NETWORK_NAME", "ASSIGN_DEPT", "BRIEF_DESCRIPTION", "LOCATION"]. no duplicate incidents and rfcs to be outputed in output json response.
                    response must have inference,upstream and downstream data
                        below is the example for your reference, dont output the same:

                        issue: Power outage affecting the east wing

                        data_provided :{"UPSTREAM": {"INCIDENTS": [
                        {
                        "NUMBERPRGN": "IM3195092",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT": "SC3157596",
                        "BRIEF_DESCRIPTION": "power failure in the west wing",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                       {
                        "NUMBERPRGN": "IM3195992",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW177",
                        "ASSIGN_DEPT": "SC3157586",
                        "BRIEF_DESCRIPTION": "Heating system malfunction",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                       {
                        "NUMBERPRGN": "IM3195392",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW377",
                        "ASSIGN_DEPT": "SC3153596",
                        "BRIEF_DESCRIPTION": "network issues casuing slow connectivity",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                    ],
  
                    "RFCS": [
                        {
                        "RFC": "CR44892527",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "Installation of new power backup system",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        },
                        {
                        "RFC": "CR44820803",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-04T11:52:16",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "routine maintenance of electrical systems",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        }
                    ],
                },
                "DOWNSTREAM":{"INCIDENTS": [
                        {
                        "NUMBERPRGN": "IM3195092",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT": "SC3157596",
                        "BRIEF_DESCRIPTION": "power failure in the west wing",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                       {
                        "NUMBERPRGN": "IM3195992",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW177",
                        "ASSIGN_DEPT": "SC3157586",
                        "BRIEF_DESCRIPTION": "Heating system malfunction",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                       {
                        "NUMBERPRGN": "IM3195392",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW377",
                        "ASSIGN_DEPT": "SC3153596",
                        "BRIEF_DESCRIPTION": "network issues casuing slow connectivity",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                    ],
  
                    "RFCS": [
                        {
                        "RFC": "CR44892527",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "Installation of new power backup system",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        },
                        {
                        "RFC": "CR44820803",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-04T11:52:16",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "routine maintenance of electrical systems",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        }
                    ],
}}
                    llm response for above example :{"INFERENCE":"There are very few related incidents for the upstream and downstream to suggest an widespread issue/outage for clients.Possible correlation may be to ticket IM3195092,rfc CR44892527 and which was created 14hrs previously for upstream and Possible correlation may be to ticket IM3195092,rfc CR44892527 and which was created 14hrs previously  for downstream, and suggests an issue with the upstream or downstream or application",
                    "UPSTREAM":{"INCIDENTS_BY_UPSTREAM": [
                        {
                        "CONFIDENCE_SCORE":95,
                        "NUMBERPRGN": "IM3195092",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT": "SC3157596",
                        "BRIEF_DESCRIPTION": "power failure in the west wing",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       }],
                       "RFCS_BY_UPSTREAM": [
                        {
                        "CONFIDENCE_SCORE":90,
                        "RFC": "CR44892527",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "Installation of new power backup system",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        }]},
                        "DOWNSTREAM":{"INCIDENTS_BY_DOWNSTREAM": [
                        {
                        "CONFIDENCE_SCORE":95,
                        "NUMBERPRGN": "IM3195092",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT": "SC3157596",
                        "BRIEF_DESCRIPTION": "power failure in the west wing",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       }],
                       "RFCS_BY_DOWNSTREAM": [
                        {
                        "CONFIDENCE_SCORE":90,
                        "RFC": "CR44892527",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "Installation of new power backup system",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        }]}
                       }
                   
                    
                        dont hallucinate the output response. it should be only from the data provided 
                        """
                    },
                    {
                        "role": "user",
                        "content": "What are the similar issue for the below issue and data_provided. issue :" + issue  ,
                         
                    }
                ],
                "temperature":temperature,
                "max_tokens":20000
            }
 
    #print("payload to llm",payload)
    #text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
    async with httpx.AsyncClient(timeout=200.0) as client:
        text_response = await client.post(url=url_chatCompletion, headers=headers, json=payload)
    #print("VOX UP DOWNSTREAM :      ", text_response.json())
    try:
        result_json = json.loads(text_response.json()['result'])
        result = result_json['content']
        totalTokens = text_response.json()['totalTokens']
 
    except KeyError:
        result = None
        totalTokens=None
 
    return result,totalTokens


# vox_device_type 
async def llm_new_vox_device_type(issue):
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages":[
                    {"role": "system",
                        "content": """#context#
                   This is required to analyze the issue if is similar to incidents and related  to Request for Change(RFC) records that is rfc have caused the incident.The similar incidents and rfc should have the confidence score in the output.confidence score should be strictly calculated based on the similarity.
                More focus should be on Approved or Completed RFCs status.  New status would be weighted less in the consideration in RFC.A change could potentially be completed before an RFC is created or approved.Respons4e must be in JSON format only

                    #########

                    # Objective#
                    Evaluate the issue is similar to any  incidents and whether any RFCs may have caused the incident. Provide an inference indicating whether the incident is likely caused by the incident or by the RFC . 
                    #########

                    # Style#
                    The response should be clear, concise, self contained, while maintaining the intent which has to include all the necessary information 
                    #########

                    #Tone#
                    Neutral and focused on accurately capturing the essence of the original incident. If given data(incidents and rfcs) has no relation with the input issue it shouldnot output the input incident is not related.
                    #########

                    #Audience#
                    The Audience is the ticket resolving team.
                    #########

                    #Response#
                    response shall be in the json format only.Follow the example output response. similar incidents should have following keys :  ["CONFIDENCE_SCORE","NUMBERPRGN", "STATUS","TYPE", "OPEN_TIME", "NETWORK_NAME","ASSIGNMENT, "BRIEF_DESCRIPTION", "LOCATION"]
                    and similar rfc should have following keys  rfc:  ["CONFIDENCE_SCORE","RFC", "STATUS","TYPE","OPEN_TIME","NETWORK_NAME", "ASSIGN_DEPT", "BRIEF_DESCRIPTION", "LOCATION"]. no duplicate incidents and rfcs to be outputed in output json response.

                    dont hallucinate the output response. it should be only from the data provided and response shall be in the above json format only no need of any key for response. NO need of pointer in the response

                        below is the example for your reference, dont output the same:

                        issue: Power outage affecting the east wing

                        data_provided : {"INCIDENTS": [
                        {
                        "NUMBERPRGN": "IM3195092",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW077",
                        "TYPE": "APPLICATION",
                        "ASSIGN_DEPT": "SC3157596",
                        "BRIEF_DESCRIPTION": "power failure in the west wing",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                       {
                        "NUMBERPRGN": "IM3195992",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW177",
                        "TYPE": "APPLICATION",
                        "ASSIGN_DEPT": "SC3157586",
                        "BRIEF_DESCRIPTION": "Heating system malfunction",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                       {
                        "NUMBERPRGN": "IM3195392",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW377",
                        "TYPE": "APPLICATION",
                        "ASSIGN_DEPT": "SC3153596",
                        "BRIEF_DESCRIPTION": "network issues casuing slow connectivity",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       },
                    ],
  
                    "RFCS": [
                        {
                        "RFC": "CR44892527",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARINW077",
                        "TYPE": "APPLICATION",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "Installation of new power backup system",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        },
                        {
                        "RFC": "CR44820803",
                        "STATUS": "closed",
                        "OPEN_TIME": "2024-09-04T11:52:16",
                        "NETWORK_NAME": "EMARINW077",
                        "TYPE": "APPLICATION",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "routine maintenance of electrical systems",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        }
                    ]
}
                    llm response for above example is : {"INFERENCE":"There are very few related incidents for the TYPE to suggest an widespread issue/outage for clients.Possible correlation may be to ticket IM3195092,rfc CR44892527 and which was created 14hrs previously, and suggests an issue with the power failure in location",
                    "INCIDENTS_BY_DEVICE_TYPE": [
                        {
                        "CONFIDENCE_SCORE":95,
                        "NUMBERPRGN": "IM3195092",
                        "TYPE": "APPLICATION",
                        "OPEN_TIME": "01-01-2024",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT": "SC3157596",
                        "BRIEF_DESCRIPTION": "power failure in the west wing",
                        "STATUS": "Active",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                       }],
                       "RFCS_BY_DEVICE_TYPE": [
                        {
                        "CONFIDENCE_SCORE":90,
                        "RFC": "CR44892527",
                        "STATUS": "closed",
                        "TYPE": "APPLICATION",
                        "OPEN_TIME": "2024-09-26T08:11:07",
                        "NETWORK_NAME": "EMARINW077",
                        "ASSIGN_DEPT":"SC3153596",
                        "BRIEF_DESCRIPTION": "Installation of new power backup system",
                        "LOCATION": "India",
                        "CI_NAME": 'SC2298823'
                        }]
                       }
                   
                        
                        """
                    },
                    {
                        "role": "user",
                        "content": "What are the similar issue for the below issue and data_provided. issue :" + issue  ,
                         
                    }
                ],
                "temperature":temperature,
                "max_tokens":20000
            }
 
    #print("payload to llm",payload)
    #text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
    async with httpx.AsyncClient(timeout=200.0) as client:
        text_response = await client.post(url=url_chatCompletion, headers=headers, json=payload)
    try:
        result_json = json.loads(text_response.json()['result'])
        result = result_json['content']
        totalTokens = text_response.json()['totalTokens']
 
    except KeyError:
        result = None
        totalTokens=None
 
    return result,totalTokens


# summary of summary
async def llm_new_vox_summary(issue):
    token = generate_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages":[
                    {"role": "system",
                        "content": """#context#
                    This is required to summarise the incidents records and Request for Change(RFC) records with respective to location,events,assigned groups,application_server
                    #########

                    # Objective#
                    summarise the incident and RFC is similar to the title and Provide an inference indicating whether the incident is likely caused by RFC . 
                    #########

                    # Style#
                    The response should be clear, concise, self contained, while maintaining the intent which has to include all the necessary information 
                    #########

                    #Tone#
                    Neutral and focused on accurately capturing the essence of the original incident. If given data(incidents and rfcs) has no relation with the input issue it should output the input incident is not related to the Location. strictly follow the tone
                    #########

                    #Audience#
                    The Audience is the ticket resolving team.
                    #########

                    #Response#
                    response should be in the string format.
                    Summary shall be consists of overall summary and followed by individual summary as paragraph for each case having headers as location,events,assignment groups,application_Infrastructure,upstream and downstream, device type.
                    All headings or sub heading should be in Capital letters. no astric or hastags required
                    If for any case no data or no similar data, then combine those headers and say "no data" in a single line.
                    overall summary must appear first and later followed by individual summary.
                    
                        

                        dont hallucinate the output response. it should be only from the data provided 
                        """
                    },
                    {
                        "role": "user",
                        "content": "summarize data_provided based on issue." + issue  ,
                         
                    }
                ],
                "temperature":temperature,
                "max_tokens":20000
            }
 
    #print("payload to llm",payload)
    #text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
    async with httpx.AsyncClient(timeout=200.0) as client:
        text_response = await client.post(url=url_chatCompletion, headers=headers, json=payload)
    #print("VOX SUMMARY:     ", text_response.json())
    try:
        result_json = json.loads(text_response.json()['result'])
        result = json.loads(text_response.json()['result'])
        #result = result_json['content']
        totalTokens = text_response.json()['totalTokens']
 
    except KeyError:
        result = None
        totalTokens=None
 
    return result,totalTokens
