from database.database import connect_to_postgres,get_postgres_secrets

# Function to fetch incident details
def fetch_events(event_id: int):
    query = """
    SELECT network_name
    FROM dc1.events
    WHERE event_id = %s;
    """
    conn = connect_to_postgres({})  # Use your existing connection function
    cursor = conn.cursor()
    cursor.execute(query, (event_id,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result
