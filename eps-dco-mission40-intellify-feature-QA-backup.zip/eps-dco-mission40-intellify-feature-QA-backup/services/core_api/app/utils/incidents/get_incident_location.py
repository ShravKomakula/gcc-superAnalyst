import traceback
from database.database import connect_to_postgres,get_postgres_secrets
from datetime import datetime, timedelta
from ..utils import get_days_hours


def get_incident_location(network_name, incident_filter, rfc_filter,open_time):
    try:
        print("incident_filter",incident_filter)
        print("rfc_filter",rfc_filter)
        
        # Fetch the latest location
        query = """
        SELECT LOCATION
        FROM itsm_owner.cis
        WHERE NETWORK_NAME = %s;
        """
        conn = connect_to_postgres({})
        cursor = conn.cursor()
        cursor.execute(query, (network_name,))
        result = cursor.fetchall()
        print("result",result)
        if result:
            result = result[0][0]
            print("result",result)
            latest_open_time=open_time
            print("latest_open_time",latest_open_time)
            incident_cutoff_time_before,incident_cutoff_time_after=get_days_hours(rfc_filter,latest_open_time)
            rfc_cutoff_time_before,rfc_cutoff_time_after=get_days_hours(incident_filter,latest_open_time)
            
            
            print("incident_cutoff_time *********************",incident_cutoff_time_before,incident_cutoff_time_after)
            print("rfc_cutoff_time ************************",rfc_cutoff_time_before,rfc_cutoff_time_after)
            
            # Build the incident query with additional date filters
            query = f""" 
            WITH RankedIncidents AS (
                SELECT
                    numberprgn,
                    status,
                    brief_description,
                    location,
                    open_time,
                    network_name,
                    ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
                FROM
                    dc1sm_ro.incidents
                WHERE
                    LOCATION = '{result}' 
                    {f"AND open_time >= '{incident_cutoff_time_before}' AND open_time <= '{incident_cutoff_time_after}'" if incident_cutoff_time_before else ''}
            )
            SELECT
                numberprgn,
                status,
                brief_description,
                location,
                open_time,
                network_name
            FROM
                RankedIncidents
            WHERE
                rn = 1
            ORDER BY
                open_time DESC
            """
            
            
            print(" query ",query)
            cursor.execute(query)
            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            print("columns",columns)
            incidents_data = [dict(zip(columns, row)) for row in rows]

            # If RFC filter is provided, apply RFC logic here, assuming similar logic to incidents
            # Assuming there's an RFC table or a way to filter RFC data by location and open_time
            if rfc_filter:
                rfc_cutoff_time_str_before = rfc_cutoff_time_before.strftime('%Y-%m-%d %H:%M:%S')
                rfc_cutoff_time_str_after = rfc_cutoff_time_after.strftime('%Y-%m-%d %H:%M:%S')
                
                rfc_query = f"""
                SELECT
                    numberprgn,
                    status,
                    description,
                    location,
                    open_time,
                    network_name
                FROM
                    dc1sm_ro.rfcs
                WHERE
                    LOCATION = '{result}' 
                    AND open_time >= '{rfc_cutoff_time_str_before}'  AND open_time <= '{rfc_cutoff_time_str_after}'
                ORDER BY
                    open_time DESC
                """
                cursor.execute(rfc_query)
                rfc_rows = cursor.fetchall()
                rfc_columns = [desc[0] for desc in cursor.description]
                rfcs_data = [dict(zip(rfc_columns, row)) for row in rfc_rows]
            else:
                rfcs_data = []

            cursor.close()
            conn.close()

            return incidents_data
        else:
            return []
    except Exception as e:
        print("Error occurred in get_incident_location  function!")
        print("Error message:", str(e))
        print("Traceback details:")
        traceback.print_exc()  # Print full traceback to see the exact line of the error