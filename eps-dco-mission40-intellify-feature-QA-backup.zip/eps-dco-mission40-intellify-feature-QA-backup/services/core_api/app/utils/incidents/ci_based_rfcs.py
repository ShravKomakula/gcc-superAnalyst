
from database.database import connect_to_postgres,get_postgres_secrets
from datetime import datetime, timedelta

from ..utils import get_days_hours

def get_ci_based_rfcs(network_name, rfc_filter=None,open_time=" "):
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    latest_open_time_result=open_time
    if latest_open_time_result:
        latest_open_time = latest_open_time_result
        rfc_cutoff_time_before,rfc_cutoff_time_after=get_days_hours(rfc_filter,latest_open_time)
    # Build the query with the cutoff time filter
    query = f"""
    WITH RankedRFCs AS (
        SELECT
            numberprgn, status, network_name, assign_dept, brief_description, location, open_time,
            ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
        FROM
            dc1sm_ro.rfcs
        WHERE 
            NETWORK_NAME = %s
            {f"AND open_time >= '{rfc_cutoff_time_before}'  AND open_time <= '{rfc_cutoff_time_after}'" if rfc_cutoff_time_before else ''}
    )
    SELECT
        numberprgn, status, network_name, assign_dept, brief_description, location, open_time
    FROM
        RankedRFCs
    WHERE
        rn = 1
    ORDER BY
        open_time DESC;
    """
    cursor.execute(query, (network_name,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in rows]
    
    cursor.close()
    conn.close()
    return data