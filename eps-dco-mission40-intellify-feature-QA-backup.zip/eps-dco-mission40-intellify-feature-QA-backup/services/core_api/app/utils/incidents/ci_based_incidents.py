
from fastapi import HTTPException
from database.database import connect_to_postgres,get_postgres_secrets
from datetime import datetime, timedelta

from ..utils import get_days_hours





def get_ci_based_incidents(network_name, incident_filter,open_time):
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    latest_open_time=open_time
    incident_cutoff_time_before,incident_cutoff_time_after=get_days_hours(incident_filter,latest_open_time)

    query = f"""
    WITH RankedIncidents AS (
        SELECT
            numberprgn, status, assignment, brief_description, location, open_time,network_name,
            ROW_NUMBER() OVER (PARTITION BY numberprgn ORDER BY open_time DESC) AS rn
        FROM
            dc1sm_ro.incidents
        WHERE
            NETWORK_NAME = %s
            {f"AND open_time >= '{incident_cutoff_time_before}'  AND open_time <= '{incident_cutoff_time_after}'" if incident_cutoff_time_after else ''}
    )
    SELECT
        numberprgn, status, assignment, brief_description, location, open_time,network_name
    FROM
        RankedIncidents
    WHERE
        rn = 1
    ORDER BY
        open_time DESC;
    """
    cursor.execute(query, (network_name,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    incidents_data = [dict(zip(columns, row)) for row in rows]
    
    print("incidents_data incidents_data",incidents_data)

    cursor.close()
    conn.close()

    return incidents_data

