from database.database import connect_to_postgres,get_postgres_secrets

 
def get_problem_tasks(network_name):
    query = """
    SELECT DISTINCT LOGICAL_NAME
    FROM itsm_owner.cis
    WHERE network_name = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchall()
    logical_name = result[0][0]
    print(logical_name)
    prob_tasks_query = f"""
    SELECT id,parent_problem,assignment,status,logical_name,open_time,brief_description
    FROM dc1sm_ro.problems_tasks
    WHERE logical_name = '{logical_name}';
    """
    cursor.execute(prob_tasks_query, (logical_name,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    tasks_data = [dict(zip(columns, row)) for row in rows]
    cursor.close()
    conn.close()
    return tasks_data

def get_problems(network_name):
    query = """
    SELECT DISTINCT LOGICAL_NAME
    FROM itsm_owner.cis
    WHERE network_name = %s;
    """
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    cursor.execute(query, (network_name,))
    result = cursor.fetchall()
    logical_name = result[0][0]
    print(logical_name)
    prob_tasks_query = f"""
    SELECT id,category,assignment,status,logical_name,open_time,description,brief_description
    FROM dc1sm_ro.problems
    WHERE logical_name = '{logical_name}';
    """
    cursor.execute(prob_tasks_query, (logical_name,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    tasks_data = [dict(zip(columns, row)) for row in rows]
    cursor.close()
    conn.close()
    return tasks_data

def get_ci_based_events(network_name):
    conn = connect_to_postgres({})
    cursor = conn.cursor()
    query=  """WITH RankedEvents AS (
                    SELECT
                        event_id,
                        created_ts,
                        event_title,
                        severity,
                        event_status,
                        ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY created_ts DESC) AS rn
                    FROM
                        dc1.events
                        
                    WHERE 
                        NETWORK_NAME = %s
                )
                SELECT
                    event_id,  created_ts, event_title, severity, event_status
                FROM
                    RankedEvents
                WHERE
                    rn = 1
                ORDER BY
                    created_ts DESC;
                """
    cursor.execute(query, (network_name,))
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in rows]
    cursor.close()
    conn.close()
    return data
