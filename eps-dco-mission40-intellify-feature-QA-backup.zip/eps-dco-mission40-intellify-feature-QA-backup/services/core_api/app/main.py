from fastapi import FastAPI
from routers.dashboard.ci_dashboard import dashboard_api
from routers.triage.triage_router import triage_router
from routers.triage.triage_llm_req import *
from routers.triage.ci_triage import *

from routers.incidents.ci_info import ci_info
from routers.incidents.ci_events import ci_events_inident
from routers.incidents.ci_based_incidents import ci_based_incidents
from routers.incidents.ci_based_rfcs import ci_based_rfcs
from routers.incidents.ci_events_prob_pt_apis import ci_events_prob_pt
from routers.incidents.rfc_assignment_group import rfc_assignment_group
from routers.incidents.get_incident_location import get_incident_location_api
from routers.incidents.incident_assignment_group import incident_assignment_group
from routers.incidents.rfc_location import rfc_location
from routers.incidents.incident_device_type import incident_device_type
from routers.incidents.rfc_device_type import rfc_device_type

from routers.incidents.ic_initial_analysis import ic_initial_analysis

from routers.events.ci_info_events import *
from routers.events.ci_based_events import *
from routers.events.ci_based_rfcs_events import *
from routers.events.ci_events_prob_pt_apis_events import *
from routers.events.get_events_location import *
from routers.events.rfc_assignment_group_events import *
from routers.events.event_assignment_group import *
from routers.events.rfc_location_events import *
from routers.login.login_sso import *
from routers.feedback.feedback import feedback_router
from fastapi.middleware.cors import CORSMiddleware
from routers.universal.search import search_router
from routers.ingst.ingest import ingest_router
from routers.similarity.similarity import similarity
import uvicorn

app = FastAPI(title="pfizer- Super Analyst")

app.add_middleware(
    middleware_class= CORSMiddleware,
    allow_origins = ["*"],
    allow_credentials =True,
    allow_methods = ["*"],
    allow_headers=["*"]
)

app.include_router(router=dashboard_api,tags=["Dashboard API"])
app.include_router(router=triage_router,tags=["Triage API"])
app.include_router(router=ci_info,tags=["CI Information"])

app.include_router(router=ci_based_incidents,tags=["ci_based_incidents"])
app.include_router(router=ci_based_rfcs,tags=["ci_based_rfcs"])
app.include_router(router=ci_events_prob_pt,tags=["ci_events_prob_pt"])

app.include_router(router=get_incident_location_api,tags=["get_incident_location"])
app.include_router(router=incident_assignment_group,tags=["incident_assignment_group"])
app.include_router(router=rfc_assignment_group,tags=["rfc_assignment_group"])
app.include_router(router=incident_device_type,tags=["incident_device_type"])
app.include_router(router=rfc_device_type,tags=["rfc_device_type"])

app.include_router(router=rfc_location,tags=["rfc_location"])
# app.include_router(router=triage_router,tags=["Triage API"])
# app.include_router(router=ci_info,tags=["CI Information"])

app.include_router(router=ci_info_events,tags=["Events"])
app.include_router(router=ci_based_events,tags=["Events"])
app.include_router(router=ci_based_rfcs_events,tags=["Events"])
app.include_router(router=ci_events_prob_pt_events,tags=["Events"])


#add new file events
app.include_router(router=ci_events_inident,tags=['Events'])

app.include_router(router=get_incident_location_api_events,tags=["Events"])
app.include_router(router=event_assignment_group,tags=["Events"])
app.include_router(router=rfc_assignment_group_events,tags=["Events"])
app.include_router(router=rfc_location_events,tags=["Events"])

app.include_router(router=login_router,tags=["Login"])
app.include_router(router=feedback_router,tags=["feedback"])

app.include_router(router=triage_llm_req,tags=["triage_llm_req"])
app.include_router(router=ci_triage,tags=["ci_triage"])

app.include_router(router=similarity,tags=["similarity_api"])

app.include_router(router=search_router, tags=['search_data'])
app.include_router(router=ingest_router, tags=['search_data'])

app.include_router(router=ic_initial_analysis,tags=["Ic Initial Analysis"])

# Run the FastAPI application
if __name__ == "__main__":
    uvicorn.run("main:app",reload=True ,host="127.0.0.1", port=8244)
